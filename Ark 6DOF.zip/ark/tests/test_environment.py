import math

import pytest

from ark.environment import Environment, Sounding, Wind, geopotential, gravity, isa, wind_vector
from ark.units import R0_GEOPOT


def geometric(h):
    return R0_GEOPOT * h / (R0_GEOPOT - h)


@pytest.mark.parametrize("h,T,p,rho,a", [
    (0, 288.15, 101325.0, 1.2250, 340.29),
    (11000, 216.65, 22632.0, 0.36392, 295.07),
    (20000, 216.65, 5474.9, 0.088035, 295.07),
])
def test_standard_atmosphere_table(h, T, p, rho, a):
    air = isa(geometric(h))
    assert air.T == pytest.approx(T, abs=0.01)
    assert air.p == pytest.approx(p, rel=2e-4)
    assert air.rho == pytest.approx(rho, rel=2e-4)
    assert air.a == pytest.approx(a, abs=0.02)


def test_sea_level_viscosity():
    assert isa(0.0).mu == pytest.approx(1.7894e-5, rel=1e-4)


@pytest.mark.parametrize("h", [11000.0, 20000.0, 32000.0])
def test_continuity_at_layer_boundaries(h):
    lo, hi = isa(geometric(h - 0.01)), isa(geometric(h + 0.01))
    assert lo.p == pytest.approx(hi.p, rel=1e-5)
    assert lo.T == pytest.approx(hi.T, abs=1e-3)


def test_geometric_altitude_is_not_geopotential():
    assert geopotential(11000.0) == pytest.approx(10981.0, abs=0.5)
    assert isa(11000.0).T == pytest.approx(216.77, abs=0.01)


def test_temperature_offset_keeps_pressure():
    a, b = isa(500.0), isa(500.0, dT=10.0)
    assert b.p == a.p and b.T == pytest.approx(a.T + 10.0)
    assert b.rho == pytest.approx(a.rho * a.T / b.T)


def test_out_of_range_raises():
    with pytest.raises(ValueError):
        isa(60000.0)


def test_gravity():
    assert gravity(0.0) == pytest.approx(9.80665)
    assert gravity(10000.0) == pytest.approx(9.7759, abs=2e-4)


def test_wind_direction_convention():
    assert wind_vector(5.0, 0.0) == pytest.approx((0.0, -5.0), abs=1e-12)     # from north blows south
    assert wind_vector(5.0, 90.0) == pytest.approx((-5.0, 0.0), abs=1e-12)    # from east blows west
    assert wind_vector(5.0, 270.0) == pytest.approx((5.0, 0.0), abs=1e-12)    # from west blows east


def test_wind_table_interpolates_through_north():
    w = Wind(model="table", table=[[0, 5.0, 350.0], [100, 5.0, 10.0]])
    e, n = w.mean(50.0)
    assert e == pytest.approx(0.0, abs=1e-9) and n < -4.9     # still from the north, not the south


def test_power_law_wind():
    w = Wind(model="power_law", speed=5.0, direction=270.0, ref_height=10.0, exponent=1 / 7)
    assert w.mean(10.0)[0] == pytest.approx(5.0)
    assert w.mean(100.0)[0] == pytest.approx(5.0 * 10 ** (1 / 7))


def test_gusts_repeat_with_seed_and_differ_without():
    g = dict(sigma=1.0, tau=2.0)
    a = Wind(model="constant", speed=3, direction=0, gust=g, seed=7)
    b = Wind(model="constant", speed=3, direction=0, gust=g, seed=7)
    c = Wind(model="constant", speed=3, direction=0, gust=g, seed=8)
    assert a(50.0, 3.21) == b(50.0, 3.21)
    assert a(50.0, 3.21) != c(50.0, 3.21)
    import numpy as np
    assert np.std(a.gust[:, 0]) == pytest.approx(1.0, rel=0.15)


def test_sounding_matches_its_own_levels():
    s = Sounding([200.0, 1000.0, 2000.0], [99000.0, 90000.0, 80000.0], [285.0, 280.0, 274.0], [1, 2, 3], [0, 0, 0])
    z = R0_GEOPOT * 1000.0 / (R0_GEOPOT - 1000.0)
    air = s.air(z)
    assert air.p == pytest.approx(90000.0, rel=1e-9) and air.T == pytest.approx(280.0)
    assert s.wind(z)[0] == pytest.approx(2.0)


def test_environment_uses_site_elevation():
    env = Environment(elevation=1000.0)
    assert env.air(0.0).rho == pytest.approx(isa(1000.0).rho)
    assert math.isclose(env.g(0.0), gravity(1000.0))
