"""The in-browser simulator (web/sim.js) must agree with the Python core."""
import json
import shutil
import subprocess

import pytest

from conftest import ROOT
from ark.config import fly
from ark.webmodel import web_model

NODE = shutil.which("node")
RUN = "const S=require(process.argv[1]);const m=JSON.parse(require('fs').readFileSync(0,'utf8'));" \
      "const r=S.simulate(m.model,m.options);console.log(JSON.stringify({summary:r.summary,events:r.events,failed:r.failed," \
      "n:r.samples?r.samples.t.length:0}));"


def js(model, options=None):
    out = subprocess.run([NODE, "-e", RUN, str(ROOT / "web" / "sim.js")], input=json.dumps(dict(model=model, options=options or {})),
                         capture_output=True, text=True, check=True)
    return json.loads(out.stdout)


@pytest.mark.skipif(NODE is None, reason="node is not installed")
@pytest.mark.parametrize("name", ["alpha3", "bella_lui", "ndrt_2020"])
def test_browser_model_matches_python(configs, name):
    cfg = configs[name]
    py = fly(cfg).summary
    r = js(web_model(cfg))
    s = r["summary"]
    assert s["apogee"] == pytest.approx(py["apogee"], rel=2e-3)
    assert s["apogee_time"] == pytest.approx(py["apogee_time"], rel=2e-3)
    assert s["max_speed"] == pytest.approx(py["max_speed"], rel=2e-3)
    assert s["rail_exit_speed"] == pytest.approx(py["rail_exit_speed"], rel=2e-3)
    assert s["flight_time"] == pytest.approx(py["flight_time"], rel=5e-3)
    assert s["landing_distance"] == pytest.approx(py["landing_distance"], rel=0.01, abs=0.5)
    assert [e["name"] for e in r["events"]] == [e["name"] for e in fly(cfg).events if e["name"] != "peak_parachute_load"]


@pytest.mark.skipif(NODE is None, reason="node is not installed")
def test_browser_what_if_options_match_python(configs):
    import copy
    cfg = copy.deepcopy(configs["bella_lui"])
    cfg["site"].update(rail_elevation=80.0, wind=dict(model="constant", speed=8.0, direction=300.0))
    py = fly(cfg, dict(cd_scale=1.2, impulse_scale=0.95)).summary
    s = js(web_model(configs["bella_lui"]), dict(windMode="custom", windSpeed=8.0, windFrom=300.0, railElevation=80.0,
                                                 dragScale=1.2, impulseScale=0.95))["summary"]
    # the Python run keeps the recorded temperature profile too (wind only is replaced), as the browser does
    assert s["apogee"] == pytest.approx(py["apogee"], rel=3e-3)
    assert s["landing_x"] == pytest.approx(py["landing_x"], rel=0.01, abs=1.0)
    assert s["landing_y"] == pytest.approx(py["landing_y"], rel=0.01, abs=1.0)


@pytest.mark.skipif(NODE is None, reason="node is not installed")
def test_browser_monte_carlo_perturbations_match_python(configs):
    """The offsets the page's live Monte Carlo applies mean the same thing as the Python core's."""
    cfg = configs["ndrt_2020"]
    pert = dict(mass_scale=1.02, cd_scale=0.93, impulse_scale=1.04, wind_speed_offset=2.0, wind_direction_offset=-25.0,
                rail_elevation_offset=-2.0, rail_azimuth_offset=10.0, cds_scale=1.15)
    py = fly(cfg, pert).summary
    opts = dict(massScale=1.02, dragScale=0.93, impulseScale=1.04, windSpeedOffset=2.0, windDirOffset=-25.0, railElevation=88.0,
                azimuthOffset=10.0, cdsScale=1.15)
    s = js(web_model(cfg), opts)["summary"]
    assert s["apogee"] == pytest.approx(py["apogee"], rel=3e-3)
    assert s["landing_x"] == pytest.approx(py["landing_x"], rel=0.01, abs=1.5)
    assert s["landing_y"] == pytest.approx(py["landing_y"], rel=0.01, abs=1.5)
    f = js(web_model(cfg), dict(opts, fast=True))
    assert f["n"] == 0                                                   # fast mode keeps no samples
    assert f["summary"]["apogee"] == pytest.approx(py["apogee"], rel=5e-3)
    assert f["summary"]["landing_x"] == pytest.approx(py["landing_x"], rel=0.02, abs=3.0)
