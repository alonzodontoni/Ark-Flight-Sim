import pytest

from conftest import DATA
from ark.motor import EngFormatError, Motor, load_eng, parse_eng


@pytest.mark.parametrize("f,impulse,cls,prop", [
    ("Estes_C6.eng", 8.82, "C", 0.0108),
    ("AeroTech_K828FJ.eng", 2070.99, "K", 1.45),
    ("Cesaroni_L1395.eng", 4894.9, "L", 2.475),
])
def test_reference_motors(f, impulse, cls, prop):
    m = Motor(load_eng(DATA / "motors" / f))
    assert m.total_impulse == pytest.approx(impulse, rel=5e-3)
    assert m.impulse_class == cls
    assert m.propellant_mass0 == pytest.approx(prop)


def test_thrust_is_zero_outside_the_burn():
    m = Motor(load_eng(DATA / "motors" / "Estes_C6.eng"))
    assert m.thrust(-1.0) == 0.0 and m.thrust(0.0) == 0.0 and m.thrust(m.burn_time) == 0.0 and m.thrust(99.0) == 0.0
    assert m.thrust(0.0155) == pytest.approx(0.473)          # halfway up the implied ramp from (0, 0)


def test_propellant_mass_falls_monotonically_to_zero():
    m = Motor(load_eng(DATA / "motors" / "AeroTech_K828FJ.eng"))
    assert m.propellant_mass(0.0) == pytest.approx(1.45)
    assert m.propellant_mass(m.burn_time) == pytest.approx(0.0, abs=1e-12)
    ts = [i * m.burn_time / 500 for i in range(501)]
    ms = [m.propellant_mass(t) for t in ts]
    assert all(b <= a + 1e-15 for a, b in zip(ms, ms[1:]))


def test_impulse_is_the_integral_of_thrust():
    m = Motor(load_eng(DATA / "motors" / "Cesaroni_L1395.eng"))
    n = 20000; h = m.burn_time / n
    num = sum(0.5 * (m.thrust(i * h) + m.thrust((i + 1) * h)) * h for i in range(n))
    assert m.total_impulse == pytest.approx(num, rel=1e-5)
    assert m.impulse(1.234) == pytest.approx(sum(0.5 * (m.thrust(i * 1e-4) + m.thrust((i + 1) * 1e-4)) * 1e-4
                                                 for i in range(12340)), rel=1e-5)


GOOD = "; comment\r\nX1 18 70 0-3 0.010 0.020 Me\r\n ; another comment\r\n0.1\t5.0\r\n  0.5   5.0\r\n1.0 0.0\r\n\r\n"


def test_parser_handles_comments_tabs_and_windows_line_endings():
    e = parse_eng(GOOD)
    assert e.name == "X1" and e.diameter == pytest.approx(0.018) and e.length == pytest.approx(0.070)
    assert e.t == [0.1, 0.5, 1.0] and e.thrust == [5.0, 5.0, 0.0]
    assert Motor(e).total_impulse == pytest.approx(0.25 + 2.0 + 1.25)
    assert Motor(e).case_mass == pytest.approx(0.010)


@pytest.mark.parametrize("bad", [
    "",
    "X1 18 70 0 0.01\n0.1 5\n1 0\n",                             # short header
    "X1 18 70 0 0.01 0.02 Me\n0.5 5\n0.4 5\n1 0\n",              # time goes backwards
    "X1 18 70 0 0.01 0.02 Me\n0.5 5\n1 3\n",                     # does not end at zero
    "X1 18 70 0 0.01 0.02 Me\n0.5 5\n1 0\nX2 18 70 0 0.01 0.02 Me\n0.5 5\n1 0\n",  # two motors
    "X1 18 70 0 0.03 0.02 Me\n0.5 5\n1 0\n",                     # propellant heavier than the motor
])
def test_parser_rejects_malformed_files(bad):
    with pytest.raises(EngFormatError):
        parse_eng(bad)
