"""Every rocket in the library flies, and agrees with RocketPy's published result for the same inputs."""
import glob

import pytest

from conftest import DATA
from ark.config import fly, load_config

LIB = sorted(glob.glob(str(DATA / "library" / "*.yaml")))


@pytest.mark.parametrize("path", LIB, ids=lambda p: p.split("/")[-1][:-5])
def test_library_rocket_matches_the_published_rocketpy_apogee(path):
    cfg = load_config(path)
    meta = cfg["meta"]
    s = fly(cfg).summary
    assert s["rail_exit_speed"] > 15.0
    # same published inputs, two independent simulators: the apogees should agree closely
    assert s["apogee"] == pytest.approx(meta["rocketpy_apogee"], rel=0.025)
    # against the real flight the error is dominated by the quality of the published inputs
    assert s["apogee"] == pytest.approx(meta["measured_apogee"], rel=0.10)


def test_library_is_not_empty():
    assert len(LIB) >= 10
