import copy
import json
import math

import numpy as np
import pytest

from ark.config import ConfigError, build, fly, load_config, validate
from ark.flight import PHASES
from ark.integrate import solve
from ark.montecarlo import (dispersion_ellipse, ellipse_scale, inside_ellipse, monte_carlo, one_at_a_time)
from ark.output import FIELDS, trajectory
from conftest import DATA

ORDER = ["liftoff", "rail_exit", "burnout", "apogee"]


@pytest.mark.parametrize("name", ["alpha3", "bella_lui", "ndrt_2020"])
def test_all_reference_rockets_fly_pad_to_ground(configs, name):
    res = fly(configs[name])
    names = [e["name"] for e in res.events]
    assert [n for n in names if n in ORDER] == ORDER
    assert names[-1] in ("landing", "peak_parachute_load") and names.count("landing") == 1
    ts = [e["t"] for e in res.events]
    assert ts == sorted(ts)
    for a, b in zip(res.segments, res.segments[1:]):
        assert a.t[-1] == pytest.approx(b.t[0], abs=1e-9)
    s = res.summary
    assert s["status"] == "ok" and s["apogee"] > 100 and s["rail_exit_speed"] > 10 and s["impact_speed"] < 25


def test_descent_rate_and_drift(stub_vehicle):
    v = stub_vehicle()
    f = lambda t, y: v.descent_deriv(t, y, 18.227, lambda t: 11.673)
    ts, ys, _ = solve(f, 0.0, [0, 0, 3000.0, 0, 0, 0], 60.0, method="RK45", max_step=0.1)
    assert -ys[-1][5] == pytest.approx(5.00, abs=0.005)
    from ark.environment import Wind
    v.env.wind = Wind(model="constant", speed=5.0, direction=270.0)
    ts, ys, hit = solve(f, 0.0, [0, 0, 300.0, 5.0, 0, -5.0], 200.0, events=[(lambda t, y: y[2], -1)], method="RK45", max_step=0.1)
    assert hit == 0 and ys[-1][0] == pytest.approx(300.0, abs=0.5)


def test_main_parachute_opens_at_its_altitude(configs):
    res = fly(configs["ndrt_2020"])
    ev = {e["name"]: e for e in res.events}
    dro, main = ev["deploy:drogue"], ev["deploy:main"]
    assert dro["t"] == pytest.approx(ev["apogee"]["t"] + 1.0, abs=1e-6)
    # the trigger fires at 167.64 m; the canopy opens one second (the lag) later
    seg = [s for s in res.segments if s.kind == "3dof" and s.t[-1] <= main["t"] + 1e-9][-2]
    assert seg.y[-1][2] == pytest.approx(167.64, abs=0.1)
    assert main["altitude"] < 167.64 and main["speed"] > 15


def test_slower_inflation_lowers_the_opening_load(configs):
    cfg = copy.deepcopy(configs["ndrt_2020"])
    loads = []
    for ti in (0.2, 1.0, 3.0):
        cfg["rocket"]["recovery"][1]["inflation_time"] = ti
        loads.append(fly(cfg).summary["peak_parachute_load"])
    assert loads[0] > loads[1] > loads[2] and math.isfinite(loads[0])


def test_no_recovery_system_lands_ballistic(alpha):
    alpha["rocket"]["recovery"] = []
    s = fly(alpha).summary
    assert s["status"] == "ballistic" and s["impact_speed"] > 30


def test_gusts_are_repeatable_and_seeded(alpha):
    alpha["site"]["wind"] = dict(model="power_law", speed=4.0, direction=250.0, gust=dict(sigma=1.0, tau=2.0))
    a = fly(alpha).summary; b = fly(alpha).summary
    assert a == b
    c = fly(alpha, dict(gust_seed=123)).summary
    assert c["landing_x"] != a["landing_x"] and c["apogee"] == pytest.approx(a["apogee"], rel=0.05)
    alpha["site"]["wind"]["gust"]["sigma"] = 0.0
    d = fly(alpha).summary
    alpha["site"]["wind"].pop("gust")
    assert fly(alpha).summary == d


# ---------------------------------------------------------------------- config
def test_missing_field_and_unknown_key_are_named(alpha):
    alpha.pop("_dir")
    bad = copy.deepcopy(alpha); del bad["site"]["rail_length"]
    with pytest.raises(ConfigError, match="rail_length"):
        validate(bad)
    bad = copy.deepcopy(alpha); bad["site"]["rail_lenght"] = 1.0
    with pytest.raises(ConfigError, match="rail_lenght"):
        validate(bad)
    bad = copy.deepcopy(alpha); bad["rocket"]["components"][3]["position"] = 5.0
    with pytest.raises(ConfigError, match="outside"):
        validate(bad)
    bad = copy.deepcopy(alpha); bad["rocket"]["reference_diameter"] = -1
    with pytest.raises(ConfigError, match="reference_diameter"):
        validate(bad)


def test_motor_must_fit(alpha):
    alpha["rocket"]["reference_diameter"] = 0.012
    with pytest.raises(ConfigError, match="does not fit"):
        build(alpha)


# ---------------------------------------------------------------------- output
def test_trajectory_json_contract(configs):
    cfg = configs["bella_lui"]
    res = fly(cfg)
    tr = trajectory(res, cfg, rate=25.0)
    json.dumps(tr)                                             # serialisable
    s = tr["samples"]
    assert set(s) == set(FIELDS) and len({len(v) for v in s.values()}) == 1
    assert tr["meta"]["schema_version"] == 1 and tr["meta"]["phases"] == PHASES
    t = np.array(s["t"]); assert np.all(np.diff(t) > 0) and t[0] == 0.0
    assert max(s["z"]) == pytest.approx(res.summary["apogee"], abs=0.5)
    q = np.array([s["q0"], s["q1"], s["q2"], s["q3"]]); assert np.allclose((q ** 2).sum(axis=0), 1.0, atol=1e-3)
    ph = s["phase"]; assert ph == sorted(ph) and ph[-1] == PHASES.index("landed")
    assert tr["rocket"]["length"] == pytest.approx(2.6776)
    assert tr["summary"]["apogee"] == pytest.approx(res.summary["apogee"], abs=1e-5)


# ----------------------------------------------------------------- Monte Carlo
def test_ellipse_scale_factors():
    assert ellipse_scale(0.5) == pytest.approx(1.1774, abs=1e-4)
    assert ellipse_scale(0.95) == pytest.approx(2.4477, abs=1e-4)
    assert ellipse_scale(0.99) == pytest.approx(3.0349, abs=1e-4)
    assert 1 - math.exp(-2) == pytest.approx(0.8647, abs=1e-4)       # what a '2 sigma' ellipse really holds


def test_ellipse_contains_the_stated_fraction_and_points_the_right_way():
    rng = np.random.default_rng(0)
    u = rng.standard_normal(20000) * 30.0; w = rng.standard_normal(20000) * 5.0
    x = (u - w) / math.sqrt(2) + 100.0; y = (u + w) / math.sqrt(2) - 40.0        # long axis along north-east
    c, ax, ang = dispersion_ellipse(x, y, 0.95)
    assert inside_ellipse(x, y, c, ax, ang).mean() == pytest.approx(0.95, abs=0.007)
    assert math.degrees(ang) % 180 == pytest.approx(45.0, abs=1.0)
    assert c == pytest.approx((100.0, -40.0), abs=1.0) and ax[0] / ax[1] == pytest.approx(6.0, rel=0.05)


def test_zero_spread_reproduces_the_nominal_flight(alpha):
    alpha["uncertainty"] = {k: dict(sigma=0.0) for k in alpha["uncertainty"]}
    nominal = fly(alpha).summary
    rows = monte_carlo(alpha, 3, seed=1)
    assert all(r["apogee"] == pytest.approx(nominal["apogee"], rel=1e-12) for r in rows)


def test_monte_carlo_is_independent_of_worker_count(alpha):
    alpha["site"]["wind"] = dict(model="power_law", speed=3.0, direction=270.0)
    a = monte_carlo(alpha, 6, seed=5, workers=1)
    b = monte_carlo(alpha, 6, seed=5, workers=2)
    assert a == b
    assert len({r["apogee"] for r in a}) == 6
    assert monte_carlo(alpha, 2, seed=6)[0]["apogee"] != a[0]["apogee"]


def test_failed_runs_are_recorded(alpha):
    alpha["rocket"]["components"].append(dict(type="mass", name="brick", position=0.2, mass=5.0))
    rows = monte_carlo(alpha, 2, seed=0)
    assert all(r["status"].startswith("failed") and math.isnan(r["apogee"]) for r in rows)


def test_one_at_a_time_signs(alpha):
    alpha["site"]["wind"] = dict(model="power_law", speed=3.0, direction=270.0)
    rows = {r["parameter"]: r for r in one_at_a_time(alpha)}
    assert rows["cd_scale"]["apogee_plus"] < 0 < rows["cd_scale"]["apogee_minus"]
    assert rows["impulse_scale"]["apogee_plus"] > 0 > rows["impulse_scale"]["apogee_minus"]
    assert rows["cd_scale"]["apogee_plus"] == pytest.approx(-rows["cd_scale"]["apogee_minus"], rel=0.25)


def test_cli_runs(tmp_path, capsys):
    from ark.cli import main
    out = tmp_path / "t.json"
    main(["run", str(DATA / "rockets" / "alpha3.yaml"), "-o", str(out)])
    assert "apogee" in capsys.readouterr().out
    assert json.loads(out.read_text())["rocket"]["name"] == "Estes Alpha III"
    assert load_config(DATA / "rockets" / "ndrt_2020.yaml")["rocket"]["name"].startswith("Notre Dame")
