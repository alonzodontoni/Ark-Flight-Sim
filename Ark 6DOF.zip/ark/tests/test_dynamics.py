import copy
import math

import numpy as np
import pytest

from conftest import StubAero, StubMass
from ark import quaternion as Q
from ark.config import build, fly
from ark.integrate import rk4, solve

G = 9.80665
UP = Q.from_rail(90.0, 0.0)


def state(pos=(0, 0, 0), vel=(0, 0, 0), q=UP, w=(0, 0, 0)):
    return np.array([*pos, *vel, *q, *w], float)


# ---------------------------------------------------------------- translation
def test_vacuum_ballistic_flight(stub_vehicle):
    v = stub_vehicle(no_aero=True)
    c = 100 * math.cos(math.pi / 4)
    ts, ys, hit = solve(v.deriv6, 0.0, state(vel=(c, 0, c)), 60.0, events=[(lambda t, y: y[2], -1)],
                        method="rk4", dt=0.01)
    assert hit == 0
    assert ts[-1] == pytest.approx(14.421, abs=1e-3)
    assert ys[-1][0] == pytest.approx(1019.72, abs=0.01)
    assert ys[:, 2].max() == pytest.approx(254.93, abs=0.01)
    e = 0.5 * (ys[:, 3] ** 2 + ys[:, 5] ** 2) + G * ys[:, 2]
    assert np.ptp(e) < 1e-8 * e[0]


def burnt_out_alpha(stub_vehicle):
    aero = StubAero([(2.0, 0.03), (10.0, 0.28)], 0.025, cd=0.56, length=0.311)
    return stub_vehicle(mass=StubMass(m=0.0463, xcg=0.2, Ia=1e-5, It=4e-4), aero=aero)


def test_terminal_velocity(stub_vehicle):
    v = burnt_out_alpha(stub_vehicle)
    ts, ys, _ = solve(v.deriv6, 0.0, state(pos=(0, 0, 5000)), 40.0, method="RK45")
    assert -ys[-1][5] == pytest.approx(51.93, abs=0.01)


def test_vertical_coast_matches_closed_form(stub_vehicle):
    v = burnt_out_alpha(stub_vehicle)
    ts, ys, hit = solve(v.deriv6, 0.0, state(vel=(0, 0, 100)), 20.0, events=[(lambda t, y: y[5], -1)],
                        method="rk4", dt=0.002)
    assert hit == 0
    assert ys[-1][2] == pytest.approx(213.02, abs=0.01) and ts[-1] == pytest.approx(5.782, abs=1e-3)


def test_rk4_is_fourth_order_on_the_coast_problem(stub_vehicle):
    v = burnt_out_alpha(stub_vehicle)
    vt = math.sqrt(2 * 0.0463 * G / (1.225 * 0.56 * math.pi * 0.025 ** 2 / 4))
    exact = vt * math.tan(math.atan(100 / vt) - G * 2.0 / vt)       # speed after 2 s of coasting
    errs = []
    for dt in (0.05, 0.025, 0.0125, 0.00625):   # asymptotic range (the error changes sign near dt = 0.15)
        ts, ys, _ = rk4(v.deriv6, 0.0, state(vel=(0, 0, 100)), 2.0, dt)
        errs.append(abs(ys[-1][5] - exact))
    orders = [math.log2(a / b) for a, b in zip(errs, errs[1:])]
    assert all(3.6 < o < 4.4 for o in orders), orders


# ------------------------------------------------------------------- rotation
def test_torque_free_spin(stub_vehicle):
    v = stub_vehicle(mass=StubMass(Ia=0.01, It=1.0), no_aero=True)
    ts, ys, _ = solve(v.deriv6, 0.0, state(pos=(0, 0, 1e4), w=(10.0, 0.1, 0.0)), 3.0, method="DOP853",
                      max_step=0.005, rtol=1e-10, atol=1e-12)
    assert np.allclose(ys[:, 10], 10.0)
    wp = np.hypot(ys[:, 11], ys[:, 12])
    assert np.allclose(wp, 0.1, rtol=1e-8)
    # the transverse rate circles in the body frame with period 2 pi I_t / ((I_t - I_a) w_x)
    up = [ts[i] + (ts[i + 1] - ts[i]) * (0 - ys[i, 12]) / (ys[i + 1, 12] - ys[i, 12])
          for i in range(len(ts) - 1) if ys[i, 12] < 0 <= ys[i + 1, 12]]
    assert np.diff(up).mean() == pytest.approx(0.6347, abs=2e-4)
    # angular momentum is constant in the launch frame
    H = np.array([Q.rotate(tuple(y[6:10] / np.linalg.norm(y[6:10])), (0.01 * y[10], y[11], y[12])) for y in ys])
    assert np.ptp(H, axis=0).max() < 1e-7
    assert np.abs(np.linalg.norm(ys[:, 6:10], axis=1) - 1).max() < 1e-8


def test_pitch_oscillation_frequency_and_damping(stub_vehicle):
    aero = StubAero([(2.0, 0.0699), (6.826784270229682, 0.5533333333333333)], 0.05)
    v = stub_vehicle(mass=StubMass(m=0.3, xcg=0.35, Ia=1e-4, It=0.01), aero=aero)
    v.freeze_translation = True                       # 'wind tunnel': hold the airspeed, let it pitch
    q = Q.qmul(UP, Q.from_axis_angle((0, 1, 0), math.radians(2.0)))
    ts, ys, _ = solve(v.deriv6, 0.0, state(vel=(0, 0, 50.0), q=q), 4.0, method="DOP853", max_step=0.002,
                      rtol=1e-10, atol=1e-12)
    wb = np.array([Q.rotate_inv(tuple(y[6:10]), (0, 0, 50.0))[2] for y in ys])    # crossflow, signed
    zc = [ts[i] + (ts[i + 1] - ts[i]) * (0 - wb[i]) / (wb[i + 1] - wb[i])
          for i in range(len(ts) - 1) if wb[i] * wb[i + 1] < 0]
    wd = math.pi / np.diff(zc).mean()
    peaks = [abs(wb[i]) for i in range(1, len(wb) - 1) if abs(wb[i]) > abs(wb[i - 1]) and abs(wb[i]) >= abs(wb[i + 1])]
    delta = np.mean(np.log(np.array(peaks[:-1]) / np.array(peaks[1:])))           # per half cycle
    zeta = delta / math.sqrt(math.pi ** 2 + delta ** 2)
    wn = wd / math.sqrt(1 - zeta ** 2)
    assert wn == pytest.approx(15.777, rel=0.01)
    assert zeta == pytest.approx(0.0837, rel=0.02)


# ---------------------------------------------------------------- whole flights
def vertical_no_wind(cfg, **sim):
    cfg = copy.deepcopy(cfg)
    cfg["site"]["rail_elevation"] = 90.0; cfg["site"]["wind"] = dict(model="none")
    cfg["site"].pop("sounding", None)
    cfg.setdefault("sim", {}).update(sim)
    return cfg


def test_regression_against_the_inspiration_repo(alpha):
    cfg = vertical_no_wind(alpha, constant_density=1.225, constant_gravity=True)
    s = fly(cfg).summary
    assert s["apogee"] == pytest.approx(373.4, rel=0.005)
    assert s["max_speed"] == pytest.approx(116.2, rel=0.005)
    assert s["apogee_time"] == pytest.approx(7.94, rel=0.01)


def test_vertical_flight_has_no_angle_of_attack(alpha):
    s = fly(vertical_no_wind(alpha)).summary
    assert s["max_alpha_deg"] < 1e-6 and s["landing_distance"] < 1e-6


def test_integrators_agree(alpha):
    a = fly(vertical_no_wind(alpha, method="rk4", dt=0.001)).summary["apogee"]
    b = fly(vertical_no_wind(alpha, method="RK45")).summary["apogee"]
    c = fly(vertical_no_wind(alpha, method="DOP853")).summary["apogee"]
    assert a == pytest.approx(b, rel=1e-3) and b == pytest.approx(c, rel=1e-3)


def nose_east_at_burnout(cfg):
    res = fly(cfg)
    seg = [s for s in res.segments if s.phase == "powered"][-1]
    return Q.rotate(tuple(seg.y[-1][6:10]), (1, 0, 0))[0], res


def test_stable_rocket_turns_into_the_wind_and_mirrors(alpha):
    west = vertical_no_wind(alpha); west["site"]["wind"] = dict(model="constant", speed=5.0, direction=270.0)
    east = vertical_no_wind(alpha); east["site"]["wind"] = dict(model="constant", speed=5.0, direction=90.0)
    nw, rw = nose_east_at_burnout(west); ne, re_ = nose_east_at_burnout(east)
    assert nw < -0.02            # wind from the west: nose tilts west, into the wind
    assert ne == pytest.approx(-nw, rel=1e-6)
    aw = [e for e in rw.events if e["name"] == "apogee"][0]; ae = [e for e in re_.events if e["name"] == "apogee"][0]
    assert aw["x"] == pytest.approx(-ae["x"], rel=1e-5) and aw["altitude"] == pytest.approx(ae["altitude"], rel=1e-7)
    assert rw.summary["apogee"] < fly(vertical_no_wind(alpha)).summary["apogee"]
    assert rw.summary["quaternion_norm_error"] < 1e-6


def test_result_does_not_depend_on_roll_orientation(configs):
    """A symmetric rocket must fly the same path whatever roll angle it leaves the rail with."""
    cfg = copy.deepcopy(configs["bella_lui"])
    a = fly(cfg).summary
    cfg["site"]["rail_azimuth"] += 360.0
    assert fly(cfg).summary["apogee"] == pytest.approx(a["apogee"], rel=1e-4)     # solver tolerance
    v, kw = build(configs["bella_lui"])
    from ark.flight import simulate
    import ark.flight as F
    orig = F.from_rail
    try:
        F.from_rail = lambda el, az: Q.qmul(orig(el, az), Q.from_axis_angle((1, 0, 0), 1.1))
        b = simulate(v, **kw).summary
    finally:
        F.from_rail = orig
    assert b["apogee"] == pytest.approx(a["apogee"], rel=1e-4)
    assert b["landing_x"] == pytest.approx(a["landing_x"], abs=0.1)


def test_unstable_rocket_tumbles_but_the_run_finishes(alpha):
    cfg = vertical_no_wind(alpha); cfg["site"]["wind"] = dict(model="constant", speed=3.0, direction=270.0)
    cfg["rocket"]["components"].append(dict(type="mass", name="tail weight", position=0.30, mass=0.06))
    v, _ = build(cfg)
    assert v.aero.cp(0.0)[1] < v.mass.at(0.0)[1]          # CP ahead of CG
    s = fly(cfg).summary
    assert s["max_alpha_deg"] > 60.0
    assert s["apogee"] < 0.5 * fly(vertical_no_wind(alpha)).summary["apogee"]


def test_variable_mass_terms_are_small_and_switchable(configs):
    cfg = copy.deepcopy(configs["ndrt_2020"])
    a = fly(cfg).summary["apogee"]
    cfg["sim"].update(jet_damping=False, inertia_rate=False)
    b = fly(cfg).summary["apogee"]
    assert a != b and abs(a - b) / a < 0.01


def test_thrust_misalignment_tilts_the_flight(alpha):
    cfg = vertical_no_wind(alpha); cfg["sim"]["thrust_misalignment"] = [0.5, 0.0]
    s = fly(cfg).summary
    assert s["max_alpha_deg"] > 0.01 and s["landing_distance"] > 0.1
