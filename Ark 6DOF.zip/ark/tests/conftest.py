import copy
import math
from pathlib import Path

import pytest

from ark.config import load_config
from ark.dynamics import Vehicle
from ark.environment import Environment

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"


@pytest.fixture(scope="session")
def configs():
    return {n: load_config(DATA / "rockets" / f"{n}.yaml") for n in ("alpha3", "bella_lui", "ndrt_2020")}


@pytest.fixture
def alpha(configs):
    return copy.deepcopy(configs["alpha3"])


class StubMotor:
    burn_time = 0.0
    def thrust(self, t): return 0.0
    def mass_flow(self, t): return 0.0
    def propellant_mass(self, t): return 0.0


class StubMass:
    nozzle_position = 0.6
    def __init__(self, m=1.0, xcg=0.35, Ia=0.01, It=1.0):
        self.v = (m, xcg, Ia, It)
    def at(self, t): return self.v
    def inertia_rate(self, t): return 0.0


class StubAero:
    """Fixed Barrowman components and a constant drag coefficient."""
    def __init__(self, comps, d_ref, cd=0.0, length=0.6):
        self.comps = comps; self.d_ref = d_ref; self.A_ref = math.pi * d_ref ** 2 / 4; self._cd = cd; self.length = length
    def normal(self, mach): return self.comps
    def cd(self, mach, re, thrusting): return self._cd
    def cp(self, mach=0.0):
        cn = sum(c for c, _ in self.comps)
        return cn, sum(c * x for c, x in self.comps) / cn


@pytest.fixture
def stub_vehicle():
    def make(mass=None, aero=None, rho=1.225, **kw):
        env = Environment(constant_density=rho, constant_gravity=True)
        return Vehicle(env, StubMotor(), mass or StubMass(), aero or StubAero([(2.0, 0.1)], 0.05), **kw)
    return make
