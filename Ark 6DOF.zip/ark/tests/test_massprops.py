import pytest

from ark.config import build
from ark.geometry import fin_cg_chordwise, frustum_profile, nose_profile, shell_properties
from ark.massprops import MassModel, component_mass_item
from conftest import StubMotor


def test_two_point_masses():
    comps = [dict(type="mass", position=0.0, mass=1.0), dict(type="mass", position=1.0, mass=3.0)]
    m = StubMotor(); m.length = 0.1; m.diameter = 0.02; m.case_mass = 0.0
    mm = MassModel(comps, m, nozzle_position=1.0)
    mass, xcg, Ia, It = mm.at(0.0)
    assert mass == pytest.approx(4.0) and xcg == pytest.approx(0.75) and It == pytest.approx(0.75)


def test_numerical_shell_matches_cone_formulas():
    L, R = 0.3, 0.05
    A, xcg, ka2, kt2 = shell_properties(nose_profile("cone", L, R), L, 4000)
    assert xcg == pytest.approx(2 * L / 3, rel=1e-4)
    assert ka2 == pytest.approx(R * R / 2, rel=1e-4)
    assert kt2 == pytest.approx(R * R / 4 + L * L / 18, rel=1e-4)


def test_numerical_shell_matches_thin_tube():
    L, R = 0.4, 0.03
    A, xcg, ka2, kt2 = shell_properties(frustum_profile(L, R, R), L)
    assert xcg == pytest.approx(L / 2) and ka2 == pytest.approx(R * R)
    assert kt2 == pytest.approx(R * R / 2 + L * L / 12, rel=1e-6)
    it = component_mass_item(dict(type="body", position=0.1, length=L, diameter=2 * R, mass=2.0))
    assert it["x"] == pytest.approx(0.3) and it["It"] == pytest.approx(2.0 * kt2, rel=1e-6)


@pytest.mark.parametrize("shape", ["ogive", "parabolic", "ellipsoid"])
def test_nose_profiles_meet_the_body(shape):
    f = nose_profile(shape, 0.2, 0.04)
    assert float(f(0.0)) == pytest.approx(0.0, abs=1e-12) and float(f(0.2)) == pytest.approx(0.04)


def test_fin_cg_limits():
    assert fin_cg_chordwise(0.1, 0.1, 0.0) == pytest.approx(0.05)        # rectangle
    assert fin_cg_chordwise(0.12, 0.0, 0.0) == pytest.approx(0.04)       # triangle, unswept leading edge


def test_alpha3_masses_and_burn_sequence(alpha):
    v, _ = build(alpha)
    tb = v.motor.burn_time
    assert v.mass.at(0.0)[0] == pytest.approx(0.0571, abs=1e-6)
    assert v.mass.at(tb)[0] == pytest.approx(0.0463, abs=1e-6)
    ts = [i * tb / 200 for i in range(201)]
    vals = [v.mass.at(t) for t in ts]
    assert all(b[0] <= a[0] + 1e-15 for a, b in zip(vals, vals[1:]))     # mass falls
    assert all(b[1] <= a[1] + 1e-12 for a, b in zip(vals, vals[1:]))     # CG moves forward (motor is aft)
    assert all(x[3] > 0 and x[2] > 0 for x in vals)


def test_inertia_rate_is_negative_during_the_burn(alpha):
    v, _ = build(alpha)
    assert v.mass.inertia_rate(0.8) < 0.0
    assert v.mass.inertia_rate(v.motor.burn_time + 1.0) == pytest.approx(0.0, abs=1e-12)


def test_mass_scale_and_cg_offset(alpha):
    v0, _ = build(alpha); v1, _ = build(alpha, dict(mass_scale=1.1, cg_offset=0.01))
    assert v1.mass.m_dry == pytest.approx(1.1 * v0.mass.m_dry)
    assert v1.mass.x_dry == pytest.approx(v0.mass.x_dry + 0.01)
