import math

import pytest

from ark.aero import Aero, base_drag, fin_midchord_length, skin_friction
from ark.config import build

EXAMPLE = [
    dict(type="nose", shape="ogive", length=0.15, diameter=0.05),
    dict(type="body", position=0.15, length=0.45, diameter=0.05),
    dict(type="fins", count=3, position=0.52, root_chord=0.08, tip_chord=0.04, span=0.05, sweep=0.04,
         body_diameter=0.05, thickness=0.003),
]


def test_barrowman_worked_example():
    a = Aero(EXAMPLE, 0.05, backend="constant", cd=0.5)
    assert fin_midchord_length(0.08, 0.04, 0.05, 0.04) == pytest.approx(0.05385, abs=1e-5)
    nose, fins = a.normal(0.0)
    assert nose == pytest.approx((2.0, 0.0699))
    assert fins[0] == pytest.approx(6.8268, abs=1e-4) and fins[1] == pytest.approx(0.55333, abs=1e-5)
    cn, xcp = a.cp(0.0)
    assert cn == pytest.approx(8.8268, abs=1e-4) and xcp == pytest.approx(0.44380, abs=1e-5)
    assert (xcp - 0.35) / 0.05 == pytest.approx(1.876, abs=1e-3)


def test_fin_lift_rises_with_mach():
    a = Aero(EXAMPLE, 0.05, backend="constant", cd=0.5)
    assert a.normal(0.6)[1][0] > a.normal(0.0)[1][0]
    assert a.cp(0.6)[1] > a.cp(0.0)[1]


def test_boattail_reduces_normal_force():
    comps = EXAMPLE[:2] + [dict(type="transition", position=0.6, length=0.05, fore_diameter=0.05, aft_diameter=0.04)]
    a = Aero(comps, 0.05, backend="constant", cd=0.5)
    cna, x = a.fixed[1]
    assert cna == pytest.approx(2 * (0.64 - 1.0)) and 0.6 < x < 0.65


@pytest.mark.parametrize("re,cf", [(1e5, 0.007344), (1e6, 0.004372), (1e7, 0.002898)])
def test_smooth_skin_friction(re, cf):
    assert skin_friction(re, 0.0, 0.0) == pytest.approx(cf, rel=1e-3)


def test_skin_friction_limits():
    assert skin_friction(5e3, 0.0, 0.0) == pytest.approx(0.0148)
    assert skin_friction(1.0001e4, 0.0, 0.0) == pytest.approx(0.0148, rel=5e-3)        # continuous at Re = 1e4
    rr = 60e-6 / 1.0
    recrit = 51 * rr ** -1.039
    assert skin_friction(recrit, rr, 0.0) == pytest.approx(0.032 * rr ** 0.2, rel=0.02)   # the branches meet
    assert skin_friction(1e9, rr, 0.0) == pytest.approx(0.032 * rr ** 0.2)               # roughness-limited
    assert skin_friction(1e6, 0.0, 0.5) == pytest.approx(skin_friction(1e6, 0.0, 0.0) * 0.975)


def test_base_drag_branches_meet_at_mach_one():
    assert base_drag(0.0) == pytest.approx(0.12)
    assert base_drag(1.0 - 1e-12) == pytest.approx(0.25) and base_drag(1.0) == pytest.approx(0.25)


def test_body_tube_only_friction_by_hand():
    comps = [dict(type="body", position=0.0, length=1.0, diameter=0.1)]
    a = Aero(comps, 0.1, backend="buildup", roughness=0.0)
    re, mach = 2e6, 0.2
    cf = skin_friction(re, 0.0, mach)
    expected = cf * (1 + 1 / (2 * 10.0)) * (math.pi * 0.1 * 1.0) / (math.pi * 0.05 ** 2)
    assert a.cd_buildup(mach, re, False, parts=True)["friction"] == pytest.approx(expected)
    assert a.cd_buildup(mach, re, False, parts=True)["base"] == pytest.approx(base_drag(mach))


def test_thrusting_lowers_base_drag(alpha):
    alpha["aero"] = dict(backend="buildup")
    v, _ = build(alpha)
    assert v.aero.cd(0.3, 5e5, True) < v.aero.cd(0.3, 5e5, False)


def test_lookup_backend_returns_table_values_and_holds_ends():
    a = Aero(EXAMPLE, 0.05, backend="lookup", cd_table=[[0.1, 0.5, 0.45], [0.5, 0.6, 0.55]])
    assert a.cd(0.1, 1e6, False) == pytest.approx(0.5) and a.cd(0.5, 1e6, True) == pytest.approx(0.55)
    assert a.cd(0.3, 1e6, False) == pytest.approx(0.55)
    assert a.cd(2.0, 1e6, False) == pytest.approx(0.6) and a.cd(0.0, 1e6, False) == pytest.approx(0.5)


def test_square_fin_edges_cost_drag(alpha):
    alpha["aero"] = dict(backend="buildup")
    v_round, _ = build(alpha)
    alpha["rocket"]["components"][2]["edge"] = "square"
    v_square, _ = build(alpha)
    cr, cs = v_round.aero.cd(0.3, 6e5, False), v_square.aero.cd(0.3, 6e5, False)
    assert cs > 1.2 * cr
    assert 0.3 < cr < 0.9


def test_subsonic_drag_falls_then_rises(alpha):
    alpha["aero"] = dict(backend="buildup")
    v, _ = build(alpha)
    f = lambda m: v.aero.cd(m, 1.2e6 * m, False)   # Reynolds number grows with speed
    assert f(0.1) > f(0.3) and f(0.85) > f(0.5)
