import math
import random

import pytest

from ark import quaternion as Q


def test_ninety_degrees_about_z_takes_x_to_y():
    q = Q.from_axis_angle((0, 0, 1), math.pi / 2)
    assert Q.rotate(q, (1, 0, 0)) == pytest.approx((0, 1, 0), abs=1e-12)
    assert Q.rotate_inv(q, (0, 1, 0)) == pytest.approx((1, 0, 0), abs=1e-12)


def test_conjugate_is_inverse_and_matrix_is_a_rotation():
    random.seed(1)
    for _ in range(20):
        q = Q.qnormalize(tuple(random.gauss(0, 1) for _ in range(4)))
        assert Q.qmul(q, Q.qconj(q)) == pytest.approx((1, 0, 0, 0), abs=1e-12)
        R = Q.rotmat(q)
        for i in range(3):
            for j in range(3):
                assert sum(R[i][k] * R[j][k] for k in range(3)) == pytest.approx(1.0 if i == j else 0.0, abs=1e-12)
        det = (R[0][0] * (R[1][1] * R[2][2] - R[1][2] * R[2][1]) - R[0][1] * (R[1][0] * R[2][2] - R[1][2] * R[2][0])
               + R[0][2] * (R[1][0] * R[2][1] - R[1][1] * R[2][0]))
        assert det == pytest.approx(1.0)
        q2 = Q.from_rotmat(R)
        s = 1.0 if sum(a * b for a, b in zip(q, q2)) > 0 else -1.0     # q and -q are the same rotation
        assert tuple(s * x for x in q2) == pytest.approx(q, abs=1e-9)


def test_product_composes_rotations():
    a = Q.from_axis_angle((0, 0, 1), 0.7); b = Q.from_axis_angle((1, 0, 0), -0.4)
    v = (0.3, -1.2, 2.0)
    assert Q.rotate(Q.qmul(a, b), v) == pytest.approx(Q.rotate(a, Q.rotate(b, v)), abs=1e-12)


def test_agrees_with_scipy_after_reordering():
    from scipy.spatial.transform import Rotation
    q = Q.qnormalize((0.3, -0.5, 0.2, 0.78))
    r = Rotation.from_quat([q[1], q[2], q[3], q[0]])       # SciPy is scalar-last
    assert tuple(r.apply([1.0, 2.0, 3.0])) == pytest.approx(Q.rotate(q, (1.0, 2.0, 3.0)), abs=1e-12)


@pytest.mark.parametrize("el,az", [(90, 0), (85, 0), (80, 45), (89, 181), (60, 270)])
def test_rail_attitude_points_the_nose_along_the_rail(el, az):
    q = Q.from_rail(el, az)
    assert Q.rotate(q, (1, 0, 0)) == pytest.approx(Q.rail_direction(el, az), abs=1e-12)
    assert Q.qnorm(q) == pytest.approx(1.0)


def test_rail_direction_convention():
    assert Q.rail_direction(90, 0) == pytest.approx((0, 0, 1), abs=1e-12)
    assert Q.rail_direction(0, 90) == pytest.approx((1, 0, 0), abs=1e-12)     # azimuth 90 is East
    assert Q.rail_direction(0, 0) == pytest.approx((0, 1, 0), abs=1e-12)      # azimuth 0 is North
