# Model notes

The equations the code solves, the conventions it uses, and the modelling choices behind them.
Symbols: m mass, I_a / I_t axial / transverse inertia, q attitude quaternion, w angular velocity (body frame).

## Frames and state
- Launch frame: x East, y North, z Up, origin at the pad. Flat, non-rotating Earth.
- Body frame: x along the axis towards the nose. Geometry is stored as distance from the nose tip (positive
  aft), so a point at station s sits at body x = x_cg - s.
- Quaternion: scalar first, Hamilton product, rotates body vectors into the launch frame.
- 6DOF state (13): position, velocity (launch frame), quaternion, angular velocity (body frame).
  Mass is not a state: m, x_cg, I_a and I_t are functions of time from the thrust curve.

## Equations of motion
    r' = v
    m v' = R(q) (F_thrust + F_aero)_body + m g(z)
    q' = 1/2 q (x) [0, w] + (1 - |q|^2) q            (the last term holds |q| at 1 between steps)
    I_t w_y' = M_y - (I_a - I_t) w_x w_z
    I_t w_z' = M_z - (I_t - I_a) w_x w_y
    w_x' = 0                                         (no roll moment is modelled)

## Aerodynamic forces
Air-relative velocity v_rel = v - wind, rotated into the body frame as (u, v_b, w_b); V = |v_rel|.
- Axial: F_x = -q_dyn A C_A u / V, with C_A the zero-incidence drag coefficient (build-up, table or constant).
- Normal: each Barrowman component i (nose, transitions, fin set) with slope C_Na,i at station x_i sees the
  local crossflow (v_b + w_z x_b,i , w_b - w_y x_b,i) and produces
  F_i = -q_dyn A C_Na,i (local crossflow) / V, applied at x_b,i.
  Summing the forces gives C_N = C_Na sin(alpha); summing the moments gives the static restoring moment
  q_dyn A C_Na (x_cp - x_cg) sin(alpha) and the pitch/yaw damping moment
  -1/2 rho V A sum_i C_Na,i (x_i - x_cg)^2 w  in one pass.
- Using sin(alpha) keeps the force bounded when an unstable rocket tumbles; body lift is neglected.
- Fin C_Na uses the Prandtl-Glauert factor inside the square root, held constant above Mach 0.8.

## Variable-mass terms
- Thrust comes from the measured curve; m_p(t) = m_p0 (1 - I(t)/I_total) (constant effective exhaust velocity).
- Inertia rate: moment -I_t' w on the transverse rates.
- Jet damping: moment -mdot (x_nozzle - x_cg)^2 w on the transverse rates.
- Both are switchable (`sim.jet_damping`, `sim.inertia_rate`). Their effect on apogee is under 0.2 m for
  all three reference rockets.

## Phases
pad (hold until thrust exceeds the weight component along the rail) -> rail (1D along the rail, drag from
the along-rail speed, wind ignored) -> powered (6DOF) -> coast (6DOF) -> descent (3DOF point mass under the
deployed parachutes, each ramping linearly to its full C_D S over its inflation time) -> landed.
Events (rail exit, burnout, apogee, altitude triggers, ground) are located by the integrator and each phase
starts from the previous phase's final state.

## Environment
- US Standard Atmosphere 1976 to 47 km, geometric -> geopotential conversion with r0 = 6356.766 km,
  optional temperature offset; or a sounding table (geopotential height, pressure, temperature, wind).
- Gravity: inverse square with R = 6371 km.
- Wind: none, constant, power law, table (interpolated in east/north components) or the sounding's own wind;
  optional gusts as a first-order Gauss-Markov process in time, generated once from the seed on a fixed
  50 ms grid. This is simpler than the full Dryden model.

## Numerics
- In-house fixed-step RK4 with events located by bisection on the step size; or SciPy RK45 / DOP853.
- The integration is restarted at burnout and at every event.
