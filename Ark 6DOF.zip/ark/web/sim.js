/* ark in the browser: a fixed-step RK4 port of the Python core's equations of motion
   (src/ark/dynamics.py, flight.py), used by the replay page for live "what if" flights.
   It reads a model exported by scripts/build_web.py. tests/test_web_model.py checks it against
   the Python core. Conventions are the same: launch frame East/North/Up, body x towards the nose,
   quaternion scalar-first body -> launch, stations in metres from the nose tip. */
(function (root) {
  "use strict";
  const G0 = 9.80665, R_AIR = 287.05287, GAMMA = 1.4, R_EARTH = 6371000, R0 = 6356766, GMR = G0 / R_AIR;
  const LAYERS = [[0, 288.15, -0.0065], [11000, 216.65, 0], [20000, 216.65, 0.001], [32000, 228.65, 0.0028], [47000, 270.65, 0]];
  const PB = [101325];
  for (let i = 0; i < LAYERS.length - 1; i++) {
    const [h0, T0, L] = LAYERS[i], h1 = LAYERS[i + 1][0];
    PB.push(L === 0 ? PB[i] * Math.exp(-GMR * (h1 - h0) / T0) : PB[i] * Math.pow((T0 + L * (h1 - h0)) / T0, -GMR / L));
  }
  const geop = z => R0 * z / (R0 + z);
  const suth = T => 1.458e-6 * Math.pow(T, 1.5) / (T + 110.4);
  function airOf(T, p) { return { T, p, rho: p / (R_AIR * T), a: Math.sqrt(GAMMA * R_AIR * T), mu: suth(T) }; }
  function isa(z, dT) {
    const h = Math.min(Math.max(geop(z), -5000), 46999);
    let i = 0; while (i < LAYERS.length - 2 && h >= LAYERS[i + 1][0]) i++;
    const [h0, T0, L] = LAYERS[i], T = T0 + L * (h - h0);
    const p = L === 0 ? PB[i] * Math.exp(-GMR * (h - h0) / T0) : PB[i] * Math.pow(T / T0, -GMR / L);
    return airOf(T + (dT || 0), p);
  }
  function interp(x, xs, ys) {
    const n = xs.length;
    if (x <= xs[0]) return ys[0];
    if (x >= xs[n - 1]) return ys[n - 1];
    let lo = 0, hi = n - 1;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (xs[m] <= x) lo = m; else hi = m; }
    return ys[lo] + (ys[hi] - ys[lo]) * (x - xs[lo]) / (xs[hi] - xs[lo]);
  }
  const windVec = (speed, fromDeg) => { const a = fromDeg * Math.PI / 180; return [-speed * Math.sin(a), -speed * Math.cos(a)]; };

  function makeEnv(m, o) {
    const e = m.env, s = e.sounding, w = m.wind;
    function air(z) {
      if (!s) return isa(z + e.elevation, e.dT);
      const h = geop(z + e.elevation), n = s.h.length, T = interp(h, s.h, s.T);
      let lnp;
      if (h < s.h[0]) lnp = s.lnp[0] - GMR * (h - s.h[0]) / s.T[0];
      else if (h > s.h[n - 1]) lnp = s.lnp[n - 1] - GMR * (h - s.h[n - 1]) / s.T[n - 1];
      else lnp = interp(h, s.h, s.lnp);
      return airOf(T, Math.exp(lnp));
    }
    const custom = o.windMode === "custom" ? windVec(o.windSpeed || 0, o.windFrom || 0) : null;
    function mean(z) {
      if (custom) return custom;
      if (w.model === "constant") return windVec(w.speed, w.direction);
      if (w.model === "power_law") return windVec(w.speed * Math.pow(Math.max(z, 1) / w.ref_height, w.exponent), w.direction);
      if (w.model === "sounding" && s) { const h = geop(z + e.elevation); return [interp(h, s.h, s.u), interp(h, s.h, s.v)]; }
      return [0, 0];
    }
    const dS = o.windSpeedOffset || 0, dD = o.windDirOffset || 0;
    function wind(z) {          // optional offsets on speed and direction, as the Python core's Monte Carlo applies them
      const m0 = mean(z); if (!dS && !dD) return m0;
      const sp = Math.hypot(m0[0], m0[1]);
      if (sp > 1e-9) return windVec(Math.max(0, sp + dS), Math.atan2(-m0[0], -m0[1]) * 180 / Math.PI + dD);
      return dS > 0 ? windVec(dS, (o.windFrom != null ? o.windFrom : w.direction || 0) + dD) : m0;
    }
    const g = z => G0 * Math.pow(R_EARTH / (R_EARTH + z + e.elevation), 2);
    return { air, wind, g };
  }

  function makeVehicle(m, o) {
    const mo = m.motor, ms = m.mass, ae = m.aero, env = makeEnv(m, o);
    const kI = o.impulseScale || 1, kCd = (o.dragScale || 1) * (ae.cd_scale || 1), kM = o.massScale || 1;
    function seg(t) { let lo = 0, hi = mo.t.length - 1; while (hi - lo > 1) { const k = (lo + hi) >> 1; if (mo.t[k] <= t) lo = k; else hi = k; } return lo; }
    function thrust(t) {
      if (t <= 0 || t >= mo.burn_time) return 0;
      const i = seg(t); return kI * (mo.f[i] + (mo.f[i + 1] - mo.f[i]) * (t - mo.t[i]) / (mo.t[i + 1] - mo.t[i]));
    }
    function burned(t) {   // fraction of total impulse delivered
      if (t <= 0) return 0; if (t >= mo.burn_time) return 1;
      const i = seg(t), dt = t - mo.t[i], sl = (mo.f[i + 1] - mo.f[i]) / (mo.t[i + 1] - mo.t[i]);
      return (mo.cum[i] + mo.f[i] * dt + 0.5 * sl * dt * dt) / mo.total_impulse;
    }
    const mdot = t => mo.propellant_mass * thrust(t) / (kI * mo.total_impulse);
    function massAt(t) {
      const mp = mo.propellant_mass * (1 - burned(t)), mass = kM * ms.m_dry + mp;
      const xcg = (kM * ms.s1 + mp * ms.xp) / mass;
      return [mass, xcg, kM * ms.Ia_dry + mp * ms.kp_a2, kM * ms.j + mp * (ms.kp_t2 + ms.xp * ms.xp) - mass * xcg * xcg];
    }
    const inertiaRate = t => { const h = 1e-3; return (massAt(t + h)[3] - massAt(Math.max(t - h, 0))[3]) / (h + Math.min(t, h)); };
    function cd(mach, thrusting) {
      if (ae.backend === "constant") return ae.cd * kCd;
      return interp(mach, ae.table.m, thrusting ? ae.table.on : ae.table.off) * kCd;
    }
    function normal(mach) {
      const mm = Math.min(mach, 0.8), beta = Math.sqrt(1 - mm * mm), out = ae.fixed.slice();
      for (const [n, cr, ct, s, sw, rb, xcp] of ae.fins) {
        const lf = Math.hypot(s, sw + ct / 2 - cr / 2), k = 1 + rb / (s + rb);
        out.push([k * 4 * n * Math.pow(s / ae.d_ref, 2) / (1 + Math.sqrt(1 + Math.pow(beta * 2 * lf / (cr + ct), 2))), xcp]);
      }
      return out;
    }
    const el = (o.railElevation != null ? o.railElevation : m.rail.elevation) * Math.PI / 180, az = (m.rail.azimuth + (o.azimuthOffset || 0)) * Math.PI / 180;
    const dir = [Math.cos(el) * Math.sin(az), Math.cos(el) * Math.cos(az), Math.sin(el)];

    function railDeriv(t, y) {
      const v = y[1], z = y[0] * dir[2], air = env.air(z), mass = massAt(t)[0];
      const drag = v > 1e-3 ? 0.5 * air.rho * v * v * ae.A_ref * cd(v / air.a, true) : 0;
      const a = (thrust(t) - drag) / mass - env.g(z) * dir[2];
      return (a < 0 && y[0] <= 0 && v <= 0) ? [0, 0] : [v, a];
    }
    function body(y, t) {   // air-relative velocity in the body frame, plus the rotation matrix
      const n = Math.hypot(y[6], y[7], y[8], y[9]), a0 = y[6] / n, a1 = y[7] / n, a2 = y[8] / n, a3 = y[9] / n;
      const w = env.wind(y[2]), rx = y[3] - w[0], ry = y[4] - w[1], rz = y[5];
      const R = [1 - 2 * (a2 * a2 + a3 * a3), 2 * (a1 * a2 - a0 * a3), 2 * (a1 * a3 + a0 * a2),
                 2 * (a1 * a2 + a0 * a3), 1 - 2 * (a1 * a1 + a3 * a3), 2 * (a2 * a3 - a0 * a1),
                 2 * (a1 * a3 - a0 * a2), 2 * (a2 * a3 + a0 * a1), 1 - 2 * (a1 * a1 + a2 * a2)];
      const ub = R[0] * rx + R[3] * ry + R[6] * rz, vb = R[1] * rx + R[4] * ry + R[7] * rz, wb = R[2] * rx + R[5] * ry + R[8] * rz;
      return { R, ub, vb, wb, V: Math.hypot(ub, vb, wb), n2: n * n };
    }
    function deriv6(t, y) {
      const b = body(y, t), R = b.R, [mass, xcg, Ia, It] = massAt(t), air = env.air(y[2]);
      const wx = y[10], wy = y[11], wz = y[12], thrusting = t < mo.burn_time;
      let Fx = 0, Fy = 0, Fz = 0, My = 0, Mz = 0;
      if (b.V > 1e-3) {
        const mach = b.V / air.a, qA = 0.5 * air.rho * b.V * b.V * ae.A_ref;
        Fx = -qA * cd(mach, thrusting) * b.ub / b.V;
        for (const [cna, xs] of normal(mach)) {
          const xb = xcg - xs, fy = -qA * cna * (b.vb + wz * xb) / b.V, fz = -qA * cna * (b.wb - wy * xb) / b.V;
          Fy += fy; Fz += fz; My -= xb * fz; Mz += xb * fy;
        }
      }
      const T = thrust(t);
      if (T > 0) {
        Fx += T;
        if (m.jet_damping) { const c = mdot(t) * Math.pow(ms.nozzle - xcg, 2); My -= c * wy; Mz -= c * wz; }
      }
      if (m.inertia_rate && thrusting) { const di = inertiaRate(t); My -= di * wy; Mz -= di * wz; }
      const k = 1 - b.n2, q0 = y[6], q1 = y[7], q2 = y[8], q3 = y[9];
      return [y[3], y[4], y[5],
        (R[0] * Fx + R[1] * Fy + R[2] * Fz) / mass, (R[3] * Fx + R[4] * Fy + R[5] * Fz) / mass, (R[6] * Fx + R[7] * Fy + R[8] * Fz) / mass - env.g(y[2]),
        -0.5 * (q1 * wx + q2 * wy + q3 * wz) + k * q0, 0.5 * (q0 * wx + q2 * wz - q3 * wy) + k * q1,
        0.5 * (q0 * wy + q3 * wx - q1 * wz) + k * q2, 0.5 * (q0 * wz + q1 * wy - q2 * wx) + k * q3,
        0, (My - (Ia - It) * wx * wz) / It, (Mz - (It - Ia) * wx * wy) / It];
    }
    function observe(t, y) {
      const b = body(y, t), air = env.air(Math.max(y[2], 0));
      return { alpha: b.V > 1e-3 ? Math.atan2(Math.hypot(b.vb, b.wb), b.ub) * 180 / Math.PI : 0, mach: b.V / air.a, thrust: thrust(t), q: 0.5 * air.rho * b.V * b.V };
    }
    return { env, dir, el, az, thrust, massAt, railDeriv, deriv6, observe, burn: mo.burn_time };
  }

  function rk4(f, t, y, h) {
    const n = y.length, k1 = f(t, y), y2 = new Array(n), y3 = new Array(n), y4 = new Array(n), out = new Array(n);
    for (let i = 0; i < n; i++) y2[i] = y[i] + h / 2 * k1[i];
    const k2 = f(t + h / 2, y2); for (let i = 0; i < n; i++) y3[i] = y[i] + h / 2 * k2[i];
    const k3 = f(t + h / 2, y3); for (let i = 0; i < n; i++) y4[i] = y[i] + h * k3[i];
    const k4 = f(t + h, y4); for (let i = 0; i < n; i++) out[i] = y[i] + h / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]);
    return out;
  }
  const lerp = (a, b, f) => a.map((v, i) => v + (b[i] - v) * f);
  function railQuat(el, az) {   // body x along the rail; body z as close to Up as possible (North if vertical)
    const x = [Math.cos(el) * Math.sin(az), Math.cos(el) * Math.cos(az), Math.sin(el)];
    const ref = Math.abs(x[2]) < 0.999999 ? [0, 0, 1] : [0, 1, 0], d = ref[0] * x[0] + ref[1] * x[1] + ref[2] * x[2];
    let z = ref.map((r, i) => r - d * x[i]); const zn = Math.hypot(...z); z = z.map(v => v / zn);
    const y = [z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0]];
    const a = x[0], b = y[0], c = z[0], dd = x[1], e = y[1], f = z[1], g = x[2], h = y[2], i = z[2], tr = a + e + i;
    let q;
    if (tr > 0) { const s = Math.sqrt(tr + 1) * 2; q = [0.25 * s, (h - f) / s, (c - g) / s, (dd - b) / s]; }
    else if (a > e && a > i) { const s = Math.sqrt(1 + a - e - i) * 2; q = [(h - f) / s, 0.25 * s, (b + dd) / s, (c + g) / s]; }
    else if (e > i) { const s = Math.sqrt(1 + e - a - i) * 2; q = [(c - g) / s, (b + dd) / s, 0.25 * s, (f + h) / s]; }
    else { const s = Math.sqrt(1 + i - a - e) * 2; q = [(dd - b) / s, (c + g) / s, (f + h) / s, 0.25 * s]; }
    const n = Math.hypot(...q); return q.map(v => v / n);
  }

  /* Fly one rocket. o: { windMode: 'recorded' | 'custom', windSpeed, windFrom, railElevation, dragScale, impulseScale, massScale,
     windSpeedOffset, windDirOffset, azimuthOffset, cdsScale, fast }. With fast: true only the summary is returned (for Monte Carlo). */
  function simulate(m, o) {
    o = o || {};
    const v = makeVehicle(m, o), fast = !!o.fast;
    const S = { t: [], x: [], y: [], z: [], vx: [], vy: [], vz: [], q0: [], q1: [], q2: [], q3: [], alpha_deg: [], mach: [], thrust: [], qdyn: [], phase: [], speed: [] };
    const events = [], qRail = railQuat(v.el, v.az), qUp = railQuat(Math.PI / 2, 0);
    const push = (t, p, vel, q, ph, ob) => {
      if (fast) return;
      S.vx.push(vel[0]); S.vy.push(vel[1]); S.vz.push(vel[2]); S.qdyn.push(ob.q || 0);
      S.t.push(t); S.x.push(p[0]); S.y.push(p[1]); S.z.push(p[2]); S.q0.push(q[0]); S.q1.push(q[1]); S.q2.push(q[2]); S.q3.push(q[3]);
      S.alpha_deg.push(ob.alpha); S.mach.push(ob.mach); S.thrust.push(ob.thrust); S.phase.push(ph); S.speed.push(Math.hypot(vel[0], vel[1], vel[2]));
    };
    const sum = { max_speed: 0, max_mach: 0 };
    // pad
    const excess = t => v.thrust(t) - v.massAt(t)[0] * v.env.g(0) * v.dir[2];
    let tlo = null;
    for (let i = 0; i < 4000; i++) { const b = v.burn * (i + 1) / 4000; if (excess(b) > 0) { let lo = v.burn * i / 4000, hi = b; for (let k = 0; k < 50; k++) { const md = 0.5 * (lo + hi); if (excess(md) <= 0) lo = md; else hi = md; } tlo = hi; break; } }
    if (tlo === null) return { failed: "Thrust never exceeds weight: the rocket stays on the pad." };
    push(0, [0, 0, 0], [0, 0, 0], qRail, 0, { alpha: 0, mach: 0, thrust: 0 });
    events.push({ name: "liftoff", t: tlo });
    // rail
    let t = tlo, yr = [0, 0], n = 0; const hr = 0.0005, Lr = m.rail.length;
    for (;;) {
      const y1 = rk4(v.railDeriv, t, yr, hr);
      if (y1[0] >= Lr) { const f = (Lr - yr[0]) / (y1[0] - yr[0]); t += f * hr; yr = lerp(yr, y1, f); break; }
      t += hr; yr = y1;
      if (++n % 40 === 0) push(t, v.dir.map(d => d * yr[0]), v.dir.map(d => d * yr[1]), qRail, 1, { alpha: 0, mach: yr[1] / v.env.air(0).a, thrust: v.thrust(t) });
      if (t > tlo + 30) return { failed: "The rocket did not clear the rail." };
    }
    let y = [v.dir[0] * yr[0], v.dir[1] * yr[0], v.dir[2] * yr[0], v.dir[0] * yr[1], v.dir[1] * yr[1], v.dir[2] * yr[1], qRail[0], qRail[1], qRail[2], qRail[3], 0, 0, 0];
    sum.rail_exit_speed = yr[1]; sum.rail_exit_alpha = v.observe(t, y).alpha;
    events.push({ name: "rail_exit", t });
    // free flight (6DOF)
    const rec = (m.recovery || []).map(r => Object.assign({ lag: 0, inflation_time: 0.5 }, r, { cds: r.cds * (o.cdsScale || 1) }));
    const apoDev = rec.filter(r => r.trigger === "apogee"), altDev = rec.filter(r => r.trigger !== "apogee");
    const h6 = fast ? 0.004 : 0.002; let zmax = 0, tzmax = t, tAp = null, tSwitch = Infinity, landed = false, burnt = t >= v.burn; n = 0;
    const store6 = (ph) => { if (fast) return; const ob = v.observe(t, y); push(t, y, [y[3], y[4], y[5]], [y[6], y[7], y[8], y[9]], ph, ob); };
    store6(2);
    for (;;) {
      let h = h6;
      if (!burnt && t + h >= v.burn) h = v.burn - t;
      if (t + h >= tSwitch) h = tSwitch - t;
      let y1 = h > 0 ? rk4(v.deriv6, t, y, h) : y;
      const qn = Math.hypot(y1[6], y1[7], y1[8], y1[9]); for (let i = 6; i < 10; i++) y1[i] /= qn;
      if (y1[2] < 0 && y[2] >= 0 && h > 0) { const f = y[2] / (y[2] - y1[2]); t += f * h; y = lerp(y, y1, f); landed = true; store6(tAp === null && !burnt ? 2 : 3); break; }
      if (tAp === null && y[5] > 0 && y1[5] <= 0) {
        const f = y[5] / (y[5] - y1[5]), ya = lerp(y, y1, f); tAp = t + f * h;
        events.push({ name: "apogee", t: tAp, altitude: ya[2], x: ya[0], y: ya[1] });
        sum.apogee = ya[2]; sum.apogee_time = tAp;
        if (apoDev.length) tSwitch = tAp + Math.min(...apoDev.map(r => r.lag));
      }
      t += h; y = y1;
      if (y[2] > zmax) { zmax = y[2]; tzmax = t; }
      const sp = Math.hypot(y[3], y[4], y[5]); if (sp > sum.max_speed) sum.max_speed = sp;
      if (!burnt && t >= v.burn - 1e-12) { burnt = true; events.push({ name: "burnout", t, altitude: y[2] }); store6(3); }
      if (++n % 10 === 0 && !fast) { store6(burnt ? 3 : 2); const mc = S.mach[S.mach.length - 1]; if (mc > sum.max_mach) sum.max_mach = mc; }
      if (t >= tSwitch - 1e-12) break;
      if (tAp !== null && !apoDev.length && altDev.length && y[2] <= Math.max(...altDev.map(r => r.trigger))) break;
      if (t > 900) return { failed: "The flight did not end." };
    }
    if (sum.apogee == null) { sum.apogee = zmax; sum.apogee_time = tzmax; }
    // parachute descent (3DOF)
    if (!landed && rec.length) {
      store6(3);
      const mass = v.massAt(t)[0], deployed = [], scheduled = apoDev.map(r => [tAp + r.lag, r]), pending = altDev.slice();
      const cds = tt => { let s = 1e-9; for (const [td, r] of deployed) s += r.cds * (r.inflation_time <= 0 ? 1 : Math.min(Math.max((tt - td) / r.inflation_time, 0), 1)); return s; };
      const f3 = (tt, s) => { const z = Math.max(s[2], 0), air = v.env.air(z), w = v.env.wind(z), rx = s[3] - w[0], ry = s[4] - w[1], rz = s[5], k = 0.5 * air.rho * Math.hypot(rx, ry, rz) * cds(tt) / mass; return [s[3], s[4], s[5], -k * rx, -k * ry, -k * rz - v.env.g(z)]; };
      let s = y.slice(0, 6); const hd = 0.02; n = 0;
      for (;;) {
        for (let i = pending.length - 1; i >= 0; i--) if (s[2] <= pending[i].trigger) { scheduled.push([t + pending[i].lag, pending[i]]); pending.splice(i, 1); }
        for (let i = scheduled.length - 1; i >= 0; i--) if (scheduled[i][0] <= t + 1e-9) { deployed.push([t, scheduled[i][1]]); events.push({ name: "deploy:" + (scheduled[i][1].name || "parachute"), t }); scheduled.splice(i, 1); }
        let h = hd; for (const [td] of scheduled) if (t + h > td) h = Math.max(td - t, 1e-6);
        const s1 = rk4(f3, t, s, h);
        if (s1[2] <= 0) { const f = s[2] / (s[2] - s1[2]); t += f * h; s = lerp(s, s1, f); break; }
        t += h; s = s1;
        if (++n % 2 === 0 && !fast) { const air = v.env.air(Math.max(s[2], 0)); push(t, s, [s[3], s[4], s[5]], qUp, 4, { alpha: 0, mach: Math.hypot(s[3], s[4], s[5]) / air.a, thrust: 0 }); }
        if (t > 3600) return { failed: "The descent did not end." };
      }
      y = s;
    }
    push(t, [y[0], y[1], 0], [y[3], y[4], y[5]], rec.length && !landed ? qUp : [y[6] || qUp[0], y[7] || qUp[1], y[8] || qUp[2], y[9] || qUp[3]], 5, { alpha: 0, mach: 0, thrust: 0 });
    events.push({ name: "landing", t, x: y[0], y: y[1] });
    for (let i = 0; i < S.t.length; i++) if (S.t[i] > sum.apogee_time) S.alpha_deg[i] = 0;
    sum.landing_x = y[0]; sum.landing_y = y[1]; sum.landing_distance = Math.hypot(y[0], y[1]); sum.flight_time = t; sum.impact_speed = Math.hypot(y[3], y[4], y[5]);
    events.sort((a, b) => a.t - b.t);
    return { samples: S, events, summary: sum };
  }
  function windAt(m, o, z) { const w = makeEnv(m, o || {}).wind(z); return { east: w[0], north: w[1], speed: Math.hypot(w[0], w[1]), from: (Math.atan2(-w[0], -w[1]) * 180 / Math.PI + 360) % 360 }; }

  const api = { simulate, windAt, isa, env: makeEnv };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.ArkSim = api;
})(typeof window !== "undefined" ? window : globalThis);
