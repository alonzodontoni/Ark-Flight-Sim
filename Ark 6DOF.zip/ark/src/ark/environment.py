"""Atmosphere, gravity and wind.

`isa` is the US Standard Atmosphere 1976 up to 47 km. `Environment` wraps an
atmosphere (standard or a sounding table), gravity and a wind model behind
one interface that takes height above the launch pad.
"""
from __future__ import annotations

import math
from bisect import bisect_right
from collections import namedtuple

import numpy as np

from .units import DEG, G0, GAMMA, R0_GEOPOT, R_AIR, R_EARTH

Air = namedtuple("Air", "T p rho a mu")

# (base geopotential height m, base temperature K, lapse rate K/m)
_LAYERS = [(0.0, 288.15, -0.0065), (11000.0, 216.65, 0.0), (20000.0, 216.65, 0.001),
           (32000.0, 228.65, 0.0028), (47000.0, 270.65, 0.0)]
_GMR = G0 / R_AIR


def _base_pressures():
    p = [101325.0]
    for (h0, T0, L), (h1, _, _) in zip(_LAYERS[:-1], _LAYERS[1:]):
        if L == 0.0:
            p.append(p[-1] * math.exp(-_GMR * (h1 - h0) / T0))
        else:
            p.append(p[-1] * ((T0 + L * (h1 - h0)) / T0) ** (-_GMR / L))
    return p


_PB = _base_pressures()
_HB = [l[0] for l in _LAYERS]


def geopotential(z: float) -> float:
    """Geometric altitude above sea level -> geopotential altitude."""
    return R0_GEOPOT * z / (R0_GEOPOT + z)


def sutherland(T: float) -> float:
    return 1.458e-6 * T ** 1.5 / (T + 110.4)


def isa(z: float, dT: float = 0.0) -> Air:
    """US Standard Atmosphere 1976 at geometric altitude z (m above sea level).

    dT is a temperature offset: pressure keeps the standard profile and the
    offset is applied to temperature, so density is p / (R (T + dT)).
    """
    h = geopotential(z)
    if h < -5000.0 or h > 47000.0:
        raise ValueError(f"altitude {z:.0f} m is outside the atmosphere model (-5 to 47 km)")
    i = max(0, bisect_right(_HB, h) - 1)
    i = min(i, len(_LAYERS) - 2)
    h0, T0, L = _LAYERS[i]
    T = T0 + L * (h - h0)
    if L == 0.0:
        p = _PB[i] * math.exp(-_GMR * (h - h0) / T0)
    else:
        p = _PB[i] * (T / T0) ** (-_GMR / L)
    Tt = T + dT
    return Air(Tt, p, p / (R_AIR * Tt), math.sqrt(GAMMA * R_AIR * Tt), sutherland(Tt))


def gravity(z: float) -> float:
    """Inverse-square gravity at geometric altitude z above sea level."""
    return G0 * (R_EARTH / (R_EARTH + z)) ** 2


class Sounding:
    """Atmosphere from a table of geopotential height, pressure and temperature.

    Temperature is interpolated linearly and pressure log-linearly. Outside the
    table the end temperature is held and pressure follows the hydrostatic law.
    May also carry wind components (east, north).
    """

    def __init__(self, h, p, T, u=None, v=None):
        o = np.argsort(h)
        self.h = np.asarray(h, float)[o]; self.lnp = np.log(np.asarray(p, float)[o]); self.T = np.asarray(T, float)[o]
        self.u = None if u is None else np.asarray(u, float)[o]
        self.v = None if v is None else np.asarray(v, float)[o]

    @classmethod
    def from_csv(cls, path):
        d = np.loadtxt(path, delimiter=",", comments="#")
        return cls(d[:, 0], d[:, 1], d[:, 2], d[:, 3] if d.shape[1] > 3 else None, d[:, 4] if d.shape[1] > 4 else None)

    def air(self, z: float) -> Air:
        h = geopotential(z)
        T = float(np.interp(h, self.h, self.T))
        if h < self.h[0]:
            lnp = self.lnp[0] - _GMR * (h - self.h[0]) / self.T[0]
        elif h > self.h[-1]:
            lnp = self.lnp[-1] - _GMR * (h - self.h[-1]) / self.T[-1]
        else:
            lnp = float(np.interp(h, self.h, self.lnp))
        p = math.exp(lnp)
        return Air(T, p, p / (R_AIR * T), math.sqrt(GAMMA * R_AIR * T), sutherland(T))

    def wind(self, z: float):
        h = geopotential(z)
        return float(np.interp(h, self.h, self.u)), float(np.interp(h, self.h, self.v))


def wind_vector(speed: float, direction_from_deg: float):
    """Meteorological wind (speed, direction it blows FROM, clockwise from north) -> (east, north)."""
    a = direction_from_deg * DEG
    return -speed * math.sin(a), -speed * math.cos(a)


class Wind:
    """Mean wind profile plus optional pre-generated gusts.

    model: 'none', 'constant', 'power_law', 'table' or 'sounding'.
    Heights are above ground. Gusts are a first-order Gauss-Markov process in
    time per axis, generated once from the seed on a fixed grid so that the
    result does not depend on the integrator's step choices.
    """

    def __init__(self, model="none", speed=0.0, direction=0.0, ref_height=10.0, exponent=1.0 / 7.0,
                 table=None, sounding=None, elevation=0.0, gust=None, seed=0, t_max=600.0,
                 speed_offset=0.0, direction_offset=0.0):
        self.model = model
        self.speed = speed; self.direction = direction
        self.ref_height = ref_height; self.exponent = exponent
        self.sounding = sounding; self.elevation = elevation
        self.speed_offset = speed_offset; self.direction_offset = direction_offset
        if model == "table":
            t = np.asarray(table, float)
            o = np.argsort(t[:, 0])
            self.tz = t[o, 0]
            en = np.array([wind_vector(s, d) for s, d in t[o, 1:3]])
            self.te, self.tn = en[:, 0], en[:, 1]
        self.gust = None
        if gust and gust.get("sigma", 0.0) > 0.0:
            dt = 0.05
            n = int(t_max / dt) + 2
            tau = float(gust.get("tau", 3.0))
            phi = math.exp(-dt / tau)
            rng = np.random.default_rng(seed)
            sig = float(gust["sigma"]) * np.array([1.0, 1.0, float(gust.get("vertical_ratio", 0.5))])
            g = np.zeros((n, 3))
            g[0] = rng.standard_normal(3) * sig
            eta = rng.standard_normal((n, 3))
            for k in range(1, n):
                g[k] = phi * g[k - 1] + sig * math.sqrt(1.0 - phi * phi) * eta[k]
            self.gust = g; self.gdt = dt

    def mean(self, z: float):
        m = self.model
        if m == "none":
            e = n = 0.0
        elif m == "constant":
            e, n = wind_vector(self.speed, self.direction)
        elif m == "power_law":
            s = self.speed * (max(z, 1.0) / self.ref_height) ** self.exponent
            e, n = wind_vector(s, self.direction)
        elif m == "table":
            e = float(np.interp(z, self.tz, self.te)); n = float(np.interp(z, self.tz, self.tn))
        elif m == "sounding":
            e, n = self.sounding.wind(z + self.elevation)
        else:
            raise ValueError(f"unknown wind model {m!r}")
        if self.speed_offset or self.direction_offset:
            s = math.hypot(e, n)
            if s > 1e-9:
                d = math.atan2(-e, -n) / DEG + self.direction_offset
                e, n = wind_vector(max(0.0, s + self.speed_offset), d)
            elif self.speed_offset > 0:
                e, n = wind_vector(self.speed_offset, self.direction + self.direction_offset)
        return e, n

    def __call__(self, z: float, t: float):
        e, n = self.mean(z)
        if self.gust is None:
            return e, n, 0.0
        x = max(t, 0.0) / self.gdt
        i = min(int(x), len(self.gust) - 2)
        f = min(x - i, 1.0)
        g0 = self.gust[i]; g1 = self.gust[i + 1]
        return (e + g0[0] + f * (g1[0] - g0[0]), n + g0[1] + f * (g1[1] - g0[1]), g0[2] + f * (g1[2] - g0[2]))


class Environment:
    """Air, gravity and wind as functions of height above the launch pad."""

    def __init__(self, elevation=0.0, temperature_offset=0.0, wind=None, sounding=None,
                 constant_density=None, constant_gravity=False):
        self.elevation = elevation; self.dT = temperature_offset
        self.wind = wind or Wind()
        self.sounding = sounding
        self.constant_density = constant_density
        self.constant_gravity = constant_gravity
        self._air0 = self._air(0.0)

    def _air(self, z_agl):
        if self.sounding is not None:
            return self.sounding.air(z_agl + self.elevation)
        return isa(z_agl + self.elevation, self.dT)

    def air(self, z_agl: float) -> Air:
        if self.constant_density is not None:
            a = self._air0
            return Air(a.T, a.p, self.constant_density, a.a, a.mu)
        return self._air(z_agl)

    def g(self, z_agl: float) -> float:
        return G0 if self.constant_gravity else gravity(z_agl + self.elevation)
