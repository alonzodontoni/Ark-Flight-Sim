"""Aerodynamics: Barrowman normal force / centre of pressure and a drag build-up.

Formulas follow Barrowman (1967) and Niskanen's OpenRocket technical
documentation, chapter 3. The model is subsonic-first: the transonic and
supersonic branches are implemented but not validated in this project.
All coefficients are referenced to A_ref = pi d_ref^2 / 4.
"""
from __future__ import annotations

import math

import numpy as np

from .geometry import frustum_profile, nose_profile, rocket_length, shell_properties

_NOSE_CP = {"cone": 2.0 / 3.0, "ogive": 0.466, "parabolic": 0.5, "ellipsoid": 1.0 / 3.0}


def fin_midchord_length(cr, ct, span, sweep):
    return math.hypot(span, sweep + ct / 2.0 - cr / 2.0)


def fin_cna(n, cr, ct, span, sweep, body_radius, d_ref, beta=1.0):
    """Barrowman fin-set normal force slope (per rad), with fin-body interference."""
    lf = fin_midchord_length(cr, ct, span, sweep)
    k = 1.0 + body_radius / (span + body_radius)
    return k * 4.0 * n * (span / d_ref) ** 2 / (1.0 + math.sqrt(1.0 + (beta * 2.0 * lf / (cr + ct)) ** 2))


def fin_cp(position, cr, ct, sweep):
    return position + sweep * (cr + 2 * ct) / (3.0 * (cr + ct)) + ((cr + ct) - cr * ct / (cr + ct)) / 6.0


def skin_friction(re: float, rel_roughness: float, mach: float) -> float:
    """Turbulent skin friction coefficient with roughness limit and compressibility correction."""
    if re < 1.0e4:
        cf = 1.48e-2
    else:
        cf = 1.0 / (1.50 * math.log(re) - 5.6) ** 2
    cf_rough = 0.032 * rel_roughness ** 0.2 if rel_roughness > 0.0 else 0.0
    if mach < 1.0:
        c = 1.0 - 0.1 * mach * mach
        return max(cf * c, cf_rough * c)
    return max(cf / (1.0 + 0.15 * mach * mach) ** 0.58, cf_rough / (1.0 + 0.18 * mach * mach))


def base_drag(mach: float) -> float:
    return 0.12 + 0.13 * mach * mach if mach < 1.0 else 0.25 / mach


def stagnation_ratio(mach: float) -> float:
    if mach < 1.0:
        return 1.0 + mach ** 2 / 4.0 + mach ** 4 / 40.0
    return 1.84 - 0.76 / mach ** 2 + 0.166 / mach ** 4 + 0.035 / mach ** 6


def leading_edge_drag(mach: float, rounded: bool) -> float:
    if not rounded:
        return 0.85 * stagnation_ratio(mach)
    if mach < 0.9:
        return (1.0 - mach * mach) ** -0.417 - 1.0
    if mach < 1.0:
        return 1.0 - 1.785 * (mach - 0.9)
    return 1.214 - 0.502 / mach ** 2 + 0.1095 / mach ** 4


class Aero:
    """Aerodynamic coefficients for one rocket.

    backend: 'buildup' (drag from geometry), 'constant' (one C_d) or
    'lookup' (table of Mach against C_d, optionally separate power-on values).
    Normal force and centre of pressure always come from Barrowman.
    """

    def __init__(self, components, d_ref, backend="buildup", cd=None, cd_table=None, roughness=60e-6,
                 extra_cd=0.0, cd_scale=1.0, nozzle_diameter=None):
        self.d_ref = d_ref
        self.A_ref = math.pi * d_ref * d_ref / 4.0
        self.backend = backend
        self.cd_const = cd
        self.cd_scale = cd_scale
        self.extra_cd = extra_cd
        self.length = rocket_length(components)
        self.rel_rough = roughness / self.length if self.length > 0 else 0.0
        if backend == "lookup":
            t = np.asarray(cd_table, float)
            self.tm = t[:, 0]; self.tcd_off = t[:, 1]; self.tcd_on = t[:, 2] if t.shape[1] > 2 else t[:, 1]
        elif backend == "constant" and cd is None:
            raise ValueError("aero backend 'constant' needs a cd value")
        # --- Barrowman pieces: fixed (cna, x) and fin sets (Mach dependent)
        self.fixed = []
        self.fins = []
        wet_body = 0.0; wet_fins = 0.0; self.fin_front = []; press = []
        max_d = d_ref
        aft_d = self._base_diameter(components, d_ref)
        for c in components:
            t = c["type"]
            if t == "nose":
                L, R = c["length"], c["diameter"] / 2.0
                shape = c.get("shape", "ogive")
                self.fixed.append((2.0 * (c["diameter"] / d_ref) ** 2, _NOSE_CP[shape] * L))
                wet_body += shell_properties(nose_profile(shape, L, R), L)[0]
                if shape == "cone":
                    press.append(0.8 * math.sin(math.atan(R / L)) ** 2 * (c["diameter"] / d_ref) ** 2)
                max_d = max(max_d, c["diameter"])
            elif t == "body":
                wet_body += math.pi * c["diameter"] * c["length"]
                max_d = max(max_d, c["diameter"])
            elif t == "transition":
                d0, d1, L = c["fore_diameter"], c["aft_diameter"], c["length"]
                cna = 2.0 * ((d1 / d_ref) ** 2 - (d0 / d_ref) ** 2)
                x = c["position"] + L / 3.0 * (1.0 + (1.0 - d0 / d1) / (1.0 - (d0 / d1) ** 2))
                self.fixed.append((cna, x))
                wet_body += shell_properties(frustum_profile(L, d0 / 2.0, d1 / 2.0), L)[0]
                if d1 < d0:   # boattail: part of the base drag is recovered on a long taper
                    g = L / (d0 - d1)
                    gam = 1.0 if g < 1.0 else (3.0 - g) / 2.0 if g < 3.0 else 0.0
                    self._boattail = getattr(self, "_boattail", 0.0) + gam * (d0 * d0 - d1 * d1) / (d_ref * d_ref)
                elif d1 > d0:
                    press.append(0.8 * math.sin(math.atan((d1 - d0) / (2 * L))) ** 2 * (d1 * d1 - d0 * d0) / (d_ref * d_ref))
            elif t == "fins":
                n, cr, ct, s = c["count"], c["root_chord"], c["tip_chord"], c["span"]
                sw = c.get("sweep", 0.0); rb = c.get("body_diameter", d_ref) / 2.0
                self.fins.append((n, cr, ct, s, sw, rb, fin_cp(c["position"], cr, ct, sw)))
                wet_fins += 2.0 * n * 0.5 * (cr + ct) * s
                th = c.get("thickness", 0.003)
                self._tc = 2.0 * th / (0.5 * (cr + ct))
                edge = c.get("edge", "rounded")
                cosg2 = s * s / (s * s + sw * sw)
                self.fin_front.append((n * th * s / self.A_ref, edge, cosg2))
        self.wet_body = wet_body; self.wet_fins = wet_fins
        self.press_const = sum(press)
        self.boattail = getattr(self, "_boattail", 0.0)
        self.tc = getattr(self, "_tc", 0.0)
        self.fineness = self.length / max_d if max_d > 0 else 10.0
        self.base_ratio = (aft_d / d_ref) ** 2
        dn = nozzle_diameter if nozzle_diameter is not None else 0.0
        self.nozzle_ratio = min((dn / d_ref) ** 2, self.base_ratio)

    @staticmethod
    def _base_diameter(components, d_ref):
        """Diameter at the aft end of the aft-most body, transition or nose."""
        best, d = -1.0, d_ref
        for k in components:
            if k["type"] == "nose":
                st, dk = k["length"], k["diameter"]
            elif k["type"] == "body":
                st, dk = k["position"] + k["length"], k["diameter"]
            elif k["type"] == "transition":
                st, dk = k["position"] + k["length"], k["aft_diameter"]
            else:
                continue
            if st > best:
                best, d = st, dk
        return d

    # ---- normal force
    def normal(self, mach: float):
        """List of (C_N_alpha, x_cp) per component at this Mach number."""
        m = min(mach, 0.8)                      # Prandtl-Glauert, held above Mach 0.8 (not validated beyond)
        beta = math.sqrt(1.0 - m * m)
        out = list(self.fixed)
        for n, cr, ct, s, sw, rb, xcp in self.fins:
            out.append((fin_cna(n, cr, ct, s, sw, rb, self.d_ref, beta), xcp))
        return out

    def cp(self, mach: float = 0.0):
        comps = self.normal(mach)
        cn = sum(c for c, _ in comps)
        return cn, sum(c * x for c, x in comps) / cn

    # ---- axial force
    def cd_buildup(self, mach: float, re: float, thrusting: bool, parts: bool = False):
        cf = skin_friction(re, self.rel_rough, mach)
        friction = cf * ((1.0 + 1.0 / (2.0 * self.fineness)) * self.wet_body
                         + (1.0 + self.tc) * self.wet_fins) / self.A_ref
        cb = base_drag(mach)
        base = cb * (self.base_ratio - (self.nozzle_ratio if thrusting else 0.0)) + cb * self.boattail
        fin = 0.0
        for area_ratio, edge, cosg2 in self.fin_front:
            le = leading_edge_drag(mach, edge in ("rounded", "airfoil")) * cosg2
            te = cb if edge == "square" else 0.5 * cb if edge == "rounded" else 0.0
            fin += area_ratio * (le + te)
        if parts:
            return dict(friction=friction, base=base, fins=fin, pressure=self.press_const, extra=self.extra_cd)
        return friction + base + fin + self.press_const + self.extra_cd

    def cd(self, mach: float, re: float, thrusting: bool) -> float:
        b = self.backend
        if b == "constant":
            c = self.cd_const
        elif b == "lookup":
            c = float(np.interp(mach, self.tm, self.tcd_on if thrusting else self.tcd_off))
        else:
            c = self.cd_buildup(mach, re, thrusting)
        return c * self.cd_scale
