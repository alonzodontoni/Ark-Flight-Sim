"""Load and validate a run configuration, and build the objects a flight needs."""
from __future__ import annotations

import copy
import math
from pathlib import Path

import yaml

from .aero import Aero
from .dynamics import Vehicle
from .environment import Environment, Sounding, Wind
from .geometry import NOSE_SHAPES, rocket_length
from .massprops import MassModel
from .motor import Motor, load_eng


class ConfigError(ValueError):
    pass


_SCHEMA = {
    "rocket": {"name", "reference_diameter", "components", "rail_button_aft", "recovery", "notes"},
    "motor": {"eng_file", "nozzle_position", "propellant_mass", "case_mass", "propellant_cg", "grain_length",
              "nozzle_diameter"},
    "aero": {"backend", "cd", "cd_table", "roughness", "extra_cd"},
    "site": {"elevation", "temperature_offset", "rail_length", "rail_elevation", "rail_azimuth", "sounding", "wind"},
    "sim": {"method", "dt", "rtol", "atol", "max_step", "t_max", "seed", "jet_damping", "inertia_rate",
            "constant_density", "constant_gravity", "thrust_misalignment", "sample_rate"},
    "uncertainty": None,
    "meta": None,      # free-form: team, year, measured apogee, sources, notes
}
_COMPONENT_KEYS = {
    "nose": {"type", "name", "shape", "length", "diameter", "mass", "cg", "inertia_axial", "inertia_transverse"},
    "body": {"type", "name", "position", "length", "diameter", "mass", "cg", "inertia_axial", "inertia_transverse"},
    "transition": {"type", "name", "position", "length", "fore_diameter", "aft_diameter", "mass", "cg",
                   "inertia_axial", "inertia_transverse"},
    "fins": {"type", "name", "count", "position", "root_chord", "tip_chord", "span", "sweep", "thickness",
             "body_diameter", "mass", "edge", "cg", "inertia_axial", "inertia_transverse"},
    "mass": {"type", "name", "position", "mass", "length", "radius"},
    "lumped": {"type", "name", "mass", "cg", "inertia_axial", "inertia_transverse"},
}
_COMPONENT_REQUIRED = {
    "nose": {"length", "diameter"}, "body": {"position", "length", "diameter"},
    "transition": {"position", "length", "fore_diameter", "aft_diameter"},
    "fins": {"count", "position", "root_chord", "tip_chord", "span"},
    "mass": {"position", "mass"}, "lumped": {"mass", "cg", "inertia_axial", "inertia_transverse"},
}
_WIND_KEYS = {"model", "speed", "direction", "ref_height", "exponent", "table", "gust"}
_RECOVERY_KEYS = {"name", "cds", "trigger", "lag", "inflation_time"}
UNCERTAIN = ("mass_scale", "cg_offset", "cd_scale", "impulse_scale", "wind_speed_offset", "wind_direction_offset",
             "rail_elevation_offset", "rail_azimuth_offset", "misalignment", "cds_scale", "lag_offset")


def _check_keys(d, allowed, where):
    if not isinstance(d, dict):
        raise ConfigError(f"{where} must be a mapping")
    extra = set(d) - allowed
    if extra:
        raise ConfigError(f"unknown key(s) in {where}: {', '.join(sorted(extra))}")


def _positive(d, key, where):
    if not isinstance(d.get(key), (int, float)) or d[key] <= 0:
        raise ConfigError(f"{where}.{key} must be a positive number")


def validate(cfg: dict) -> dict:
    _check_keys(cfg, set(_SCHEMA), "config")
    for sec in ("rocket", "motor", "site"):
        if sec not in cfg:
            raise ConfigError(f"missing required section: {sec}")
    for sec, keys in _SCHEMA.items():
        if keys is not None and sec in cfg:
            _check_keys(cfg[sec], keys, sec)
    r = cfg["rocket"]
    for k in ("name", "reference_diameter", "components"):
        if k not in r:
            raise ConfigError(f"missing required field: rocket.{k}")
    _positive(r, "reference_diameter", "rocket")
    if not r["components"]:
        raise ConfigError("rocket.components must not be empty")
    for i, c in enumerate(r["components"]):
        where = f"rocket.components[{i}]"
        t = c.get("type")
        if t not in _COMPONENT_KEYS:
            raise ConfigError(f"{where}.type must be one of {sorted(_COMPONENT_KEYS)}")
        _check_keys(c, _COMPONENT_KEYS[t], where)
        missing = _COMPONENT_REQUIRED[t] - set(c)
        if missing:
            raise ConfigError(f"missing required field(s) in {where}: {', '.join(sorted(missing))}")
        if t == "nose" and c.get("shape", "ogive") not in NOSE_SHAPES:
            raise ConfigError(f"{where}.shape must be one of {NOSE_SHAPES}")
        if c.get("mass", 0.0) < 0:
            raise ConfigError(f"{where}.mass must not be negative")
    L = rocket_length(r["components"])
    for i, c in enumerate(r["components"]):
        pos = c.get("position", c.get("cg", 0.0))
        if L > 0 and not (-1e-9 <= pos <= L + 1e-9):
            raise ConfigError(f"rocket.components[{i}] sits at {pos} m, outside the rocket's length of {L:.3f} m")
    for i, d in enumerate(r.get("recovery", []) or []):
        _check_keys(d, _RECOVERY_KEYS, f"rocket.recovery[{i}]")
        _positive(d, "cds", f"rocket.recovery[{i}]")
        if d.get("trigger") != "apogee" and not isinstance(d.get("trigger"), (int, float)):
            raise ConfigError(f"rocket.recovery[{i}].trigger must be 'apogee' or an altitude in metres")
    m = cfg["motor"]
    for k in ("eng_file", "nozzle_position"):
        if k not in m:
            raise ConfigError(f"missing required field: motor.{k}")
    s = cfg["site"]
    if "rail_length" not in s:
        raise ConfigError("missing required field: site.rail_length")
    _positive(s, "rail_length", "site")
    if "wind" in s:
        _check_keys(s["wind"], _WIND_KEYS, "site.wind")
    if "uncertainty" in cfg:
        _check_keys(cfg["uncertainty"], set(UNCERTAIN), "uncertainty")
    return cfg


def load_config(path) -> dict:
    path = Path(path)
    with open(path) as fh:
        cfg = yaml.safe_load(fh)
    validate(cfg)
    cfg["_dir"] = str(path.resolve().parent)
    return cfg


def _resolve(cfg, rel):
    """Find a data file: relative to the config, then to the repo's data folders."""
    base = Path(cfg.get("_dir", "."))
    for cand in (base / rel, base.parent / rel, base.parent / "motors" / rel, base.parent / "weather" / rel):
        if cand.exists():
            return cand
    raise ConfigError(f"file not found: {rel} (looked relative to {base})")


def build(cfg: dict, pert: dict | None = None):
    """Build (vehicle, simulate-kwargs) from a validated config. `pert` holds Monte Carlo perturbations."""
    p = dict(mass_scale=1.0, cg_offset=0.0, cd_scale=1.0, impulse_scale=1.0, wind_speed_offset=0.0,
             wind_direction_offset=0.0, rail_elevation_offset=0.0, rail_azimuth_offset=0.0,
             misalign_y=0.0, misalign_z=0.0, cds_scale=1.0, lag_offset=0.0, gust_seed=None)
    p.update(pert or {})
    r, m, s = cfg["rocket"], cfg["motor"], cfg["site"]
    a = cfg.get("aero", {}) or {}; sim = cfg.get("sim", {}) or {}
    eng = load_eng(_resolve(cfg, m["eng_file"]))
    if eng.diameter > r["reference_diameter"] + 1e-9:
        raise ConfigError(f"motor diameter {eng.diameter * 1000:.0f} mm does not fit in the rocket")
    motor = Motor(eng, m.get("propellant_mass"), m.get("case_mass"), p["impulse_scale"])
    comps = r["components"]
    mass = MassModel(comps, motor, m["nozzle_position"], m.get("propellant_cg"), m.get("grain_length"),
                     p["mass_scale"], p["cg_offset"])
    aero = Aero(comps, r["reference_diameter"], a.get("backend", "buildup"), a.get("cd"), a.get("cd_table"),
                a.get("roughness", 60e-6), a.get("extra_cd", 0.0), p["cd_scale"],
                m.get("nozzle_diameter", 0.6 * eng.diameter))
    sounding = Sounding.from_csv(_resolve(cfg, s["sounding"])) if s.get("sounding") else None
    w = dict(s.get("wind", {}) or {})
    t_max = sim.get("t_max", 600.0)
    seed = p["gust_seed"] if p["gust_seed"] is not None else sim.get("seed", 0)
    wind = Wind(model=w.get("model", "none"), speed=w.get("speed", 0.0), direction=w.get("direction", 0.0),
                ref_height=w.get("ref_height", 10.0), exponent=w.get("exponent", 1.0 / 7.0), table=w.get("table"),
                sounding=sounding, elevation=s.get("elevation", 0.0), gust=w.get("gust"), seed=seed, t_max=t_max,
                speed_offset=p["wind_speed_offset"], direction_offset=p["wind_direction_offset"])
    env = Environment(s.get("elevation", 0.0), s.get("temperature_offset", 0.0), wind, sounding,
                      sim.get("constant_density"), sim.get("constant_gravity", False))
    mis = sim.get("thrust_misalignment", [0.0, 0.0])
    vehicle = Vehicle(env, motor, mass, aero,
                      s.get("rail_elevation", 90.0) + p["rail_elevation_offset"],
                      s.get("rail_azimuth", 0.0) + p["rail_azimuth_offset"],
                      (math.radians(mis[0] + p["misalign_y"]), math.radians(mis[1] + p["misalign_z"])),
                      sim.get("jet_damping", True), sim.get("inertia_rate", True))
    L = rocket_length(comps)
    rail = s["rail_length"]
    if "rail_button_aft" in r:
        rail = rail - (L - r["rail_button_aft"])   # the aft button starts this far up the rail
        if rail <= 0:
            raise ConfigError("the rail is shorter than the distance from the nozzle to the aft rail button")
    rec = []
    for d in r.get("recovery", []) or []:
        d = copy.deepcopy(d)
        d["cds"] *= p["cds_scale"]
        d["lag"] = max(0.0, d.get("lag", 0.0) + p["lag_offset"])
        rec.append(d)
    kw = dict(rail_length=rail, recovery=rec, method=sim.get("method", "RK45"), dt=sim.get("dt", 0.001),
              rtol=sim.get("rtol", 1e-7), atol=sim.get("atol", 1e-9), max_step=sim.get("max_step", 0.02), t_max=t_max)
    return vehicle, kw


def fly(cfg: dict, pert: dict | None = None):
    from .flight import simulate
    vehicle, kw = build(cfg, pert)
    return simulate(vehicle, **kw)
