"""Flight phases: pad -> rail -> powered -> coast -> parachute descent -> landed."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from .integrate import solve
from .quaternion import from_rail

PHASES = ["pad", "rail", "powered", "coast", "descent", "landed"]


@dataclass
class Segment:
    phase: str
    kind: str            # 'rail', '6dof' or '3dof'
    t: np.ndarray
    y: np.ndarray
    extra: dict = field(default_factory=dict)


@dataclass
class FlightResult:
    segments: list
    events: list
    summary: dict
    vehicle: object
    status: str = "ok"


def _normalise_q(y):
    y = np.array(y, float)
    q = y[6:10]
    y[6:10] = q / math.sqrt(float(q @ q))
    return y


def simulate(vehicle, rail_length, recovery=(), method="RK45", dt=0.001, rtol=1e-7, atol=1e-9,
             max_step=0.02, t_max=600.0) -> FlightResult:
    """Fly one rocket from the pad to the ground.

    recovery: list of dicts with name, cds (m^2), trigger ('apogee' or an altitude in m above ground),
    lag (s after the trigger) and inflation_time (s).
    """
    v = vehicle; motor = v.motor
    kw = dict(method=method, dt=dt, rtol=rtol, atol=atol)
    segments = []; events = []
    sin_el = v.rail_dir[2]

    # ---- pad: wait for thrust to exceed the weight component along the rail
    def excess(t):
        return v.thrust(t) - v.mass.at(t)[0] * v.env.g(0.0) * sin_el
    t_lo = None
    grid = np.linspace(0.0, motor.burn_time, 4001)
    for a, b in zip(grid[:-1], grid[1:]):
        if excess(b) > 0.0:
            lo, hi = a, b
            for _ in range(60):
                mid = 0.5 * (lo + hi)
                lo, hi = (mid, hi) if excess(mid) <= 0.0 else (lo, mid)
            t_lo = hi
            break
    if t_lo is None:
        raise RuntimeError("thrust never exceeds weight: the rocket does not leave the pad")
    t_lo = float(t_lo)
    events.append(dict(name="liftoff", t=t_lo))

    # ---- rail
    ts, ys, hit = solve(v.rail_deriv, t_lo, [0.0, 0.0], t_lo + 30.0,
                        events=[(lambda t, y: y[0] - rail_length, +1)], max_step=0.005, **kw)
    if hit is None:
        raise RuntimeError("the rocket did not clear the rail within 30 s")
    segments.append(Segment("rail", "rail", ts, ys))
    t = float(ts[-1]); s, sp = ys[-1]
    d = v.rail_dir
    q = from_rail(v.el, v.az)
    y = np.array([d[0] * s, d[1] * s, d[2] * s, d[0] * sp, d[1] * sp, d[2] * sp, *q, 0.0, 0.0, 0.0])
    events.append(dict(name="rail_exit", t=t, speed=float(sp)))

    post = _normalise_q
    ground = (lambda t, y: y[2], -1)
    apogee = (lambda t, y: y[5], -1)
    status = "ok"

    def fly6(phase, t, y, t_end, evs):
        ts, ys, hit = solve(v.deriv6, t, y, t_end, events=evs, max_step=max_step, post_step=post, **kw)
        ys[-1] = _normalise_q(ys[-1])
        segments.append(Segment(phase, "6dof", ts, ys))
        return float(ts[-1]), ys[-1].copy(), hit

    landed = False; t_ap = None
    # ---- powered flight
    if t < motor.burn_time:
        t, y, hit = fly6("powered", t, y, motor.burn_time, [ground, apogee])
        if hit == 0:
            landed = True
        elif hit == 1:
            t_ap = t
        else:
            events.append(dict(name="burnout", t=t, altitude=float(y[2]), speed=float(np.linalg.norm(y[3:6]))))
    # ---- coast to apogee
    if not landed and t_ap is None:
        t, y, hit = fly6("coast", t, y, t_max, [ground, apogee])
        if hit == 0:
            landed = True
        elif hit == 1:
            t_ap = t
        else:
            raise RuntimeError("no apogee before t_max")
    if t_ap is not None:
        events.append(dict(name="apogee", t=t_ap, altitude=float(y[2]), x=float(y[0]), y=float(y[1])))

    # ---- recovery scheduling
    devices = [dict(r) for r in recovery]
    for dv in devices:
        dv.setdefault("lag", 0.0); dv.setdefault("inflation_time", 0.5)
    scheduled = []          # (deploy time, device)
    pending = []            # altitude-triggered devices not yet triggered
    if t_ap is not None:
        for dv in devices:
            if dv["trigger"] == "apogee":
                scheduled.append((t_ap + dv["lag"], dv))
            else:
                pending.append(dv)

    if not landed:
        if not devices:
            # no recovery system: ballistic 6DOF to the ground
            t, y, hit = fly6("coast", t, y, t_max, [ground])
            landed = True; status = "ballistic"
        else:
            # keep flying 6DOF until the first parachute opens
            if scheduled:
                t_first = min(s[0] for s in scheduled)
                if t_first > t:
                    t, y, hit = fly6("coast", t, y, t_first, [ground])
                    landed = hit == 0
            else:
                # only altitude-triggered devices: fall 6DOF until the highest trigger altitude
                h = max(dv["trigger"] for dv in pending)
                if y[2] > h:
                    t, y, hit = fly6("coast", t, y, t_max, [ground, (lambda t, yy, h=h: yy[2] - h, -1)])
                    landed = hit == 0

    # ---- descent under parachutes (3DOF)
    if not landed and devices:
        mass = v.mass.at(t)[0]
        deployed = []       # (deploy time, device)

        def cds(tt):
            tot = 0.0
            for td, dv in deployed:
                ti = dv["inflation_time"]
                tot += dv["cds"] * (1.0 if ti <= 0.0 else min(max((tt - td) / ti, 0.0), 1.0))
            return tot + 1e-9

        yd = y[:6].copy()
        peak_force = 0.0
        while True:
            # anything already due or already below its trigger altitude
            for dv in list(pending):
                if yd[2] <= dv["trigger"]:
                    pending.remove(dv); scheduled.append((t + dv["lag"], dv))
            for sd in sorted(scheduled, key=lambda s: s[0]):
                if sd[0] <= t + 1e-9:
                    scheduled.remove(sd); deployed.append((t, sd[1]))
                    events.append(dict(name=f"deploy:{sd[1].get('name', 'parachute')}", t=t, altitude=float(yd[2]),
                                       speed=float(np.linalg.norm(yd[3:6]))))
            t_end = min([s[0] for s in scheduled] + [t_max])
            evs = [ground] + [(lambda tt, yy, h=dv["trigger"]: yy[2] - h, -1) for dv in pending]
            f = lambda tt, yy: v.descent_deriv(tt, yy, mass, cds)  # noqa: E731
            ts, ys, hit = solve(f, t, yd, t_end, events=evs, max_step=0.1, **{**kw, "dt": max(dt, 0.005)})
            segments.append(Segment("descent", "3dof", ts, ys, dict(cds=[cds(tt) for tt in ts])))
            for tt, yy in zip(ts, ys):
                air = v.env.air(max(yy[2], 0.0)); w = v.env.wind(max(yy[2], 0.0), tt)
                V2 = sum((yy[3 + i] - w[i]) ** 2 for i in range(3))
                peak_force = max(peak_force, 0.5 * air.rho * V2 * cds(tt))
            t = float(ts[-1]); yd = ys[-1].copy()
            if hit == 0:
                landed = True
                break
            if hit is not None:
                dv = pending.pop(hit - 1); scheduled.append((t + dv["lag"], dv))
            if t >= t_max - 1e-9:
                raise RuntimeError("still descending at t_max")
        y = yd
        events.append(dict(name="peak_parachute_load", t=t, force=peak_force))

    events.append(dict(name="landing", t=t, x=float(y[0]), y=float(y[1]),
                       speed=float(np.linalg.norm(y[3:6]))))
    res = FlightResult(segments, sorted(events, key=lambda e: e["t"]), {}, v, status)
    res.summary = summarise(res)
    return res


def summarise(res: FlightResult) -> dict:
    v = res.vehicle
    ev = {e["name"]: e for e in res.events}
    out = dict(status=res.status)
    out["rail_exit_speed"] = ev["rail_exit"]["speed"]
    out["rail_exit_time"] = ev["rail_exit"]["t"]
    if "burnout" in ev:
        out["burnout_altitude"] = ev["burnout"]["altitude"]; out["burnout_speed"] = ev["burnout"]["speed"]
    max_speed = max_mach = max_q = max_alpha = max_acc = 0.0
    min_margin = float("inf"); apogee = 0.0; max_qerr = 0.0
    t_ap = ev["apogee"]["t"] if "apogee" in ev else float("inf")
    obs = []
    for sg in res.segments:
        if sg.kind != "6dof":
            continue
        sp = np.linalg.norm(sg.y[:, 3:6], axis=1)
        if len(sg.t) > 2:
            acc = np.linalg.norm(np.diff(sg.y[:, 3:6], axis=0), axis=1) / np.maximum(np.diff(sg.t), 1e-9)
            max_acc = max(max_acc, float(np.max(acc)))
        for tt, yy in zip(sg.t, sg.y):
            o = v.observe6(tt, yy)
            max_mach = max(max_mach, o["mach"]); max_q = max(max_q, o["qdyn"])
            max_qerr = max(max_qerr, abs(o["qnorm"] - 1.0))
            if tt <= t_ap:
                obs.append(o)
            apogee = max(apogee, float(yy[2]))
        max_speed = max(max_speed, float(sp.max()))
    # angle of attack only matters where there is air load: report its maximum where the dynamic
    # pressure is at least 10% of the peak, and separately the value at the moment of rail exit
    for o in obs:
        if o["qdyn"] >= 0.1 * max_q:
            max_alpha = max(max_alpha, o["alpha"])
        if o["airspeed"] > 10.0:
            min_margin = min(min_margin, o["margin"])
    out["rail_exit_alpha_deg"] = math.degrees(obs[0]["alpha"]) if obs else 0.0
    out.update(apogee=ev["apogee"]["altitude"] if "apogee" in ev else apogee,
               apogee_time=ev["apogee"]["t"] if "apogee" in ev else float("nan"),
               max_speed=max_speed, max_mach=max_mach, max_dynamic_pressure=float(max_q),
               max_acceleration=max_acc, max_alpha_deg=math.degrees(max_alpha),
               min_static_margin=float(min_margin) if math.isfinite(min_margin) else float("nan"),
               quaternion_norm_error=max_qerr)
    ld = ev["landing"]
    out.update(flight_time=ld["t"], landing_x=ld["x"], landing_y=ld["y"],
               landing_distance=math.hypot(ld["x"], ld["y"]), impact_speed=ld["speed"])
    if "peak_parachute_load" in ev:
        out["peak_parachute_load"] = float(ev["peak_parachute_load"]["force"])
    return out
