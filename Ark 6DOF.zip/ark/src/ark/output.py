"""Trajectory JSON: the one interface between the physics core and everything else."""
from __future__ import annotations

import json
import math

import numpy as np

from . import __version__
from .flight import PHASES
from .geometry import rocket_length
from .quaternion import from_rail

SCHEMA_VERSION = 1
FIELDS = ["t", "x", "y", "z", "vx", "vy", "vz", "q0", "q1", "q2", "q3", "alpha_deg", "mach", "qdyn",
          "thrust", "mass", "static_margin", "phase"]


def _clean(o):
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return None if not math.isfinite(f) else round(f, 6)
    if isinstance(o, np.integer):
        return int(o)
    return o


def geometry(cfg) -> dict:
    """The outline a viewer needs to draw the rocket."""
    comps = cfg["rocket"]["components"]
    keep = ("type", "shape", "position", "length", "diameter", "fore_diameter", "aft_diameter", "count", "root_chord",
            "tip_chord", "span", "sweep", "body_diameter")
    return dict(name=cfg["rocket"]["name"], length=rocket_length(comps), reference_diameter=cfg["rocket"]["reference_diameter"],
                components=[{k: c[k] for k in c if k in keep} for c in comps if c["type"] in ("nose", "body", "transition", "fins")])


def trajectory(res, cfg=None, rate=25.0) -> dict:
    """Resample a flight to a fixed rate and return the columnar trajectory dictionary."""
    v = res.vehicle
    q_rail = from_rail(v.el, v.az); q_up = from_rail(90.0, 0.0)
    d = v.rail_dir
    t_end = res.segments[-1].t[-1]
    grid = np.arange(0.0, t_end, 1.0 / rate)
    grid = np.append(grid, t_end)
    cols = {k: np.zeros(len(grid)) for k in FIELDS}
    cols["t"][:] = grid
    m0 = v.mass.at(0.0)
    t_lo = res.segments[0].t[0]
    for i, t in enumerate(grid):                       # on the pad
        if t >= t_lo:
            break
        cols["q0"][i], cols["q1"][i], cols["q2"][i], cols["q3"][i] = q_rail
        cols["mass"][i] = v.mass.at(t)[0]; cols["thrust"][i] = v.thrust(t)
        cols["static_margin"][i] = (v.aero.cp(0.0)[1] - m0[1]) / v.aero.d_ref
    n_seg = len(res.segments)
    for k, sg in enumerate(res.segments):
        t0, t1 = sg.t[0], sg.t[-1]
        idx = np.where((grid >= t0) & ((grid < t1) | ((k == n_seg - 1) & (grid <= t1))))[0]
        if len(idx) == 0:
            continue
        tt = grid[idx]
        ys = np.column_stack([np.interp(tt, sg.t, sg.y[:, j]) for j in range(sg.y.shape[1])])
        ph = PHASES.index(sg.phase)
        for j, i in enumerate(idx):
            t = tt[j]; y = ys[j]
            cols["phase"][i] = ph
            if sg.kind == "rail":
                s, sp = y
                pos = [d[0] * s, d[1] * s, d[2] * s]; vel = [d[0] * sp, d[1] * sp, d[2] * sp]
                o = v.observe6(t, [*pos, *vel, *q_rail])
                q = q_rail
            elif sg.kind == "6dof":
                pos, vel = y[0:3], y[3:6]
                qn = y[6:10] / np.linalg.norm(y[6:10]); q = qn
                o = v.observe6(t, y)
            else:
                pos, vel = y[0:3], y[3:6]; q = q_up
                air = v.env.air(max(y[2], 0.0)); sp = float(np.linalg.norm(vel))
                o = dict(alpha=0.0, mach=sp / air.a, qdyn=0.5 * air.rho * sp * sp, mass=v.mass.at(t)[0],
                         margin=0.0, thrust=0.0)
            cols["x"][i], cols["y"][i], cols["z"][i] = pos
            cols["vx"][i], cols["vy"][i], cols["vz"][i] = vel
            cols["q0"][i], cols["q1"][i], cols["q2"][i], cols["q3"][i] = q
            cols["alpha_deg"][i] = math.degrees(o["alpha"]); cols["mach"][i] = o["mach"]; cols["qdyn"][i] = o["qdyn"]
            cols["thrust"][i] = o["thrust"]; cols["mass"][i] = o["mass"]; cols["static_margin"][i] = o["margin"]
    cols["phase"][-1] = PHASES.index("landed")
    digits = dict(t=3, x=2, y=2, z=2, vx=2, vy=2, vz=2, q0=5, q1=5, q2=5, q3=5, alpha_deg=2, mach=4, qdyn=1,
                  thrust=1, mass=4, static_margin=3, phase=0)
    samples = {k: [round(float(x), digits[k]) for x in cols[k]] for k in FIELDS}
    samples["phase"] = [int(x) for x in samples["phase"]]
    geom = geometry(cfg) if cfg is not None else None
    return _clean(dict(
        meta=dict(schema_version=SCHEMA_VERSION, code_version=__version__, sample_rate=rate, phases=PHASES,
                  frame="launch frame: x East, y North, z Up; quaternion scalar-first, body to launch"),
        rocket=geom, samples=samples, events=res.events, summary=res.summary))


def write_json(obj, path):
    with open(path, "w") as fh:
        json.dump(_clean(obj), fh, separators=(",", ":"))
