"""Equations of motion: launch rail (1D), free flight (6DOF) and parachute descent (3DOF).

State vectors
  rail:    [s, v]                          distance and speed along the rail
  6DOF:    [x, y, z, vx, vy, vz, q0, q1, q2, q3, wx, wy, wz]
           position and velocity in the launch frame (East, North, Up),
           attitude quaternion body->launch, angular velocity in the body frame
  descent: [x, y, z, vx, vy, vz]

Body frame: x along the axis towards the nose. Geometry positions are metres
from the nose tip, positive aft, so a point at station s sits at body
x = x_cg - s.
"""
from __future__ import annotations

import math

from .quaternion import rail_direction

V_EPS = 1e-3   # below this airspeed (m/s) aerodynamic forces are switched off


class Vehicle:
    """Everything the equations of motion need, bundled."""

    def __init__(self, env, motor, mass, aero, rail_elevation=90.0, rail_azimuth=0.0,
                 misalignment=(0.0, 0.0), jet_damping=True, inertia_rate=True, no_thrust=False, no_aero=False):
        self.env = env; self.motor = motor; self.mass = mass; self.aero = aero
        self.el = rail_elevation; self.az = rail_azimuth
        self.rail_dir = rail_direction(rail_elevation, rail_azimuth)
        self.mis = misalignment            # thrust misalignment angles about body y and z, rad
        self.jet_damping = jet_damping; self.inertia_rate = inertia_rate
        self.no_thrust = no_thrust; self.no_aero = no_aero
        self.freeze_translation = False    # debug switch: 'wind tunnel' mode for the pitch test

    def thrust(self, t):
        return 0.0 if self.no_thrust else self.motor.thrust(t)

    # ------------------------------------------------------------------ rail
    def rail_deriv(self, t, y):
        s, v = y
        m = self.mass.at(t)[0]
        z = s * self.rail_dir[2]
        air = self.env.air(z)
        drag = 0.0
        if v > V_EPS and not self.no_aero:
            mach = v / air.a; re = air.rho * v * self.aero.length / air.mu
            drag = 0.5 * air.rho * v * v * self.aero.A_ref * self.aero.cd(mach, re, True)
        a = (self.thrust(t) - drag) / m - self.env.g(z) * self.rail_dir[2]
        if a < 0.0 and s <= 0.0 and v <= 0.0:
            return [0.0, 0.0]
        return [v, a]

    # ------------------------------------------------------------------ 6DOF
    def deriv6(self, t, y):
        x, yy, z, vx, vy, vz, q0, q1, q2, q3, wx, wy, wz = y
        qn2 = q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3
        n = math.sqrt(qn2)
        a0, a1, a2, a3 = q0 / n, q1 / n, q2 / n, q3 / n
        m, xcg, Ia, It = self.mass.at(t)
        air = self.env.air(z)
        we, wn, wu = self.env.wind(z, t)
        rx, ry, rz = vx - we, vy - wn, vz - wu
        r11 = 1 - 2 * (a2 * a2 + a3 * a3); r12 = 2 * (a1 * a2 - a0 * a3); r13 = 2 * (a1 * a3 + a0 * a2)
        r21 = 2 * (a1 * a2 + a0 * a3); r22 = 1 - 2 * (a1 * a1 + a3 * a3); r23 = 2 * (a2 * a3 - a0 * a1)
        r31 = 2 * (a1 * a3 - a0 * a2); r32 = 2 * (a2 * a3 + a0 * a1); r33 = 1 - 2 * (a1 * a1 + a2 * a2)
        ub = r11 * rx + r21 * ry + r31 * rz
        vb = r12 * rx + r22 * ry + r32 * rz
        wb = r13 * rx + r23 * ry + r33 * rz
        V = math.sqrt(ub * ub + vb * vb + wb * wb)
        thrusting = t < self.motor.burn_time
        Fx = Fy = Fz = 0.0; My = Mz = 0.0
        if V > V_EPS and not self.no_aero:
            aero = self.aero
            mach = V / air.a
            qA = 0.5 * air.rho * V * V * aero.A_ref
            re = air.rho * V * aero.length / air.mu
            Fx = -qA * aero.cd(mach, re, thrusting) * ub / V
            # normal force per component, using the local crossflow (includes pitch/yaw damping)
            for cna, xs in aero.normal(mach):
                xb = xcg - xs
                fy = -qA * cna * (vb + wz * xb) / V
                fz = -qA * cna * (wb - wy * xb) / V
                Fy += fy; Fz += fz
                My -= xb * fz; Mz += xb * fy
        T = self.thrust(t)
        if T > 0.0:
            ey, ez = self.mis
            Fx += T
            if ey or ez:
                # small tilt of the thrust line: rotation ey about body y, ez about body z
                ty, tz = T * ez, -T * ey
                xb = xcg - self.mass.nozzle_position
                Fy += ty; Fz += tz
                My -= xb * tz; Mz += xb * ty
            if self.jet_damping:
                c = self.motor.mass_flow(t) * (self.mass.nozzle_position - xcg) ** 2
                My -= c * wy; Mz -= c * wz
        if self.inertia_rate and thrusting:
            di = self.mass.inertia_rate(t)
            My -= di * wy; Mz -= di * wz
        g = self.env.g(z)
        if self.freeze_translation:
            ax = ay = az = 0.0
            dx = dy = dz = 0.0
        else:
            ax = (r11 * Fx + r12 * Fy + r13 * Fz) / m
            ay = (r21 * Fx + r22 * Fy + r23 * Fz) / m
            az = (r31 * Fx + r32 * Fy + r33 * Fz) / m - g
            dx, dy, dz = vx, vy, vz
        dwx = 0.0
        dwy = (My - (Ia - It) * wx * wz) / It
        dwz = (Mz - (It - Ia) * wx * wy) / It
        k = 1.0 - qn2          # pulls |q| back to 1 (the state is not renormalised mid-step)
        dq0 = -0.5 * (q1 * wx + q2 * wy + q3 * wz) + k * q0
        dq1 = 0.5 * (q0 * wx + q2 * wz - q3 * wy) + k * q1
        dq2 = 0.5 * (q0 * wy + q3 * wx - q1 * wz) + k * q2
        dq3 = 0.5 * (q0 * wz + q1 * wy - q2 * wx) + k * q3
        return [dx, dy, dz, ax, ay, az, dq0, dq1, dq2, dq3, dwx, dwy, dwz]

    def observe6(self, t, y):
        """Derived quantities at a 6DOF state: angle of attack, Mach, dynamic pressure, static margin..."""
        x, yy, z, vx, vy, vz, q0, q1, q2, q3 = y[:10]
        n = math.sqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3)
        a0, a1, a2, a3 = q0 / n, q1 / n, q2 / n, q3 / n
        m, xcg, Ia, It = self.mass.at(t)
        air = self.env.air(z)
        we, wn, wu = self.env.wind(z, t)
        rx, ry, rz = vx - we, vy - wn, vz - wu
        ub = (1 - 2 * (a2 * a2 + a3 * a3)) * rx + 2 * (a1 * a2 + a0 * a3) * ry + 2 * (a1 * a3 - a0 * a2) * rz
        vb = 2 * (a1 * a2 - a0 * a3) * rx + (1 - 2 * (a1 * a1 + a3 * a3)) * ry + 2 * (a2 * a3 + a0 * a1) * rz
        wb = 2 * (a1 * a3 + a0 * a2) * rx + 2 * (a2 * a3 - a0 * a1) * ry + (1 - 2 * (a1 * a1 + a2 * a2)) * rz
        V = math.sqrt(ub * ub + vb * vb + wb * wb)
        mach = V / air.a
        alpha = math.atan2(math.hypot(vb, wb), ub) if V > V_EPS else 0.0
        cn, xcp = self.aero.cp(mach)
        return dict(alpha=alpha, mach=mach, qdyn=0.5 * air.rho * V * V, mass=m, xcg=xcg, xcp=xcp,
                    margin=(xcp - xcg) / self.aero.d_ref, thrust=self.thrust(t), airspeed=V, qnorm=n)

    # --------------------------------------------------------------- descent
    def descent_deriv(self, t, y, mass, cds):
        x, yy, z, vx, vy, vz = y
        air = self.env.air(max(z, 0.0))
        we, wn, wu = self.env.wind(max(z, 0.0), t)
        rx, ry, rz = vx - we, vy - wn, vz - wu
        V = math.sqrt(rx * rx + ry * ry + rz * rz)
        k = 0.5 * air.rho * V * cds(t) / mass
        return [vx, vy, vz, -k * rx, -k * ry, -k * rz - self.env.g(max(z, 0.0))]
