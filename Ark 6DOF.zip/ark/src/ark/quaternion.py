"""Quaternion helpers.

Conventions: scalar first, q = (q0, q1, q2, q3); Hamilton product; q rotates
a vector from the body frame to the launch (East, North, Up) frame; angular
velocity is expressed in the body frame.
"""
from __future__ import annotations

import math


def qmul(a, b):
    a0, a1, a2, a3 = a; b0, b1, b2, b3 = b
    return (a0 * b0 - a1 * b1 - a2 * b2 - a3 * b3,
            a0 * b1 + a1 * b0 + a2 * b3 - a3 * b2,
            a0 * b2 - a1 * b3 + a2 * b0 + a3 * b1,
            a0 * b3 + a1 * b2 - a2 * b1 + a3 * b0)


def qconj(q):
    return (q[0], -q[1], -q[2], -q[3])


def qnorm(q):
    return math.sqrt(q[0] ** 2 + q[1] ** 2 + q[2] ** 2 + q[3] ** 2)


def qnormalize(q):
    n = qnorm(q)
    return (q[0] / n, q[1] / n, q[2] / n, q[3] / n)


def rotmat(q):
    """3x3 rotation matrix (tuple of rows) taking body-frame vectors to the launch frame."""
    q0, q1, q2, q3 = q
    return ((1 - 2 * (q2 * q2 + q3 * q3), 2 * (q1 * q2 - q0 * q3), 2 * (q1 * q3 + q0 * q2)),
            (2 * (q1 * q2 + q0 * q3), 1 - 2 * (q1 * q1 + q3 * q3), 2 * (q2 * q3 - q0 * q1)),
            (2 * (q1 * q3 - q0 * q2), 2 * (q2 * q3 + q0 * q1), 1 - 2 * (q1 * q1 + q2 * q2)))


def rotate(q, v):
    """Body -> launch."""
    R = rotmat(q)
    return tuple(R[i][0] * v[0] + R[i][1] * v[1] + R[i][2] * v[2] for i in range(3))


def rotate_inv(q, v):
    """Launch -> body."""
    R = rotmat(q)
    return tuple(R[0][i] * v[0] + R[1][i] * v[1] + R[2][i] * v[2] for i in range(3))


def from_axis_angle(axis, angle):
    n = math.sqrt(sum(a * a for a in axis))
    s = math.sin(angle / 2.0) / n
    return (math.cos(angle / 2.0), axis[0] * s, axis[1] * s, axis[2] * s)


def from_rotmat(R):
    """Unit quaternion from a rotation matrix given as rows (Shepperd's method)."""
    (a, b, c), (d, e, f), (g, h, i) = R
    tr = a + e + i
    if tr > 0:
        s = math.sqrt(tr + 1.0) * 2
        q = (0.25 * s, (h - f) / s, (c - g) / s, (d - b) / s)
    elif a > e and a > i:
        s = math.sqrt(1.0 + a - e - i) * 2
        q = ((h - f) / s, 0.25 * s, (b + d) / s, (c + g) / s)
    elif e > i:
        s = math.sqrt(1.0 + e - a - i) * 2
        q = ((c - g) / s, (b + d) / s, 0.25 * s, (f + h) / s)
    else:
        s = math.sqrt(1.0 + i - a - e) * 2
        q = ((d - b) / s, (c + g) / s, (f + h) / s, 0.25 * s)
    return qnormalize(q)


def rail_direction(elevation_deg, azimuth_deg):
    """Unit vector along the rail in ENU; azimuth clockwise from north."""
    el = math.radians(elevation_deg); az = math.radians(azimuth_deg)
    return (math.cos(el) * math.sin(az), math.cos(el) * math.cos(az), math.sin(el))


def from_rail(elevation_deg, azimuth_deg):
    """Attitude with body x along the rail. Body z is as close to Up as possible;
    for a vertical rail (where that is undefined) body z points North."""
    x = rail_direction(elevation_deg, azimuth_deg)
    ref = (0.0, 0.0, 1.0) if abs(x[2]) < 0.999999 else (0.0, 1.0, 0.0)
    d = sum(r * k for r, k in zip(ref, x))
    z = tuple(r - d * k for r, k in zip(ref, x))
    n = math.sqrt(sum(k * k for k in z)); z = tuple(k / n for k in z)
    y = (z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0])
    return from_rotmat(((x[0], y[0], z[0]), (x[1], y[1], z[1]), (x[2], y[2], z[2])))
