"""Mass, centre of gravity and inertia as functions of time."""
from __future__ import annotations


from .geometry import (fin_cg_chordwise, fin_cg_spanwise, frustum_profile, nose_profile, shell_properties)


def component_mass_item(c: dict) -> dict | None:
    """Turn one config component into mass, CG position, axial and transverse inertia (own CG)."""
    t = c["type"]
    if t == "lumped":
        return dict(m=c["mass"], x=c["cg"], Ia=c["inertia_axial"], It=c["inertia_transverse"])
    m = float(c.get("mass", 0.0))
    if m <= 0.0:
        return None
    if "cg" in c and "inertia_transverse" in c:   # CAD override
        return dict(m=m, x=c["cg"], Ia=c.get("inertia_axial", 0.0), It=c["inertia_transverse"])
    if t == "nose":
        R = c["diameter"] / 2.0
        _, xcg, ka2, kt2 = shell_properties(nose_profile(c.get("shape", "ogive"), c["length"], R), c["length"])
        return dict(m=m, x=xcg, Ia=m * ka2, It=m * kt2)
    if t == "body":
        r, L = c["diameter"] / 2.0, c["length"]
        return dict(m=m, x=c["position"] + L / 2.0, Ia=m * r * r, It=m * (r * r / 2.0 + L * L / 12.0))
    if t == "transition":
        L = c["length"]
        _, xcg, ka2, kt2 = shell_properties(frustum_profile(L, c["fore_diameter"] / 2.0, c["aft_diameter"] / 2.0), L)
        return dict(m=m, x=c["position"] + xcg, Ia=m * ka2, It=m * kt2)
    if t == "fins":
        cr, ct, s, sw = c["root_chord"], c["tip_chord"], c["span"], c.get("sweep", 0.0)
        R = c.get("body_diameter", 0.0) / 2.0
        xc = fin_cg_chordwise(cr, ct, sw); ys = fin_cg_spanwise(cr, ct, s)
        # second moments of a trapezoidal plate about its own centroid (approximate)
        ky2 = s * s * (cr * cr + 4 * cr * ct + ct * ct) / (18.0 * (cr + ct) ** 2)
        kx2 = (cr * cr + ct * ct) / 24.0 + (sw * sw) / 18.0
        Ia = m * ((R + ys) ** 2 + ky2)
        return dict(m=m, x=c["position"] + xc, Ia=Ia, It=0.5 * Ia + m * kx2)
    if t == "mass":
        L = c.get("length", 0.0); r = c.get("radius", 0.0)
        return dict(m=m, x=c["position"], Ia=0.5 * m * r * r, It=m * (r * r / 4.0 + L * L / 12.0))
    raise ValueError(f"unknown component type {t!r}")


class MassModel:
    """m(t), x_cg(t), I_axial(t), I_transverse(t) for the whole rocket.

    The dry rocket is summed once. The propellant is a hollow cylinder of
    fixed length and position whose mass (and so inertia) scales with the
    unburned impulse fraction.
    """

    def __init__(self, components, motor, nozzle_position, propellant_cg=None, grain_length=None,
                 mass_scale=1.0, cg_offset=0.0):
        items = [it for it in (component_mass_item(c) for c in components) if it]
        self.motor = motor
        Lm, rm = motor.length, motor.diameter / 2.0
        if motor.case_mass > 0.0:
            items.append(dict(m=motor.case_mass, x=nozzle_position - Lm / 2.0, Ia=motor.case_mass * rm * rm,
                              It=motor.case_mass * (rm * rm / 2.0 + Lm * Lm / 12.0)))
        self.items = items
        self.m_dry = sum(i["m"] for i in items) * mass_scale
        s1 = sum(i["m"] * i["x"] for i in items) * mass_scale
        self.x_dry = s1 / self.m_dry + cg_offset
        s1 = self.m_dry * self.x_dry
        self._s1 = s1
        # sum of (It_i + m_i x_i^2), shifted consistently with the CG offset
        self._j = mass_scale * sum(i["It"] + i["m"] * (i["x"] + cg_offset) ** 2 for i in items)
        self.Ia_dry = mass_scale * sum(i["Ia"] for i in items)
        Lg = grain_length if grain_length is not None else 0.85 * Lm
        ro, ri = 0.9 * rm, 0.35 * rm
        self.xp = propellant_cg if propellant_cg is not None else nozzle_position - Lm / 2.0
        self.kp_a2 = (ro * ro + ri * ri) / 2.0
        self.kp_t2 = (3.0 * (ro * ro + ri * ri) + Lg * Lg) / 12.0
        self.nozzle_position = nozzle_position

    def at(self, t: float):
        mp = self.motor.propellant_mass(t)
        m = self.m_dry + mp
        xcg = (self._s1 + mp * self.xp) / m
        It = self._j + mp * (self.kp_t2 + self.xp * self.xp) - m * xcg * xcg
        return m, xcg, self.Ia_dry + mp * self.kp_a2, It

    def inertia_rate(self, t: float, h: float = 1e-3):
        """d(I_transverse)/dt by central difference."""
        return (self.at(t + h)[3] - self.at(max(t - h, 0.0))[3]) / (h + min(t, h))
