"""Solid motor: RASP .eng parser and a thrust / impulse / mass model."""
from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass


class EngFormatError(ValueError):
    pass


@dataclass
class EngData:
    name: str
    diameter: float      # m
    length: float        # m
    delays: str
    propellant_mass: float  # kg
    total_mass: float       # kg
    manufacturer: str
    t: list
    thrust: list


def parse_eng(text: str) -> EngData:
    """Parse one motor from RASP .eng text. Raises EngFormatError on malformed input."""
    lines = [l.strip() for l in text.replace("\r", "").split("\n")]
    lines = [l for l in lines if l and not l.startswith(";")]
    if not lines:
        raise EngFormatError("no header line found")
    h = lines[0].split()
    if len(h) < 7:
        raise EngFormatError(f"header needs 7 fields, got {len(h)}: {lines[0]!r}")
    try:
        dia, length, mp, mt = float(h[1]) / 1000.0, float(h[2]) / 1000.0, float(h[4]), float(h[5])
    except ValueError as e:
        raise EngFormatError(f"bad number in header: {lines[0]!r}") from e
    ts, fs = [], []
    for l in lines[1:]:
        parts = l.split()
        if len(parts) != 2:
            raise EngFormatError(f"expected 'time thrust', got {l!r} (multiple motors per file are not supported)")
        try:
            t, f = float(parts[0]), float(parts[1])
        except ValueError as e:
            raise EngFormatError(f"bad data line {l!r}") from e
        if ts and t <= ts[-1]:
            raise EngFormatError(f"time values must increase: {t} after {ts[-1]}")
        if t < 0 or f < 0:
            raise EngFormatError(f"negative value in {l!r}")
        ts.append(t); fs.append(f)
    if len(ts) < 2:
        raise EngFormatError("thrust curve needs at least two points")
    if fs[-1] != 0.0:
        raise EngFormatError("last thrust point must be zero")
    if mp <= 0 or mt < mp:
        raise EngFormatError("header masses are inconsistent")
    return EngData(h[0], dia, length, h[3], mp, mt, " ".join(h[6:]), ts, fs)


def load_eng(path) -> EngData:
    with open(path) as fh:
        return parse_eng(fh.read())


_CLASS = "ABCDEFGHIJKLMNO"


class Motor:
    """Thrust curve with piecewise-linear interpolation and exact impulse integration.

    Propellant mass follows the burned-impulse fraction (constant effective
    exhaust velocity): m_p(t) = m_p0 (1 - I(t) / I_total).
    """

    def __init__(self, eng: EngData, propellant_mass=None, case_mass=None, impulse_scale=1.0):
        t = list(eng.t); f = [x * impulse_scale for x in eng.thrust]
        if t[0] > 0.0:
            t.insert(0, 0.0); f.insert(0, 0.0)
        self.t, self.f = t, f
        self.name = eng.name; self.diameter = eng.diameter; self.length = eng.length
        self.propellant_mass0 = eng.propellant_mass if propellant_mass is None else propellant_mass
        self.case_mass = (eng.total_mass - eng.propellant_mass) if case_mass is None else case_mass
        cum = [0.0]
        for i in range(1, len(t)):
            cum.append(cum[-1] + 0.5 * (f[i] + f[i - 1]) * (t[i] - t[i - 1]))
        self.cum = cum
        self.total_impulse = cum[-1]
        self.burn_time = t[-1]
        self.peak_thrust = max(f)
        self.average_thrust = self.total_impulse / self.burn_time

    def thrust(self, t: float) -> float:
        if t <= 0.0 or t >= self.burn_time:
            return 0.0
        i = bisect_right(self.t, t) - 1
        t0, t1 = self.t[i], self.t[i + 1]
        return self.f[i] + (self.f[i + 1] - self.f[i]) * (t - t0) / (t1 - t0)

    def impulse(self, t: float) -> float:
        if t <= 0.0:
            return 0.0
        if t >= self.burn_time:
            return self.total_impulse
        i = bisect_right(self.t, t) - 1
        t0, t1 = self.t[i], self.t[i + 1]
        dt = t - t0
        slope = (self.f[i + 1] - self.f[i]) / (t1 - t0)
        return self.cum[i] + self.f[i] * dt + 0.5 * slope * dt * dt

    def propellant_mass(self, t: float) -> float:
        return self.propellant_mass0 * (1.0 - self.impulse(t) / self.total_impulse)

    def mass_flow(self, t: float) -> float:
        """Positive propellant mass flow rate, kg/s."""
        return self.propellant_mass0 * self.thrust(t) / self.total_impulse

    @property
    def impulse_class(self) -> str:
        lim = 2.5
        for c in _CLASS:
            if self.total_impulse <= lim:
                return c
            lim *= 2.0
        return ">O"
