"""ark: a 6DOF flight simulator for passively stable rockets."""
__version__ = "0.1.0"
