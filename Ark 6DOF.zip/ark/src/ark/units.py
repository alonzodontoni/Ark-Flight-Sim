"""Physical constants. SI units everywhere inside the package."""
import math

G0 = 9.80665            # standard gravity, m/s^2
R_AIR = 287.05287       # specific gas constant of dry air, J/(kg K)
GAMMA = 1.4             # ratio of specific heats of air
R_EARTH = 6_371_000.0   # mean Earth radius, used for inverse-square gravity, m
R0_GEOPOT = 6_356_766.0 # radius the 1976 standard uses for geopotential altitude, m
RHO_SL = 1.225          # sea-level standard density, kg/m^3
DEG = math.pi / 180.0
