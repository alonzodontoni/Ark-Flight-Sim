"""Monte Carlo dispersion and one-at-a-time sensitivity."""
from __future__ import annotations

import csv
import math
from multiprocessing import Pool

import numpy as np

from .config import UNCERTAIN, fly

_SCALES = ("mass_scale", "cd_scale", "impulse_scale", "cds_scale")
OUTPUTS = ("apogee", "apogee_time", "max_speed", "max_mach", "rail_exit_speed", "rail_exit_alpha_deg", "max_alpha_deg",
           "landing_x", "landing_y", "landing_distance", "impact_speed", "flight_time")


def nominal_pert():
    return {}


def sample_pert(spec: dict, rng: np.random.Generator) -> dict:
    """Draw one set of perturbations from the config's `uncertainty` block (normal distributions)."""
    p = {}
    for k in UNCERTAIN:              # fixed order, so the stream is reproducible
        if k not in spec:
            continue
        sig = float(spec[k].get("sigma", 0.0))
        if k in _SCALES:
            p[k] = float(np.clip(1.0 + sig * rng.standard_normal(), 0.5, 1.5))
        elif k == "misalignment":
            p["misalign_y"] = float(sig * rng.standard_normal()); p["misalign_z"] = float(sig * rng.standard_normal())
        else:
            p[k] = float(sig * rng.standard_normal())
    p["gust_seed"] = int(rng.integers(0, 2 ** 31 - 1))
    return p


def _run(args):
    cfg, pert, idx = args
    row = dict(run=idx, **{k: v for k, v in pert.items()})
    try:
        res = fly(cfg, pert)
        row["status"] = res.status
        for k in OUTPUTS:
            row[k] = float(res.summary.get(k, float("nan")))
    except Exception as e:          # a failed run is a result, not something to drop
        row["status"] = f"failed: {type(e).__name__}: {e}"
        for k in OUTPUTS:
            row[k] = float("nan")
    return row


def monte_carlo(cfg: dict, n: int, seed: int = 0, workers: int = 1) -> list[dict]:
    """Run n perturbed flights. Each run has its own random stream spawned from `seed`,
    so the results do not depend on the number of workers."""
    spec = cfg.get("uncertainty", {}) or {}
    streams = np.random.SeedSequence(seed).spawn(n)
    jobs = [(cfg, sample_pert(spec, np.random.default_rng(s)), i) for i, s in enumerate(streams)]
    if workers <= 1:
        return [_run(j) for j in jobs]
    with Pool(workers) as pool:
        return pool.map(_run, jobs, chunksize=max(1, n // (workers * 8)))


def write_csv(rows, path):
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader(); w.writerows(rows)


def ellipse_scale(p: float) -> float:
    """Number of standard deviations for a 2D normal ellipse containing probability p."""
    return math.sqrt(-2.0 * math.log(1.0 - p))


def dispersion_ellipse(x, y, p: float = 0.95):
    """Centre, semi-axes (major, minor) and major-axis angle (rad, anticlockwise from East)
    of the ellipse containing probability p for a 2D normal fit to the points."""
    x = np.asarray(x, float); y = np.asarray(y, float)
    c = np.cov(np.vstack([x, y]))
    w, v = np.linalg.eigh(c)
    k = ellipse_scale(p)
    major = v[:, 1]
    return (float(x.mean()), float(y.mean())), (k * math.sqrt(max(w[1], 0.0)), k * math.sqrt(max(w[0], 0.0))), \
        float(math.atan2(major[1], major[0]))


def inside_ellipse(x, y, centre, axes, angle):
    dx = np.asarray(x) - centre[0]; dy = np.asarray(y) - centre[1]
    u = dx * math.cos(angle) + dy * math.sin(angle); w = -dx * math.sin(angle) + dy * math.cos(angle)
    return (u / axes[0]) ** 2 + (w / axes[1]) ** 2 <= 1.0


def one_at_a_time(cfg: dict) -> list[dict]:
    """Move each uncertain input to +1 sigma and -1 sigma with the rest nominal."""
    spec = cfg.get("uncertainty", {}) or {}
    base = fly(cfg).summary
    out = []
    for k in UNCERTAIN:
        if k not in spec:
            continue
        sig = float(spec[k]["sigma"])
        row = dict(parameter=k, sigma=sig)
        for sign, tag in ((+1, "plus"), (-1, "minus")):
            if k in _SCALES:
                pert = {k: 1.0 + sign * sig}
            elif k == "misalignment":
                pert = {"misalign_y": sign * sig}
            else:
                pert = {k: sign * sig}
            s = fly(cfg, pert).summary
            row[f"apogee_{tag}"] = s["apogee"] - base["apogee"]
            row[f"landing_{tag}"] = math.hypot(s["landing_x"] - base["landing_x"], s["landing_y"] - base["landing_y"])
        out.append(row)
    return out


def rank_correlation(rows, inputs, output):
    """Spearman rank correlation between each sampled input and one output."""
    from scipy.stats import spearmanr
    ok = [r for r in rows if r["status"] in ("ok", "ballistic") and math.isfinite(r[output])]
    return {k: float(spearmanr([r[k] for r in ok], [r[output] for r in ok]).statistic) for k in inputs if k in ok[0]}
