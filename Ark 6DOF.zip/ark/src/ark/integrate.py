"""Integrators: a fixed-step RK4 with event location, and a thin wrapper over SciPy's solve_ivp.

Both take the same derivative function f(t, y) and the same event list, and
return (ts, ys, hit) where hit is the index of the terminal event that
stopped the integration, or None if it ran to t_end.
"""
from __future__ import annotations

import numpy as np
from scipy.integrate import solve_ivp


def rk4_step(f, t, y, h):
    k1 = np.asarray(f(t, y)); k2 = np.asarray(f(t + h / 2, y + h / 2 * k1))
    k3 = np.asarray(f(t + h / 2, y + h / 2 * k2)); k4 = np.asarray(f(t + h, y + h * k3))
    return y + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)


def rk4(f, t0, y0, t_end, dt, events=(), post_step=None):
    """Fixed-step RK4. events: list of (g(t, y), direction) with direction -1, 0 or +1.
    An event is located by bisection on the step size, restarting from the state before the crossing."""
    t = float(t0); y = np.asarray(y0, float)
    ts = [t]; ys = [y]
    g_prev = [g(t, y) for g, _ in events]
    while t < t_end - 1e-12:
        h = min(dt, t_end - t)
        y1 = rk4_step(f, t, y, h)
        if post_step is not None:
            y1 = post_step(y1)
        t1 = t + h
        hit = None
        for i, (g, direction) in enumerate(events):
            g1 = g(t1, y1)
            crossed = (g_prev[i] < 0 <= g1) if direction > 0 else (g_prev[i] > 0 >= g1) if direction < 0 \
                else (g_prev[i] * g1 <= 0 and g_prev[i] != g1 and g_prev[i] != 0)
            if crossed:
                hit = i
                break
        if hit is not None:
            g, _ = events[hit]
            lo, hi = 0.0, h
            s0 = g_prev[hit]
            for _ in range(60):
                mid = 0.5 * (lo + hi)
                ym = rk4_step(f, t, y, mid)
                if (g(t + mid, ym) > 0) == (s0 > 0):
                    lo = mid
                else:
                    hi = mid
            ye = rk4_step(f, t, y, hi)
            if post_step is not None:
                ye = post_step(ye)
            ts.append(t + hi); ys.append(ye)
            return np.array(ts), np.array(ys), hit
        t, y = t1, y1
        ts.append(t); ys.append(y)
        g_prev = [g(t, y) for g, _ in events]
    return np.array(ts), np.array(ys), None


def solve(f, t0, y0, t_end, events=(), method="RK45", dt=0.001, max_step=0.02, rtol=1e-7, atol=1e-9, post_step=None):
    """Integrate with the chosen method ('rk4' is the in-house integrator)."""
    if t_end <= t0:
        return np.array([t0]), np.array([np.asarray(y0, float)]), None
    if method.lower() == "rk4":
        return rk4(f, t0, y0, t_end, dt, events, post_step)
    evs = []
    for g, direction in events:
        def ev(t, y, g=g):
            return g(t, y)
        ev.terminal = True; ev.direction = direction
        evs.append(ev)
    sol = solve_ivp(f, (t0, t_end), np.asarray(y0, float), method=method, events=evs or None,
                    max_step=max_step, rtol=rtol, atol=atol)
    if sol.status < 0:
        raise RuntimeError(f"integration failed: {sol.message}")
    hit = None
    if sol.status == 1:
        hit = min((te[0], i) for i, te in enumerate(sol.t_events) if len(te))[1]
    return sol.t, sol.y.T, hit
