"""Rocket geometry helpers shared by the mass and aerodynamics models.

All positions are metres from the nose tip, positive aft.
"""
from __future__ import annotations

import math

import numpy as np

NOSE_SHAPES = ("cone", "ogive", "parabolic", "ellipsoid")


def nose_profile(shape: str, L: float, R: float):
    """Return r(x) for a nose of length L and base radius R, x measured from the tip."""
    if shape == "cone":
        return lambda x: R * x / L
    if shape == "ogive":
        rho = (R * R + L * L) / (2.0 * R)
        return lambda x: np.sqrt(np.maximum(rho * rho - (L - x) ** 2, 0.0)) + R - rho
    if shape == "parabolic":
        return lambda x: R * (2.0 * x / L - (x / L) ** 2)
    if shape == "ellipsoid":
        return lambda x: R * np.sqrt(np.maximum(1.0 - (1.0 - x / L) ** 2, 0.0))
    raise ValueError(f"unknown nose shape {shape!r}; use one of {NOSE_SHAPES}")


def frustum_profile(L: float, r0: float, r1: float):
    return lambda x: r0 + (r1 - r0) * x / L


def shell_properties(profile, L: float, n: int = 2000):
    """Thin shell of revolution: surface area, CG from the front, and squared radii of gyration.

    Returns (area, x_cg, k_axial^2, k_transverse^2 about the shell's own CG),
    integrating thin rings (midpoint rule).
    """
    xe = np.linspace(0.0, L, n + 1)
    re = profile(xe)
    xm = 0.5 * (xe[1:] + xe[:-1]); rm = 0.5 * (re[1:] + re[:-1])
    ds = np.hypot(np.diff(xe), np.diff(re))
    dA = 2.0 * math.pi * rm * ds
    A = float(dA.sum())
    xcg = float((xm * dA).sum() / A)
    ka2 = float((rm ** 2 * dA).sum() / A)
    kt2 = float(((0.5 * rm ** 2 + (xm - xcg) ** 2) * dA).sum() / A)
    return A, xcg, ka2, kt2


def fin_cg_chordwise(cr: float, ct: float, sweep: float) -> float:
    """Chordwise CG of a trapezoidal fin, from the root leading edge."""
    return (sweep * (cr + 2 * ct) + cr * cr + cr * ct + ct * ct) / (3.0 * (cr + ct))


def fin_cg_spanwise(cr: float, ct: float, span: float) -> float:
    return span * (cr + 2 * ct) / (3.0 * (cr + ct))


def rocket_length(components) -> float:
    L = 0.0
    for c in components:
        t = c["type"]
        if t == "nose":
            L = max(L, c["length"])
        elif t in ("body", "transition"):
            L = max(L, c["position"] + c["length"])
        elif t == "fins":
            L = max(L, c["position"] + max(c["root_chord"], c.get("sweep", 0.0) + c["tip_chord"]))
    return L
