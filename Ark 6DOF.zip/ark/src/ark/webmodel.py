"""Export a rocket as the plain-data model that web/sim.js (the in-browser port) flies."""
from __future__ import annotations

import numpy as np

from .config import build


def web_model(cfg: dict) -> dict:
    v, kw = build(cfg)
    ms, mo, ae, env = v.mass, v.motor, v.aero, v.env
    if ae.backend == "constant":
        aero = dict(backend="constant", cd=ae.cd_const)
    else:
        if ae.backend == "lookup":
            m, off, on = ae.tm, ae.tcd_off, ae.tcd_on
        else:   # tabulate the build-up at sea-level Reynolds numbers
            air = env.air(0.0)
            m = np.linspace(0.02, 0.9, 45)
            re = [air.rho * x * air.a * ae.length / air.mu for x in m]
            off = [ae.cd_buildup(x, r, False) for x, r in zip(m, re)]
            on = [ae.cd_buildup(x, r, True) for x, r in zip(m, re)]
        aero = dict(backend="lookup", table=dict(m=list(map(float, m)), off=list(map(float, off)), on=list(map(float, on))))
    aero.update(d_ref=ae.d_ref, A_ref=ae.A_ref, cd_scale=ae.cd_scale, fixed=[list(x) for x in ae.fixed],
                fins=[list(f) for f in ae.fins])
    s = env.sounding
    w = env.wind
    return dict(
        mass=dict(m_dry=ms.m_dry, s1=ms._s1, j=ms._j, Ia_dry=ms.Ia_dry, xp=ms.xp, kp_a2=ms.kp_a2, kp_t2=ms.kp_t2,
                  nozzle=ms.nozzle_position),
        motor=dict(t=mo.t, f=mo.f, cum=mo.cum, propellant_mass=mo.propellant_mass0, total_impulse=mo.total_impulse,
                   burn_time=mo.burn_time),
        aero=aero,
        env=dict(elevation=env.elevation, dT=env.dT,
                 sounding=None if s is None else dict(h=s.h.tolist(), lnp=s.lnp.tolist(), T=s.T.tolist(),
                                                      u=s.u.tolist(), v=s.v.tolist())),
        wind=dict(model=w.model, speed=w.speed, direction=w.direction, ref_height=w.ref_height, exponent=w.exponent),
        rail=dict(length=kw["rail_length"], elevation=v.el, azimuth=v.az),
        recovery=kw["recovery"], jet_damping=v.jet_damping, inertia_rate=v.inertia_rate)
