"""Command line: ark info | run | mc."""
from __future__ import annotations

import argparse
import math
import os

from .config import build, fly, load_config
from .montecarlo import dispersion_ellipse, monte_carlo, write_csv
from .output import trajectory, write_json


def _info(cfg):
    v, kw = build(cfg)
    m0, x0, _, it0 = v.mass.at(0.0); m1, x1, _, it1 = v.mass.at(v.motor.burn_time + 1)
    cn, xcp = v.aero.cp(0.0)
    mo = v.motor
    print(f"{cfg['rocket']['name']}")
    print(f"  motor            {mo.name}: {mo.total_impulse:.1f} N s (class {mo.impulse_class}), "
          f"burn {mo.burn_time:.2f} s, peak {mo.peak_thrust:.0f} N")
    print(f"  mass             {m0:.4f} kg at launch, {m1:.4f} kg at burnout")
    print(f"  centre of gravity {x0:.3f} m -> {x1:.3f} m from the nose tip")
    print(f"  centre of pressure {xcp:.3f} m (C_N_alpha {cn:.2f} per rad)")
    print(f"  static margin    {(xcp - x0) / v.aero.d_ref:.2f} cal at launch, {(xcp - x1) / v.aero.d_ref:.2f} cal at burnout")
    print(f"  effective rail   {kw['rail_length']:.2f} m")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="ark", description="6DOF rocket flight simulator")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("info", "run", "mc"):
        sp = sub.add_parser(name); sp.add_argument("config")
        if name == "run":
            sp.add_argument("-o", "--output", help="write the trajectory JSON here")
            sp.add_argument("--rate", type=float, default=25.0)
        if name == "mc":
            sp.add_argument("-n", type=int, default=500); sp.add_argument("--seed", type=int, default=0)
            sp.add_argument("--workers", type=int, default=os.cpu_count() or 1)
            sp.add_argument("-o", "--output", default="montecarlo.csv")
    a = ap.parse_args(argv)
    cfg = load_config(a.config)
    if a.cmd == "info":
        _info(cfg)
    elif a.cmd == "run":
        res = fly(cfg)
        _info(cfg)
        print("  ---")
        for k, val in res.summary.items():
            print(f"  {k:24s} {val:.3f}" if isinstance(val, float) else f"  {k:24s} {val}")
        if a.output:
            write_json(trajectory(res, cfg, a.rate), a.output)
            print(f"  wrote {a.output}")
    else:
        rows = monte_carlo(cfg, a.n, a.seed, a.workers)
        write_csv(rows, a.output)
        ok = [r for r in rows if not str(r["status"]).startswith("failed")]
        ap_ = [r["apogee"] for r in ok]
        mean = sum(ap_) / len(ap_); sd = math.sqrt(sum((x - mean) ** 2 for x in ap_) / (len(ap_) - 1))
        c, ax, ang = dispersion_ellipse([r["landing_x"] for r in ok], [r["landing_y"] for r in ok], 0.95)
        print(f"{len(ok)}/{len(rows)} runs completed; apogee {mean:.1f} +/- {sd:.1f} m")
        print(f"95% landing ellipse: centre ({c[0]:.0f}, {c[1]:.0f}) m, semi-axes {ax[0]:.0f} x {ax[1]:.0f} m, "
              f"major axis {math.degrees(ang):.0f} deg from East; wrote {a.output}")


if __name__ == "__main__":
    main()
