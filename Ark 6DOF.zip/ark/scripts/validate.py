"""Fly the three reference rockets and compare with published and measured figures.

Usage: python scripts/validate.py   (writes docs/validation.json and docs/*.png, and web/trajectories/*.json)
"""
import copy
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from ark.config import build, fly, load_config
from ark.output import trajectory, write_json

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"; WEB = ROOT / "web" / "trajectories"
DOCS.mkdir(exist_ok=True); WEB.mkdir(parents=True, exist_ok=True)

REF = {   # published comparison figures (sources in the README)
    "alpha3": dict(openrocket=385.5, inspo_1d=373.4, rocketpy=None, measured=None),
    "bella_lui": dict(openrocket=None, rocketpy=460.54, measured=458.97),
    "ndrt_2020": dict(openrocket=None, rocketpy=1293.43, measured=1320.29),
}


def flight_data(name):
    if name == "bella_lui":
        d = np.loadtxt(ROOT / "data/flights/bella_lui_flight_data_filtered.csv", skiprows=1, delimiter=",", usecols=(2, 3, 4))
        d = d[:573]
        return d[:, 0], d[:, 1], d[:, 2]
    if name == "ndrt_2020":
        d = np.loadtxt(ROOT / "data/flights/ndrt_2020_flight_data.csv", skiprows=1, delimiter=",", usecols=(3, 4))
        return d[:, 0], d[:, 1] / 3.281, None
    return None


def series(res):
    t, z, vz = [], [], []
    d = res.vehicle.rail_dir
    for sg in res.segments:
        if sg.kind == "rail":
            t += list(sg.t); z += list(sg.y[:, 0] * d[2]); vz += list(sg.y[:, 1] * d[2])
        else:
            t += list(sg.t); z += list(sg.y[:, 2]); vz += list(sg.y[:, 5])
    return np.array(t), np.array(z), np.array(vz)


out = {}
for name in ("alpha3", "bella_lui", "ndrt_2020"):
    cfg = load_config(ROOT / "data/rockets" / f"{name}.yaml")
    res = fly(cfg)
    s = res.summary
    row = dict(name=cfg["rocket"]["name"], **{k: s[k] for k in ("apogee", "apogee_time", "max_speed", "max_mach",
               "rail_exit_speed", "max_alpha_deg", "min_static_margin", "landing_distance", "impact_speed", "flight_time")})
    row.update(REF[name])
    # alternative aero backends: error budget
    alt = {}
    for backend in ("buildup",):
        c2 = copy.deepcopy(cfg); c2["aero"] = dict(backend=backend)
        alt[backend] = fly(c2).summary["apogee"]
    row["apogee_buildup"] = alt["buildup"]
    v, _ = build(copy.deepcopy(cfg) | {"aero": dict(backend="buildup")})
    row["cd_buildup_at_mach_0.3"] = v.aero.cd(0.3, v.env.air(0).rho * 0.3 * v.env.air(0).a * v.aero.length / v.env.air(0).mu, False)
    fd = flight_data(name)
    if fd:
        ft, fz, fvz = fd
        row["measured_from_file"] = float(fz.max())
        row["error_vs_measured_pct"] = 100 * (s["apogee"] - fz.max()) / fz.max()
        t, z, vz = series(res)
        fig, ax = plt.subplots(1, 2 if fvz is not None else 1, figsize=(11 if fvz is not None else 6.5, 4))
        ax = np.atleast_1d(ax)
        ax[0].plot(ft, fz, color="#888", lw=2.5, label="flight data"); ax[0].plot(t, z, color="#1f6feb", lw=1.5, label="ark")
        ax[0].set_xlabel("time (s)"); ax[0].set_ylabel("altitude above ground (m)"); ax[0].legend(); ax[0].grid(alpha=.3)
        ax[0].set_xlim(0, max(ft.max(), s["apogee_time"] * 1.6))
        if fvz is not None:
            ax[1].plot(ft, fvz, color="#888", lw=2.5, label="flight data"); ax[1].plot(t, vz, color="#1f6feb", lw=1.5, label="ark")
            ax[1].set_xlabel("time (s)"); ax[1].set_ylabel("vertical speed (m/s)"); ax[1].legend(); ax[1].grid(alpha=.3)
            ax[1].set_xlim(0, ft.max())
        fig.suptitle(f"{cfg['rocket']['name']}: simulated vs measured")
        fig.tight_layout(); fig.savefig(DOCS / f"validation_{name}.png", dpi=130); plt.close(fig)
    out[name] = row
    write_json(trajectory(res, cfg, rate=25.0), WEB / f"{name}.json")
    print(name, json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in row.items()}))
json.dump(out, open(DOCS / "validation.json", "w"), indent=1)
