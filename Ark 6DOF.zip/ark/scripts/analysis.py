"""Findings, sensitivity and Monte Carlo dispersion. Writes docs/findings.json, docs/*.png and web/montecarlo_*.json.

Usage: python scripts/analysis.py [n_runs]
"""
import copy
import json
import math
import os
import sys
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Ellipse

from ark.config import build, fly, load_config
from ark.montecarlo import dispersion_ellipse, inside_ellipse, monte_carlo, one_at_a_time, rank_correlation, write_csv

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"; WEB = ROOT / "web"
N = int(sys.argv[1]) if len(sys.argv) > 1 else 500
BLUE, GREY, RED = "#1f6feb", "#888888", "#d1242f"
cfgs = {n: load_config(ROOT / "data/rockets" / f"{n}.yaml") for n in ("alpha3", "bella_lui", "ndrt_2020")}
F = {}


def variant(cfg, **sections):
    c = copy.deepcopy(cfg)
    for sec, upd in sections.items():
        c.setdefault(sec, {}).update(upd)
    return c


# 1. what a real atmosphere adds over constant sea-level density (the inspiration repo's hypothesis)
a = cfgs["alpha3"]
const = fly(variant(a, sim=dict(constant_density=1.225, constant_gravity=True))).summary["apogee"]
real = fly(a).summary["apogee"]
F["atmosphere_alpha3"] = dict(constant_density=const, standard_atmosphere=real, gain_m=real - const,
                              gain_pct=100 * (real - const) / const, openrocket=385.5,
                              share_of_gap_pct=100 * (real - const) / (385.5 - const))
for n in ("bella_lui", "ndrt_2020"):
    c = cfgs[n]
    air0 = build(c)[0].env.air(0.0).rho
    k = fly(variant(c, sim=dict(constant_density=air0, constant_gravity=True))).summary["apogee"]
    F[f"atmosphere_{n}"] = dict(constant_pad_density=k, with_altitude=fly(c).summary["apogee"],
                                gain_pct=100 * (fly(c).summary["apogee"] - k) / k)

# 2. variable-mass rotation terms
for n, c in cfgs.items():
    c2 = variant(c, site=dict(wind=dict(model="constant", speed=5.0, direction=270.0)))
    c2["site"].pop("sounding", None)
    on = fly(c2).summary["apogee"]; off = fly(variant(c2, sim=dict(jet_damping=False, inertia_rate=False))).summary["apogee"]
    F[f"variable_mass_{n}"] = dict(apogee_on=on, apogee_off=off, difference_m=on - off)

# 3. weathercocking: apogee and upwind drift against wind speed (Bella Lui, vertical rail)
ws = [0, 2, 4, 6, 8, 10]; ap = []; dr = []; al = []
for w in ws:
    c = variant(cfgs["bella_lui"], site=dict(rail_elevation=90.0, wind=dict(model="constant", speed=float(w), direction=270.0)))
    c["site"].pop("sounding", None)
    r = fly(c); e = [x for x in r.events if x["name"] == "apogee"][0]
    ap.append(r.summary["apogee"]); dr.append(e["x"]); al.append(r.summary["rail_exit_alpha_deg"])
F["weathercocking_bella_lui"] = dict(wind_speed=ws, apogee=ap, apogee_x=dr, rail_exit_alpha_deg=al)
fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.6))
ax[0].plot(ws, ap, "o-", color=BLUE); ax[0].set_xlabel("wind speed (m/s)"); ax[0].set_ylabel("apogee (m)")
ax[1].plot(ws, dr, "o-", color=BLUE); ax[1].set_xlabel("wind speed (m/s)"); ax[1].set_ylabel("east position at apogee (m)")
ax[1].axhline(0, color=GREY, lw=.8)
for x in ax: x.grid(alpha=.3)
fig.suptitle("Bella Lui, wind from the west: the rocket turns into the wind and flies upwind")
fig.tight_layout(); fig.savefig(DOCS / "weathercocking.png", dpi=130); plt.close(fig)

# 4. fin edge shape in the drag build-up (Alpha III)
rows = {}
for edge in ("rounded", "square"):
    c = variant(a, aero=dict(backend="buildup")); c["aero"].pop("cd", None)
    c["rocket"]["components"][2]["edge"] = edge
    v, _ = build(c); air = v.env.air(0)
    rows[edge] = dict(cd_at_mach_0_3=v.aero.cd(0.3, air.rho * 0.3 * air.a * v.aero.length / air.mu, False),
                      apogee=fly(c).summary["apogee"],
                      parts=v.aero.cd_buildup(0.3, air.rho * 0.3 * air.a * v.aero.length / air.mu, False, parts=True))
F["fin_edges_alpha3"] = dict(**rows, openrocket_cd=dict(rounded=0.56, square=1.08),
                             apogee_gain_pct=100 * (rows["rounded"]["apogee"] / rows["square"]["apogee"] - 1))

# 5. drag coefficient against Mach for the three rockets (build-up) with the teams' values
fig, ax = plt.subplots(figsize=(6.5, 4))
team = {"alpha3": ("OpenRocket value used by the inspiration repo", [[0.05, 0.56], [0.35, 0.56]]),
        "bella_lui": ("team curve", cfgs["bella_lui"]["aero"]["cd_table"]),
        "ndrt_2020": ("team value", [[0.05, 0.44], [0.55, 0.44]])}
for (n, c), col in zip(cfgs.items(), (BLUE, RED, "#1a7f37")):
    v, _ = build(variant(c, aero=dict(backend="buildup")))
    air = v.env.air(0)
    ms = np.linspace(0.03, 0.85, 80)
    ax.plot(ms, [v.aero.cd(m, air.rho * m * air.a * v.aero.length / air.mu, False) for m in ms], color=col, label=f"{c['rocket']['name']}: build-up")
    t = np.array(team[n][1]); ax.plot(t[:, 0], t[:, 1], "--", color=col, lw=2, label=f"   {team[n][0]}")
ax.set_xlabel("Mach number"); ax.set_ylabel("drag coefficient (motor off)"); ax.set_ylim(0.2, 0.8); ax.grid(alpha=.3); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig(DOCS / "drag_buildup.png", dpi=130); plt.close(fig)

# 6. static margin against time
fig, ax = plt.subplots(figsize=(6.5, 3.6))
for (n, c), col in zip(cfgs.items(), (BLUE, RED, "#1a7f37")):
    v, _ = build(c)
    ts = np.linspace(0, v.motor.burn_time * 1.3, 200)
    ax.plot(ts / v.motor.burn_time, [(v.aero.cp(0.0)[1] - v.mass.at(t)[1]) / v.aero.d_ref for t in ts], color=col, label=c["rocket"]["name"])
ax.axvline(1.0, color=GREY, lw=.8); ax.set_xlabel("time / burn time"); ax.set_ylabel("static margin (calibres)"); ax.grid(alpha=.3); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(DOCS / "static_margin.png", dpi=130); plt.close(fig)

# 7. does the transverse inertia matter? (RocketPy's listed values against the rod estimates used here)
for n, alt in (("bella_lui", 0.78267), ("ndrt_2020", 73.316)):
    c = copy.deepcopy(cfgs[n]); base = fly(c).summary
    c["rocket"]["components"][0]["inertia_transverse"] = alt
    s = fly(c).summary
    F[f"inertia_{n}"] = dict(used=cfgs[n]["rocket"]["components"][0]["inertia_transverse"], rocketpy_listed=alt,
                             apogee_used=base["apogee"], apogee_listed=s["apogee"])

# 8. RK4 convergence on the full Alpha III flight vs a smooth problem
c = variant(a, sim=dict(method="rk4"))
ref = fly(variant(a, sim=dict(method="DOP853", rtol=1e-11, atol=1e-12, max_step=0.002))).summary["apogee"]
dts = [0.02, 0.01, 0.005, 0.0025]; errs = [abs(fly(variant(c, sim=dict(dt=d))).summary["apogee"] - ref) for d in dts]
F["rk4_full_flight"] = dict(dt=dts, apogee_error=errs)
fig, ax = plt.subplots(figsize=(5.5, 3.8))
ax.loglog(dts, errs, "o-", color=BLUE, label="full flight (thrust curve has kinks)")
ax.loglog(dts, [errs[0] * (d / dts[0]) ** 4 for d in dts], ":", color=GREY, label="4th-order slope")
ax.loglog(dts, [errs[0] * (d / dts[0]) ** 2 for d in dts], "--", color=GREY, label="2nd-order slope")
ax.set_xlabel("time step (s)"); ax.set_ylabel("apogee error (m)"); ax.grid(alpha=.3, which="both"); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(DOCS / "convergence.png", dpi=130); plt.close(fig)

# 9. sensitivity (one at a time) and Monte Carlo for the two flown rockets
if N == 0:      # quick mode: keep the Monte Carlo results already on disk
    old = json.load(open(DOCS / "findings.json"))
    F.update({k: v for k, v in old.items() if k.startswith(("sensitivity_", "montecarlo_"))})
for n in (("ndrt_2020", "bella_lui") if N > 0 else ()):
    c = copy.deepcopy(cfgs[n])
    c["site"]["wind"]["gust"] = dict(sigma=0.8, tau=3.0)
    oat = one_at_a_time(c)
    F[f"sensitivity_{n}"] = oat
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    for axx, key, title in ((ax[0], "apogee", "change in apogee (m)"), (ax[1], "landing", "shift in landing point (m)")):
        rows = sorted(oat, key=lambda r: max(abs(r[f"{key}_plus"]), abs(r[f"{key}_minus"])))
        y = range(len(rows))
        if key == "apogee":
            axx.barh(y, [r["apogee_plus"] for r in rows], color=BLUE, label="+1 sigma"); axx.barh(y, [r["apogee_minus"] for r in rows], color=RED, label="-1 sigma")
            axx.axvline(0, color="k", lw=.6); axx.legend(fontsize=8)
        else:
            axx.barh(y, [max(r["landing_plus"], r["landing_minus"]) for r in rows], color=BLUE)
        axx.set_yticks(list(y)); axx.set_yticklabels([r["parameter"].replace("_", " ") for r in rows], fontsize=8); axx.set_xlabel(title); axx.grid(alpha=.3, axis="x")
    fig.suptitle(f"{c['rocket']['name']}: one input at a time, +/- 1 sigma"); fig.tight_layout(); fig.savefig(DOCS / f"tornado_{n}.png", dpi=130); plt.close(fig)

    t0 = time.time()
    rows = monte_carlo(c, N, seed=2026, workers=os.cpu_count() or 1)
    write_csv(rows, DOCS / f"montecarlo_{n}.csv")
    ok = [r for r in rows if not str(r["status"]).startswith("failed")]
    x = np.array([r["landing_x"] for r in ok]); y = np.array([r["landing_y"] for r in ok]); apo = np.array([r["apogee"] for r in ok])
    e95 = dispersion_ellipse(x, y, 0.95); e50 = dispersion_ellipse(x, y, 0.50)
    nom = fly(c).summary
    inputs = [k for k in rows[0] if k not in ("run", "status", "gust_seed") and k not in ok[0].keys() - set(rows[0])][:0]
    inputs = [k for k in ("mass_scale", "cg_offset", "cd_scale", "impulse_scale", "wind_speed_offset", "wind_direction_offset",
                          "rail_elevation_offset", "rail_azimuth_offset", "misalign_y", "misalign_z", "cds_scale", "lag_offset") if k in rows[0]]
    F[f"montecarlo_{n}"] = dict(runs=len(rows), completed=len(ok), seconds=time.time() - t0, apogee_mean=float(apo.mean()), apogee_std=float(apo.std(ddof=1)),
                                apogee_p05=float(np.percentile(apo, 5)), apogee_p95=float(np.percentile(apo, 95)),
                                nominal_apogee=nom["apogee"], landing_centre=e95[0], ellipse95_semi_axes=e95[1], ellipse95_angle_deg=math.degrees(e95[2]),
                                ellipse50_semi_axes=e50[1], inside95=float(inside_ellipse(x, y, *e95).mean()), inside50=float(inside_ellipse(x, y, *e50).mean()),
                                rank_correlation_apogee=rank_correlation(rows, inputs, "apogee"),
                                rank_correlation_landing_distance=rank_correlation(rows, inputs, "landing_distance"))
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.2))
    ax[0].scatter(x, y, s=6, color=BLUE, alpha=.5)
    for e, ls in ((e95, "-"), (e50, "--")):
        ax[0].add_patch(Ellipse(e[0], 2 * e[1][0], 2 * e[1][1], angle=math.degrees(e[2]), fill=False, color=RED, ls=ls, lw=1.5))
    ax[0].plot(0, 0, "k^", ms=8, label="launch pad"); ax[0].plot(nom["landing_x"], nom["landing_y"], "x", color="k", ms=8, label="nominal landing")
    ax[0].set_aspect("equal", "datalim"); ax[0].set_xlabel("east (m)"); ax[0].set_ylabel("north (m)"); ax[0].legend(fontsize=8); ax[0].grid(alpha=.3)
    ax[0].set_title(f"landing points, 50% and 95% ellipses ({len(ok)} runs)", fontsize=10)
    ax[1].hist(apo, bins=30, color=BLUE, alpha=.8); ax[1].axvline(nom["apogee"], color="k", ls="--", label="nominal")
    ax[1].set_xlabel("apogee (m)"); ax[1].set_ylabel("runs"); ax[1].legend(fontsize=8); ax[1].set_title(f"apogee {apo.mean():.0f} +/- {apo.std(ddof=1):.0f} m", fontsize=10)
    k = np.arange(1, len(apo) + 1); run = np.cumsum(apo) / k
    ax[2].plot(k, run, color=BLUE); se = apo.std(ddof=1) / np.sqrt(k)
    ax[2].fill_between(k, apo.mean() - 2 * se, apo.mean() + 2 * se, color=GREY, alpha=.25, label="+/- 2 standard errors")
    ax[2].set_xlabel("number of runs"); ax[2].set_ylabel("running mean apogee (m)"); ax[2].legend(fontsize=8); ax[2].grid(alpha=.3); ax[2].set_xlim(5, len(apo))
    ax[2].set_ylim(apo.mean() - 4 * se[9], apo.mean() + 4 * se[9])
    fig.suptitle(c["rocket"]["name"]); fig.tight_layout(); fig.savefig(DOCS / f"montecarlo_{n}.png", dpi=130); plt.close(fig)
    json.dump(dict(name=c["rocket"]["name"], x=[round(float(v), 1) for v in x], y=[round(float(v), 1) for v in y],
                   apogee=[round(float(v), 1) for v in apo], nominal=[nom["landing_x"], nom["landing_y"]],
                   ellipse95=dict(centre=e95[0], axes=e95[1], angle=e95[2]), ellipse50=dict(centre=e50[0], axes=e50[1], angle=e50[2])),
              open(WEB / f"montecarlo_{n}.json", "w"), separators=(",", ":"))
    print(n, "MC done in %.0f s" % (time.time() - t0))

json.dump(F, open(DOCS / "findings.json", "w"), indent=1, default=float)
print(json.dumps(F, indent=1, default=lambda o: round(float(o), 4))[:6000])
