"""Build the self-contained replay page, web/index.html: the page template, the in-browser simulator
(web/sim.js) and the rocket library (every config in data/rockets and data/library) in one file.

Usage: python scripts/build_web.py
"""
import glob
import json
import math
import shutil
import subprocess
from pathlib import Path

from ark.config import fly, load_config
from ark.output import _clean, geometry
from ark.webmodel import web_model

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
node = shutil.which("node")
paths = [ROOT / "data" / "rockets" / f"{k}.yaml" for k in ("ndrt_2020", "bella_lui", "alpha3")] + sorted(
    (Path(p) for p in glob.glob(str(ROOT / "data" / "library" / "*.yaml"))), key=lambda p: (load_config(p)["meta"]["year"], p.name))
RUN = ("const S=require(process.argv[1]);const m=JSON.parse(require('fs').readFileSync(0,'utf8'));"
       "console.log(S.simulate(m,{}).summary.apogee)")
library, worst = [], 0.0
for path in paths:
    cfg = load_config(path)
    m = cfg["meta"]
    apogee = fly(cfg).summary["apogee"]
    model = web_model(cfg)
    if node:
        js = float(subprocess.run([node, "-e", RUN, str(WEB / "sim.js")], input=json.dumps(model), capture_output=True, text=True, check=True).stdout)
        worst = max(worst, abs(js / apogee - 1))
    library.append(dict(key=m["key"], name=m["name"], team=m["team"], country=m.get("country") or "", year=m.get("year"), motor=m["motor"],
                        measured=m.get("measured_apogee"), rocketpy=m.get("rocketpy_apogee"), openrocket=m.get("openrocket_apogee"),
                        model_apogee=apogee, notes=m.get("notes", []), hybrid=bool(m.get("hybrid")), source=m["source"],
                        rocket=geometry(cfg), model=model))
    print(f"{m['key']:12s} {apogee:8.1f} m")
flown = [e for e in library if e["measured"]]
err = lambda k: 100 * sum(abs(e[k] / e["measured"] - 1) for e in flown) / len(flown)
both = [e for e in library if e["rocketpy"]]
stats = dict(n=len(library), flown=len(flown), ours_vs_measured=err("model_apogee"), rocketpy_vs_measured=err("rocketpy"),
             ours_vs_rocketpy=100 * sum(abs(e["model_apogee"] / e["rocketpy"] - 1) for e in both) / len(both),
             port=max(0.1, math.ceil(worst * 1000) / 10) if node else None)
json.dump(_clean(dict(stats=stats, rockets=[{k: v for k, v in e.items() if k not in ("model", "rocket")} for e in library])),
          open(ROOT / "docs" / "library.json", "w"), indent=1)
data = json.dumps(_clean(dict(first="ndrt_2020", library=library, stats=stats)), separators=(",", ":")).replace("</", "<\\/")
html = (WEB / "template.html").read_text().replace("/*__SIM__*/", (WEB / "sim.js").read_text()).replace("/*__DATA__*/null", data)
(WEB / "index.html").write_text(html)
print(f"wrote web/index.html ({len(html) / 1e6:.2f} MB) with {len(library)} rockets; browser port apogee difference at most {worst * 100:.3f}%")
print({k: (round(v, 2) if isinstance(v, float) else v) for k, v in stats.items()})
