"""Convert published flight examples into this project's rocket configs: data/library/*.yaml.

The inputs are the parameters and data files that university teams published through the RocketPy
project's documentation (docs/examples and data/ in the RocketPy repository). The SPECS table below is
those parameters, transcribed by hand in RocketPy's own conventions; convert() maps them to this
project's conventions. Nothing from RocketPy is executed.

Usage: python scripts/ingest_library.py /path/to/RocketPy-checkout
"""
import math
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import netCDF4
import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "library"
SRC = "https://docs.rocketpy.org/en/latest/examples/"
PI = math.pi

SPECS = dict(
    valetudo=dict(
        name="Valetudo", team="Projeto Jupiter", country="Brazil", year=2019, page="valetudo_flight_sim.html",
        measured=860.0, rocketpy=825.39,
        radius=0.04045, mass=8.257, inertia=(3.675, 0.007), cm=0.0, buttons=(0.224, -0.93),
        motor=dict(pos=-1.024, thrust="motors/projeto-jupiter/keron_thrust_curve.csv", burn=5.274, label="Keron (student-built solid)",
                   grains=dict(n=6, rho=1707, ro=0.0214, ri=0.00965, h=0.120, sep=0.006), grains_cm=0.42),
        nose=dict(length=0.274, kind="tangent", pos=1.134),
        fins=dict(n=3, span=0.077, root=0.058, tip=0.018, pos=-0.906),
        drag=("rockets/valetudo/Cd_PowerOff_RASAero.csv", "rockets/valetudo/Cd_PowerOn_RASAero.csv"),
        chutes=[dict(name="drogue", cds=0.349 * 1.3, trigger="apogee", lag=1.0)],
        env=dict(elevation=668.0), flight=dict(inclination=84.7, heading=53.0, rail=5.7)),
    andromeda=dict(
        name="Andromeda", team="Aristotle Space and Aeronautics Team", country="Greece", year=2022, page="andromeda_flight_sim.html",
        measured=3415.0, rocketpy=3614.95,
        radius=0.07535, mass=20.9767, inertia=(11.249, 0.12377), cm=1.3998, buttons=(1.5998, 0.8998),
        motor=dict(pos=0.0, thrust="rockets/andromeda/thrust_curve.csv", burn=3.76, label="Cesaroni Pro98 M2020",
                   grains=dict(n=1, rho=1468.9079097925262, ro=0.0375, ri=0.01875, h=0.893, sep=0.0), grains_cm=0.5613903872259161),
        nose=dict(length=0.3, kind="vonkarman", pos=2.4996),
        fins=dict(n=3, span=0.185, root=0.23, tip=0.11, pos=0.3546),
        drag=("rockets/andromeda/drag_coefficient.csv",) * 2,
        chutes=[dict(name="drogue", cds=0.84665922014, trigger="apogee", lag=0.0), dict(name="main", cds=8.362919643856031, trigger=500.0, lag=0.0)],
        env=dict(elevation=160.0, file="weather/euroc_2022_all_windows.nc", date=(2022, 10, 14, 14), tz="Europe/Lisbon", lat=39.388692, lon=-8.287814),
        flight=dict(inclination=84.0, heading=133.0, rail=12.0)),
    astra=dict(
        name="Astra", team="Faraday Rocketry UPV", country="Spain", year=2022, page="astra_flight_sim.html",
        measured=3250.0, rocketpy=3043.07,
        radius=0.047, mass=10.6462, inertia=(6.6986, 0.040824), cm=1.3957, buttons=(1.5957, 1.1957),
        motor=dict(pos=0.7146163949, thrust="motors/cesaroni/Cesaroni_4263L1350-P.eng", burn=3.284, label="Cesaroni L1350",
                   grains=dict(n=1, rho=1256.7753406541794, ro=0.0375, ri=0.01875, h=0.486, sep=0.0), grains_cm=0.243),
        nose=dict(length=0.27, kind="vonkarman", pos=2.5214),
        fins=dict(n=4, span=0.117, root=0.2, tip=0.118, pos=0.9134),
        drag=("rockets/astra/drag_coefficient.csv",) * 2, chutes=[],
        env=dict(elevation=160.0, file="weather/euroc_2022_all_windows.nc", date=(2022, 10, 13, 16), tz="Europe/Lisbon", lat=39.3897, lon=-8.2889639),
        flight=dict(inclination=84.0, heading=133.0, rail=12.0)),
    erebus=dict(
        name="Erebus-11", team="BME Suborbitals", country="Hungary", year=2022, page="erebus_flight_sim.html",
        measured=3020.0, rocketpy=2750.90,
        radius=0.04575, mass=5.82, inertia=(2.571, 0.0056233), cm=1.192, buttons=(1.392, 0.692),
        motor=dict(pos=0.211668, thrust="rockets/erebus11/thrust_source.csv", burn=3.657, label="Cesaroni Pro54 K-class",
                   grains=dict(n=1, rho=1196.6353410211093, ro=0.027, ri=0.0135, h=0.572, sep=0.0), grains_cm=0.3),
        nose=dict(length=0.391113, kind="vonkarman", pos=2.3841),
        fins=dict(n=4, span=0.08, root=0.12, tip=0.05, pos=0.395787),
        tail=dict(top=0.04575, bottom=0.03575, length=0.079119, pos=0.290787),
        drag=("rockets/erebus11/drag_curve.csv",) * 2, chutes=[],
        env=dict(elevation=160.0, file="weather/euroc_2022_all_windows.nc", date=(2022, 10, 15, 16), tz="Europe/Lisbon", lat=39.3897, lon=-8.2889639),
        flight=dict(inclination=84.0, heading=133.0, rail=12.0)),
    prometheus=dict(
        name="Prometheus", team="Western Engineering Rocketry Team", country="Canada", year=2023, page="prometheus_2022_flight_sim.html",
        measured=3898.37, rocketpy=4190.05,
        radius=0.06985, mass=13.93, inertia=(4.87, 0.05), cm=0.9549, buttons=(0.69, 0.21),
        motor=dict(pos=0.0, thrust="motors/cesaroni/Cesaroni_7579M1520-P.eng", burn=4.897, label="Cesaroni M1520",
                   propellant=3.737, dry=(2.981, 0.274, (0.0, 0.0)), grains_cm=0.274, length=0.548, diameter=0.128),
        nose=dict(length=0.742, kind="vonkarman", pos=2.229),
        fins=dict(n=3, span=0.13, root=0.268, tip=0.136, pos=0.273, sweep=0.066),
        drag_table=[(0.0, 0.422), (0.15, 0.422), (0.45, 0.38), (0.77, 0.32), (0.82, 0.3), (0.88, 0.3), (0.94, 0.32), (0.99, 0.37),
                    (1.04, 0.44), (1.24, 0.43), (1.33, 0.42), (1.49, 0.39), (3.0, 0.39)], drag_on_factor=1.02,
        chutes=[dict(name="drogue", cds=1.6 * PI * 0.3048 ** 2, trigger="apogee", lag=0.0), dict(name="main", cds=2.2 * PI * 0.9144 ** 2, trigger=457.2, lag=0.0)],
        env=dict(elevation=1401.0, file="weather/spaceport_america_pressure_levels_2023_hourly.nc", date=(2023, 6, 24, 9), tz="America/Denver", lat=32.939377, lon=-106.911986),
        flight=dict(inclination=80.0, heading=75.0, rail=5.18)),
    cavour=dict(
        name="Cavour", team="PoliTo Rocket Team", country="Italy", year=2023, page="cavour_flight_sim.html",
        measured=2789.0, rocketpy=2818.90,
        radius=0.052, mass=8.219, inertia=(4.449, 0.014634), cm=1.1994, buttons=(1.0954, 0.0054),
        motor=dict(pos=0.0, thrust="motors/cesaroni/Cesaroni_3618L995-P.eng", burn=3.8, label="Cesaroni L995",
                   grains=dict(n=3, rho=1653.53, ro=0.0325, ri=0.011375, h=0.13244, sep=0.001), grains_cm=0.19966),
        nose=dict(length=0.52, kind="vonkarman", pos=2.7224),
        fins=dict(n=4, span=0.1, root=0.2, tip=0.07, pos=0.2104),
        drag=("rockets/polito/drag_coefficient_power_off.csv", "rockets/polito/drag_coefficient_power_on.csv"), chutes=[],
        env=dict(elevation=150.0, file="weather/euroc_2023_all_windows.nc", date=(2023, 10, 13, 13), tz="Europe/Lisbon", lat=39.388692, lon=-8.287814),
        flight=dict(inclination=84.0, heading=133.0, rail=12.0)),
    genesis=dict(
        name="Genesis", team="Faraday Rocketry UPV", country="Spain", year=2023, page="genesis_flight_sim.html",
        measured=2916.0, rocketpy=3076.45,
        radius=0.047, mass=9.214, inertia=(7.5046, 0.042241), cm=0.895, buttons=(0.98, 0.095),
        motor=dict(pos=0.0, thrust="motors/cesaroni/Cesaroni_3618L995-P.eng", burn=3.8, label="Cesaroni L995",
                   grains=dict(n=3, rho=1815, ro=0.033, ri=0.015, h=0.12, sep=0.005), grains_cm=0.243),
        nose=dict(length=0.27, kind="vonkarman", pos=2.372),
        fins=dict(n=4, span=0.105, root=0.2, tip=0.11, pos=0.25),
        drag=("rockets/genesis/drag_coefficient_power_off.csv", "rockets/genesis/drag_coefficient_power_on.csv"),
        chutes=[dict(name="drogue", cds=0.285005285533666, trigger="apogee", lag=1.0), dict(name="main", cds=1.1, trigger=870.0, lag=1.0)],
        env=dict(elevation=160.0, file="weather/euroc_2023_all_windows.nc", date=(2023, 10, 12, 14), tz="Europe/Lisbon", lat=39.38895, lon=-8.28837),
        flight=dict(inclination=84.0, heading=133.0, rail=12.0)),
    juno3=dict(
        name="Juno III", team="Projeto Jupiter", country="Brazil", year=2023, page="juno3_flight_sim.html",
        measured=3213.0, rocketpy=3026.05,
        radius=0.0655, mass=24.05, inertia=(15.07, 0.067), cm=0.0, buttons=(0.24, -1.17),
        motor=dict(pos=0.0, thrust="motors/projeto-jupiter/mandioca_thrust_curve.csv", reshape=(5.8, 8800.0), nozzle=-1.294,
                   label="Mandioca (student-built solid)",
                   grains=dict(n=5, rho=1748.9, ro=0.0465, ri=0.016, h=0.156, sep=0.006), grains_cm=-0.683),
        nose=dict(length=0.565, kind="vonkarman", pos=1.477),
        fins=dict(n=4, span=0.13, root=0.20, tip=0.12, pos=-0.928),
        tail=dict(top=0.0655, bottom=0.0535, length=0.068, pos=-1.226),
        drag=("rockets/juno3/drag_curve.csv",) * 2, drag_match=(0.6, 0.38),
        chutes=[dict(name="drogue", cds=0.885, trigger="apogee", lag=0.5)],
        env=dict(elevation=1480.0, file="weather/spaceport_america_pressure_levels_2023_hourly.nc", date=(2023, 6, 23, 17), tz="America/Denver", lat=32.939377, lon=-106.911986),
        flight=dict(inclination=85.0, heading=105.0, rail=5.2)),
    lince=dict(
        name="Lince", team="STAR UC3M", country="Spain", year=2023, page="lince_flight_sim.html",
        measured=3587.0, rocketpy=3284.12,
        radius=0.052, mass=10.6851352, inertia=(4.9939475, 0.0213204), cm=1.061, buttons=(1.54049, 0.13549),
        motor=dict(pos=0.0, thrust="motors/cesaroni/Cesaroni_M1101.eng", burn=4.736, label="Cesaroni M1101",
                   grains=dict(n=4, rho=1363, ro=0.035, ri=0.01, h=0.16, sep=0.0), grains_cm=0.315533),
        nose=dict(length=0.28, kind="vonkarman", pos=2.109417),
        fins=dict(n=4, span=0.0825, root=0.17, tip=0.0425, pos=0.17),
        tail=dict(top=0.052, bottom=0.04852, length=0.022, pos=0.0),
        drag=("rockets/lince/drag_coefficient_power_off.csv", "rockets/lince/drag_coefficient_power_on.csv"),
        chutes=[dict(name="main", cds=3.9, trigger="apogee", lag=0.0)],
        env=dict(elevation=158.0, file="weather/euroc_2023_all_windows.nc", date=(2023, 10, 12, 11), tz="Europe/Lisbon", lat=39.3897, lon=-8.288964),
        flight=dict(inclination=84.0, heading=133.0, rail=12.0)),
    halcyon=dict(
        name="Halcyon", team="Aerospace Team Graz", country="Austria", year=2023, page="halcyon_flight_sim.html",
        measured=3450.0, rocketpy=3212.78, hybrid=True,
        radius=0.0762, mass=14.613, inertia=(24.56, 0.07), cm=2.344, buttons=(2.808, 1.549),
        motor=dict(pos=0.02, thrust="rockets/astg/engine_Halcyon_4thHotfire.eng", burn=5.0, label="Student-built N2O hybrid",
                   grains=dict(n=1, rho=920, ro=0.043, ri=0.0225, h=0.31, sep=0.0), grains_cm=0.385,
                   oxidizer=(4.2, 0.93475), dry=(10.67, 0.78, (1.668, 0.026)), diameter=0.14),
        nose=dict(length=0.46, kind="vonkarman", pos=3.556),
        fins=dict(n=4, span=0.125, root=0.247, tip=0.045, pos=0.263),
        tail=dict(top=0.0762, bottom=0.0496, length=0.254, pos=0.254),
        drag=("rockets/astg/DragCoeffOR_off.csv", "rockets/astg/DragCoeffOR_on.csv"),
        chutes=[dict(name="main", cds=9.621, trigger="apogee", lag=5.0)],
        env=dict(elevation=130.0, file="weather/euroc_2023_all_windows.nc", date=(2023, 10, 13, 14), tz="Europe/Lisbon", lat=39.388692, lon=-8.287814),
        flight=dict(inclination=85.0, heading=90.0, rail=12.0)),
    defiance=dict(
        name="Defiance Mk. IV", team="University of Toronto Aerospace Team", country="Canada", year=2024, page="defiance_flight_sim.html",
        measured=9308.32, rocketpy=9238.01, hybrid=True,
        radius=0.07, mass=37.211, inertia=(94.14, 0.09), cm=3.29, buttons=None,
        motor=dict(pos=0.2, thrust="rockets/defiance/Thrust_curve.csv", label="Student-built N2O hybrid",
                   grains=dict(n=1, rho=920, ro=0.0665, ri=0.061, h=1.25, sep=0.0), grains_cm=0.377,
                   oxidizer=(17.0, 2.2), dry=(13.832, 0.78, (1.801, 0.0305)), diameter=0.133),
        nose=dict(length=0.563, kind="vonkarman", pos=4.947),
        fins=dict(n=3, span=0.115, root=0.4, tip=0.2, pos=0.175),
        tail=dict(top=0.07, bottom=0.064, length=0.0597, pos=0.1),
        drag=("rockets/defiance/DragCurve.csv",) * 2,
        chutes=[dict(name="drogue", cds=1.55, trigger="apogee", lag=0.0), dict(name="main", cds=2.2, trigger=305.0, lag=0.0)],
        env=dict(elevation=1383.4, wind_uv=(-2.9, 1.0)), flight=dict(inclination=85.0, heading=90.0, rail=10.0)),
)
NOSE = {"tangent": "ogive", "ogive": "ogive", "vonkarman": "parabolic", "lvhaack": "parabolic", "conical": "cone", "elliptical": "ellipsoid"}


def read_curve(path):
    """Two-column numeric file (comma or space separated); comment and header lines are skipped."""
    rows = []
    for line in Path(path).read_text(encoding="utf-8-sig").splitlines():
        parts = line.replace(",", " ").split()
        if len(parts) != 2:
            continue
        try:
            rows.append((float(parts[0]), float(parts[1])))
        except ValueError:
            continue
    return np.array(rows)


def clean_table(a, n=48):
    """Sort by the first column, average duplicates and thin to at most n points."""
    a = a[np.argsort(a[:, 0], kind="stable")]
    xs = np.unique(a[:, 0])
    ys = np.array([a[a[:, 0] == x, 1].mean() for x in xs])
    if len(xs) > n:
        grid = np.unique(np.concatenate([np.linspace(xs[0], xs[-1], n), xs[[0, -1]]]))
        ys = np.interp(grid, xs, ys); xs = grid
    return xs, ys


def thrust_curve(src, m):
    a = read_curve(src / m["thrust"])
    t, f = a[:, 0], np.maximum(a[:, 1], 0.0)
    if "burn" in m:                       # RocketPy truncates the curve at the stated burn time
        tb = m["burn"]
        if t[-1] > tb:
            fb = float(np.interp(tb, t, f)); keep = t < tb
            t, f = np.append(t[keep], tb), np.append(f[keep], fb)
    if "reshape" in m:                    # stretch to a stated burn time and total impulse
        tb, imp = m["reshape"]
        t = t * tb / t[-1]
        f = f * imp / np.trapezoid(f, t)
    if f[-1] != 0.0:
        t, f = np.append(t, t[-1] + 1e-3), np.append(f, 0.0)
    if t[0] == 0.0 and f[0] == 0.0:
        t, f = t[1:], f[1:]
    keep = np.concatenate([[True], np.diff(t) > 1e-9])
    t, f = t[keep], f[keep]
    if len(t) > 160:                      # thin dense test-stand data; keep the total impulse exactly
        imp = np.trapezoid(np.concatenate([[0.0], f]), np.concatenate([[0.0], t]))
        grid = np.unique(np.concatenate([np.linspace(t[0], t[-1], 160), t[[0, -1]]]))
        f = np.interp(grid, t, f); t = grid
        f = f * imp / np.trapezoid(np.concatenate([[0.0], f]), np.concatenate([[0.0], t]))
        f[-1] = 0.0
    return t, f


def sounding(src, env):
    d = netCDF4.Dataset(src / env["file"])
    tname = "valid_time" if "valid_time" in d.variables else "time"
    lname = "pressure_level" if "pressure_level" in d.variables else "level"
    when = datetime(*env["date"], tzinfo=ZoneInfo(env["tz"]))
    tv = d.variables[tname]
    times = netCDF4.num2date(np.asarray(tv[:]), tv.units, only_use_cftime_datetimes=False, only_use_python_datetimes=True)
    stamp = when.astimezone(ZoneInfo("UTC")).replace(tzinfo=None)
    ti = int(np.argmin([abs((x - stamp).total_seconds()) for x in times]))
    la = int(np.argmin(np.abs(np.asarray(d.variables["latitude"][:]) - env["lat"])))
    lo = int(np.argmin(np.abs(np.asarray(d.variables["longitude"][:]) - env["lon"])))
    lev = np.asarray(d.variables[lname][:], float) * 100.0
    h = np.asarray(d.variables["z"][ti, :, la, lo]) / 9.80665
    T, u, v = (np.asarray(d.variables[k][ti, :, la, lo]) for k in ("t", "u", "v"))
    o = np.argsort(h); o = o[h[o] < 20000.0]
    gap = abs((times[ti] - stamp).total_seconds()) / 3600.0
    head = (f"# ERA5 reanalysis profile for {stamp:%Y-%m-%d %H:%M} UTC (nearest hour in the file: {times[ti]:%Y-%m-%d %H:%M}), "
            f"grid point {float(d.variables['latitude'][la]):.2f}, {float(d.variables['longitude'][lo]):.2f}\n"
            "# geopotential_height_m,pressure_Pa,temperature_K,wind_east_ms,wind_north_ms\n")
    return head + "".join(f"{h[i]:.1f},{lev[i]:.0f},{T[i]:.2f},{u[i]:.2f},{v[i]:.2f}\n" for i in o), gap


def convert(key, s, src):
    files = OUT / "files"; files.mkdir(parents=True, exist_ok=True)
    tip = s["nose"]["pos"]
    st = lambda x: tip - x                              # RocketPy coordinate (tail_to_nose) -> metres from the nose tip
    m = s["motor"]; R = s["radius"]
    nozzle = st(m["pos"] + m.get("nozzle", 0.0))
    notes = []
    comps = [dict(type="lumped", name="rocket without motor (as published)", mass=s["mass"], cg=round(st(s["cm"]), 5),
                  inertia_axial=s["inertia"][1], inertia_transverse=s["inertia"][0])]
    if "grains" in m:
        g = m["grains"]
        prop = g["n"] * g["rho"] * PI * (g["ro"] ** 2 - g["ri"] ** 2) * g["h"]
        glen = g["n"] * g["h"] + (g["n"] - 1) * g["sep"]
        dia = m.get("diameter", 2 * g["ro"])
    else:
        prop, glen, dia = m["propellant"], m["length"], m["diameter"]
    pcg = st(m["pos"] + m["grains_cm"])
    if "oxidizer" in m:                                   # hybrid: lump the oxidiser with the fuel grain
        mo, xo = m["oxidizer"]
        pcg = (prop * pcg + mo * st(m["pos"] + xo)) / (prop + mo)
        prop += mo
        notes.append("Hybrid motor: fuel grain and oxidiser are modelled as one propellant mass at a fixed position.")
    if "dry" in m:
        md, xd, (it, ia) = m["dry"]
        comps.append(dict(type="lumped", name="motor hardware", mass=md, cg=round(st(m["pos"] + xd), 5),
                          inertia_axial=ia, inertia_transverse=it))
    n = s["nose"]
    comps.append(dict(type="nose", shape=NOSE[n["kind"]], length=n["length"], diameter=2 * R))
    f = s["fins"]
    fin_te = st(f["pos"]) + f["root"]
    end = max(nozzle, fin_te)
    tl = s.get("tail")
    if tl:
        t0 = st(tl["pos"])
        comps.append(dict(type="body", position=n["length"], length=round(t0 - n["length"], 5), diameter=2 * R))
        comps.append(dict(type="transition", position=round(t0, 5), length=tl["length"], fore_diameter=2 * tl["top"], aft_diameter=2 * tl["bottom"]))
        if end > t0 + tl["length"] + 1e-6:
            comps.append(dict(type="body", position=round(t0 + tl["length"], 5), length=round(end - t0 - tl["length"], 5), diameter=2 * tl["bottom"]))
    else:
        comps.append(dict(type="body", position=n["length"], length=round(end - n["length"], 5), diameter=2 * R))
    comps.append(dict(type="fins", count=f["n"], position=round(st(f["pos"]), 5), root_chord=f["root"], tip_chord=f["tip"], span=f["span"],
                      sweep=round(f.get("sweep", f["root"] - f["tip"]), 5), thickness=0.004, body_diameter=2 * R, edge="rounded"))
    # motor file
    t, thr = thrust_curve(src, m)
    eng = [f"; {s['name']} motor: {m['label']}. Thrust curve from the RocketPy repository ({m['thrust']}),",
           "; processed as RocketPy's example does (burn-time cut or reshape). Masses computed from the published grain data.",
           f"{key} {dia * 1000:.1f} {glen * 1000:.1f} P {prop:.5f} {prop:.5f} library"]
    eng += [f"{a:.4f} {b:.3f}" for a, b in zip(t, thr)]
    (files / f"{key}.eng").write_text("\n".join(eng) + "\n")
    # drag table
    if "drag_table" in s:
        mm = np.array([x for x, _ in s["drag_table"]]); off = np.array([y for _, y in s["drag_table"]]); on = off * s.get("drag_on_factor", 1.0)
    else:
        xo, yo = clean_table(read_curve(src / s["drag"][0])); xn, yn = clean_table(read_curve(src / s["drag"][1]))
        mm = np.unique(np.concatenate([xo, xn])); mm = mm[np.linspace(0, len(mm) - 1, min(len(mm), 48)).astype(int)]
        off, on = np.interp(mm, xo, yo), np.interp(mm, xn, yn)
        if "drag_match" in s:
            mach, cd = s["drag_match"]; k = cd / float(np.interp(mach, xo, yo)); off, on = off * k, on * k
    table = [[round(float(a), 4), round(float(b), 4), round(float(c), 4)] for a, b, c in zip(mm, off, on)]
    # site
    e, fl = s["env"], s["flight"]
    site = dict(elevation=e["elevation"], rail_length=fl["rail"], rail_elevation=fl["inclination"], rail_azimuth=fl["heading"])
    if "file" in e:
        text, gap = sounding(src, e)
        (files / f"{key}_weather.csv").write_text(text)
        site["sounding"] = f"files/{key}_weather.csv"; site["wind"] = dict(model="sounding")
        if gap > 1.5:
            notes.append(f"The weather file's nearest hour is {gap:.0f} h from the launch time.")
    elif "wind_uv" in e:
        u, v = e["wind_uv"]
        site["wind"] = dict(model="constant", speed=round(math.hypot(u, v), 3), direction=round(math.degrees(math.atan2(-u, -v)) % 360, 1))
        notes.append("Standard atmosphere with the team's constant wind; no recorded weather profile.")
    else:
        site["wind"] = dict(model="none"); notes.append("Standard atmosphere, no wind; no recorded weather profile.")
    rocket = dict(name=f"{s['name']} ({s['year']})", reference_diameter=2 * R, components=comps,
                  recovery=[dict(name=c["name"], cds=round(c["cds"], 5), trigger=c["trigger"], lag=c["lag"], inflation_time=0.5) for c in s["chutes"]])
    if s.get("buttons"):
        rocket["rail_button_aft"] = round(st(min(s["buttons"])), 5)
    if not s["chutes"]:
        notes.append("No recovery system was published, so the simulated descent is ballistic; only the ascent is comparable.")
    cfg = dict(
        meta=dict(key=key, name=s["name"], team=s["team"], country=s["country"], year=s["year"], motor=m["label"],
                  measured_apogee=s["measured"], rocketpy_apogee=s["rocketpy"], source=SRC + s["page"],
                  hybrid=bool(s.get("hybrid")), notes=notes),
        rocket=rocket,
        motor=dict(eng_file=f"files/{key}.eng", nozzle_position=round(nozzle, 5), case_mass=0.0, propellant_cg=round(pcg, 5), grain_length=round(glen, 5)),
        aero=dict(backend="lookup", cd_table=table), site=site, sim=dict(method="RK45", t_max=1500.0),
        uncertainty=dict(mass_scale=dict(sigma=0.01), cd_scale=dict(sigma=0.05), impulse_scale=dict(sigma=0.03), wind_speed_offset=dict(sigma=1.5),
                         wind_direction_offset=dict(sigma=15.0), rail_elevation_offset=dict(sigma=1.0), cds_scale=dict(sigma=0.1)))
    head = (f"# {s['name']} ({s['year']}), {s['team']}. Generated by scripts/ingest_library.py from the inputs the team published\n"
            f"# through RocketPy's documentation: {SRC}{s['page']}\n# Positions are metres from the nose tip. Do not edit by hand; edit the script's SPECS table.\n")
    (OUT / f"{key}.yaml").write_text(head + yaml.safe_dump(cfg, sort_keys=False, default_flow_style=None, width=140))


if __name__ == "__main__":
    src = Path(sys.argv[1]) / "data"
    OUT.mkdir(parents=True, exist_ok=True)
    for key, spec in SPECS.items():
        convert(key, spec, src)
        print("wrote", key)
